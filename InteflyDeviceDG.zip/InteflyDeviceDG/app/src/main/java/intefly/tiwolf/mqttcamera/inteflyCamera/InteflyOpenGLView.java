package intefly.tiwolf.mqttcamera.inteflyCamera;

/**
 * @author tiwolf_li
 * @Date on 2021/1/25
 * @Description 整个app占用CPU达到70%左右时对我司摄像头出图有影响，每帧图片处理的时间需要几十毫秒到100多毫秒，导致画面延时
 */
public class InteflyOpenGLView {




    IGedDataFromNativeListener iGedDataFromNativeListener;
    public InteflyOpenGLView(IGedDataFromNativeListener iGedDataFromNativeListener){
        this.iGedDataFromNativeListener=iGedDataFromNativeListener;
    }

    protected int OnDataCallBack( int nType, byte[] data, int len, long ts, int iskey) {

        return iGedDataFromNativeListener==null?0:iGedDataFromNativeListener.OnDataCallBack(nType,data,len,ts,iskey);
    }

    protected int HaiKangOnDataCallBack( int nType, byte[] data, int len, long ts, int iskey) {

        return iGedDataFromNativeListener==null?0:iGedDataFromNativeListener.HaiKangOnDataCallBack(nType,data,len,ts,iskey);
    }

    protected int HaiKangOnDataCallBack1(int nType, byte[] data, int len, long ts, int iskey){
        return iGedDataFromNativeListener==null?0:iGedDataFromNativeListener.HaiKangOnDataCallBack1(nType,data,len,ts,iskey);
    }

    public int YuShiOnDataCallBack1( int nType, byte[] data, int len, long ts, int iskey){
        return iGedDataFromNativeListener==null?0:iGedDataFromNativeListener.YuShiOnDataCallBack1(nType,data,len,ts,iskey);
    }



    static {
        System.loadLibrary("curl");
        System.loadLibrary("cJSON");
        System.loadLibrary("intefly_tiwolf_mqttcamera_inteflyCamera_InteflyOpenGLView");
    }

    public native void StopStream();

    public native void StartStream();

    /**
     * callMethod1调用的方法如下 这个用于云台海康摄像头
     * public int OnRecvYuvByte(byte[] buf,int w, int h,int format,int linesize)
     */
    public native void callMethod1(String url);
    /**
     * callMethod2调用的方法如下
     * public int OnDataCallBack( int nType, byte[] data, int len, long ts, int iskey)
     */
    public native void callMethod2(String url);
    /**
     * callMethod3调用的方法如下  todo 这个用于海康枪型摄像头 枪型海康摄像头出来的帧图片和云台海康摄像头相比：少了SEI,还有SPS,PPS的值都变动了，关键帧那里也变动了
     * public  int OnRecvRGBAByte(byte[] var1, int var2, int var3, int var4, int var5)
     */
    public native void callMethod3(String url);

    /**
     * callMethod3调用的方法如下  todo 这个用于宇视球型摄像头
     * @param url
     */
    public native void callMethod4(String url);

    /**
     * login 登录
     * @param x 返回错误码 成功返回0 其他非0
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int login(int x, String user, String passwd, String ip);
    /**
     * ZoomIn 控制摄像头变倍放大
     * @param x 返回错误码 成功返回0 其他非0
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int ZoomIn(int x, String user, String passwd, String ip);
    /**
     * ZoomOut 控制摄像头变倍缩小
     * @param x 返回错误码 成功返回0 其他非0
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int ZoomOut(int x, String user, String passwd, String ip);
    /**
     * PtzUp 控制摄像头云台向上调整
     * @param x 返回错误码 成功返回0 其他非0
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int PtzUp(int x, String user, String passwd, String ip);
    /**
     * PtzDown 控制摄像头云台向下调整
     * @param x 返回错误码 成功返回0 其他非0
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int PtzDown(int x, String user, String passwd, String ip);
    /**
     * PtzLeft 控制摄像头云台向左调整
     * @param x 返回错误码 成功返回0 其他非0
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int PtzLeft(int x, String user, String passwd, String ip);
    /**
     * PtzRight 控制摄像头云台向右调整
     * @param x 返回错误码 成功返回0 其他非0
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int PtzRight(int x, String user, String passwd, String ip);

    public static native int PtzStop(int x, String user, String passwd, String ip);

    public static native int NV12ToNV21(byte[] inputByte,int length,byte[] outputByte,int width,int height);

    public static native int NV12ToYUV420P(byte[] inputByte,int length,byte[] outputByte,int width,int height);

    /**
     * Reboot 控制RV1109摄像头重启
     * @param code 返回错误码
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int Reboot(int code,String user,String passwd,String ip);


    /**
     * PrePoint 控制RV1109进行画面聚焦
     * @param code 返回错误码
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int PrePoint(int code,String user,String passwd,String ip);

    /**
     * SetThirdStreamParam 设置第三码流的参数
     * @param code 返回错误码
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int SetThirdStreamParam(int code,String user,String passwd,String ip);

    /**
     * SetThirdStreamParam 获取第三码流的参数
     * @param code 返回错误码
     * @param user 登录用户名
     * @param passwd 登录密码
     * @param ip 摄像头ip地址
     * @return 返回0
     */
    public static native int GetThirdStreamParam(int code,String user,String passwd,String ip);


    public interface IGedDataFromNativeListener{

        int OnDataCallBack( int nType, byte[] data, int len, long ts, int iskey);
        int HaiKangOnDataCallBack( int nType, byte[] data, int len, long ts, int iskey);
        int HaiKangOnDataCallBack1(int nType, byte[] data, int len, long ts, int iskey);
        int YuShiOnDataCallBack1( int nType, byte[] data, int len, long ts, int iskey);
    }
}
