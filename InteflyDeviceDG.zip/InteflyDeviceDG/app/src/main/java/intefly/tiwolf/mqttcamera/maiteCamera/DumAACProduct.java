package intefly.tiwolf.mqttcamera.maiteCamera;

/**
 * author:tiwolf
 * create date:2022/10/27
 * Describe:虚拟的音频生产 pcm长度必须设置为2048，睡眠的时间必须记录为10，如果睡眠的时间设为50或者pcm的长度设置为小于2048的时候，则录制后的视频非常快
 */
public class DumAACProduct extends Thread{

    boolean isproduce=true;

    private AACproduct.IshowPcm ishowPcm;

    public DumAACProduct(AACproduct.IshowPcm ishowPcm){
        this.ishowPcm=ishowPcm;
    }

    @Override
    public void run() {
        super.run();
        byte[] pcm=new byte[2048];//todo 如果这个设置小于2048，则录制出来的mp4文件播放速度非常快
//        byte[] pcm=new byte[1024];
//        Log.e("TAG", "run: 虚拟的一帧pcm="+pcm+";长度为="+pcm.length );
        while (isproduce){
            ishowPcm.showpcm(pcm,pcm.length);
            try {
                //todo 如果sleep(50)，则录制出来的mp4播放的速度非常快
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void closeDum(){
        isproduce=false;
    }
}
