package intefly.tiwolf.mqttcamera.maiteCamera;


/**
 * @author tiwolf_li
 * @Date on 2020/6/5
 * @Description 这个类主要是将迈特摄像头的内容封装起来
 */
public class MaiteOpenGLView {

    private static final String TAG= MaiteOpenGLView.class.getSimpleName();




    static {
        //这个.so库是根据这个包名和类名设置的，请注意
        System.loadLibrary("c++_shared");
        System.loadLibrary("intefly_rtmp_pusher");
        System.loadLibrary("intefly_playback");
    }

    /**
     * 打开日志
     * @param filePath
     * @return
     */
    public static native boolean OpenLogFile(String filePath);

    /**
     *
     * @param nStreamType  1
     * @param strVendor
     * @param strRtmpUrl  推流地址
     * @return
     */
    public static native int StartRTMPStream(int nStreamType, String strVendor,String strRtmpUrl);

    /**
     *
     * @param sampleRate 采样率
     * @param bitPerSample 采样精度
     * @param channel 通道数
     * @return
     */
    public static native int SetAudioParametes(int sampleRate,int bitPerSample,int channel);

    /**
     *
     * @param var0 登录返回值
     * @param size 内容长度
     * @param var1 内容
     * @param time 时间戳
     * @return
     */
    public static native boolean SendVideoFrame_WithDelimiter(int var0,  int size,byte[] var1,long time);

    /**
     *
     * @param var0  登录返回值
     * @param strRtmpUrl url
     * @return
     */
    public static native int StopRTMPStream(int var0, String strRtmpUrl);

    /**
     *
     * @param handler 初始化返回值
     * @param size  pcm长度
     * @param content pcm内容
     * @param time 时间戳
     * @param format 0-pcm 1-aac
     * @return
     */
    public static native boolean SendAudioFrame(int handler,int size,byte[] content,long time,int format);

    public static native void SetLogCallback(Object var0);

    /**
     *
     * @param handler
     * @param rtmpUrl
     * @return 返回0成功 非0失败
     */
    public static native int StartLiveStream(int handler,String rtmpUrl);

    public static native int StopLiveStream(int handler,String rtmpUrl);

    public static native int StartRecord(int handler,String path);

    public static native int StopRecord(int handler);

    /**
     * 打开日志文件。
     *
     * @param filePath 日志文件名称，含绝对路径。
     * 成功返回true, 否则返回false。
     */
    public static native boolean OpenPlayingLog(String filePath);

    /**
     * 关闭日志文件。
     *
     * 成功返回true, 否则返回false。
     */
    public static native boolean ClosePlayingLog();

    /**
     * 启动回放。
     *
     * @param from 录像文件名。
     * @param to 目标URL，将sRecordFileName的音视频流发送到该URL。
     * @成功返回流句柄 - 大于等于0，失败返回-1。
     */
    public static native int StartPlayback(String from,String to);

    /**
     * 停止回放。
     *
     * @param handle 回放句柄，是StartPlayback()的返回值。
     * @param to 目标URL，不为空时，停止向该URL发送流，否则停止所有流。
     * @成功返回0，失败返回-1
     */
    public static native int StopPlayback(int handle,String to);

    /**
     * 检查回放是否完成。
     *
     * @param handle 回放句柄，是StartPlayback()的返回值。
     *
     * 播放完成返回1，否则返回0
     */
    public static native int IsStop(int handle);
}
