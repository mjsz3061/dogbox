package com.ytf.dogbox.util;


/**
 * Created by Justin.t.wang on 2017-08-10.
 */
public class MD5UtilException extends Exception {
    public MD5UtilException(String message) {
        super(message);
    }

    public MD5UtilException(String message, Throwable cause) {
        super(message, cause);
    }
}
