package com.ytf.dogbox.base.view;


import com.uber.autodispose.AutoDisposeConverter;


public interface BaseView {

    /**
     * 获取总体布局
     *
     * @return layoutID
     */
    int getLayout();

    /**
     * 初始化视图
     */
    void initView(Object obj);

    /**
     * 初始化数据
     */
    void initData();

    /**
     * 设置监听器
     */
    void setListener();

    /**
     * 抛出异常
     * @param throwable
     */
    void onViewError(Throwable throwable);

    /**
     * 绑定Android生命周期 防止RxJava内存泄漏
     *
     * @param <T>
     * @return
     */
    <T> AutoDisposeConverter<T> bindAutoDispose();
}
