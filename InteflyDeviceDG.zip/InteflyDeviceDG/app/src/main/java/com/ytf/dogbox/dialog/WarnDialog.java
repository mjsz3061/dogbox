package com.ytf.dogbox.dialog;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ytf.dogbox.R;

/**
 * author:tiwolf
 * create date:2023/12/1
 * Describe:
 */
public class WarnDialog {


    //急停页面需要一直停留在前端，直到将其重新拉起
    CustomDialog urgenDialog;
    AnimationDrawable animationDrawable;
    ImageView urgenIv;
    public void showUrgenDialog(Activity activity, Context context){
        View view=activity.getLayoutInflater().inflate(R.layout.dialog_urgen,null);
        if (urgenDialog==null)
            urgenDialog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
        urgenIv=urgenDialog.findViewById(R.id.urgen_iv);
        animationDrawable= (AnimationDrawable) urgenIv.getBackground();
        urgenDialog.show();
        urgenDialog.setCancelable(false);
        animationDrawable.start();
    }

    //急停页面消失
    public void dismissUrgenDialog(){
        if (animationDrawable!=null)
            animationDrawable.stop();
        if (urgenDialog!=null && urgenDialog.isShowing()){
            urgenDialog.dismiss();
        }
    }

    // 开门提醒
    CustomDialog doorDiglog;
    ImageView warnIv;
    AnimationDrawable animationDoor;
    public void showOpenDoorDialog(Activity activity, Context context, Bitmap bitmap,String warn){
        View view=activity.getLayoutInflater().inflate(R.layout.dialog_warn,null);
        if (doorDiglog==null)
            doorDiglog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
        warnIv=doorDiglog.findViewById(R.id.warn_iv);
        animationDoor= (AnimationDrawable) warnIv.getBackground();
        if (bitmap!=null){
            warnIv.setImageBitmap(bitmap);
        }

        doorDiglog.show();
        doorDiglog.setCancelable(false);
        animationDoor.start();
    }

    public void dismissOpenDoorDialog(){
        if (animationDoor!=null && animationDoor.isRunning()){
            animationDoor.stop();
        }

        if (doorDiglog!=null && doorDiglog.isShowing()){
            doorDiglog.dismiss();
        }

    }

    // 开门提醒
    CustomDialog doorCloseDiglog;
    ImageView doorCloseIv;
    TextView doorWarnTv;
    AnimationDrawable animationCloseDoor;
    public void showCloseDoorDialog(Activity activity, Context context, Bitmap bitmap,String warn){
        View view=activity.getLayoutInflater().inflate(R.layout.dialog_warn_closedoor,null);
        if(doorCloseDiglog==null){
            doorCloseDiglog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
        }
        doorCloseIv=doorCloseDiglog.findViewById(R.id.warn_close_iv);
        doorWarnTv=doorCloseDiglog.findViewById(R.id.door_tv);
        animationCloseDoor= (AnimationDrawable) doorCloseIv.getBackground();
        if (bitmap!=null){
            doorCloseIv.setImageBitmap(bitmap);
        }
        doorWarnTv.setText(warn);

        doorCloseDiglog.show();
        doorCloseDiglog.setCancelable(false);
        animationCloseDoor.start();
    }

    public void dismissCloseDoorDialog(){
        if (animationCloseDoor!=null && animationCloseDoor.isRunning()){
            animationCloseDoor.stop();
        }

        if (doorCloseDiglog!=null  && doorCloseDiglog.isShowing()){
            doorCloseDiglog.dismiss();
        }

    }

    // 消毒提醒
    CustomDialog disinfectantsDiglog;
    public void showDisinfectants(Activity activity, Context context){
        View view=activity.getLayoutInflater().inflate(R.layout.dialog_disinfectants,null);
        if (disinfectantsDiglog==null)
            disinfectantsDiglog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
        disinfectantsDiglog.show();
        disinfectantsDiglog.setCancelable(false);
    }

    public void dismissDisinfectantsDialog(){
        if (disinfectantsDiglog!=null){
            disinfectantsDiglog.dismiss();
        }

    }


}
