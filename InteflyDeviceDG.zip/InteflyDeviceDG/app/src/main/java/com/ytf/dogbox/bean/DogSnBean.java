package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2024/1/18
 * Describe:
 */
public class DogSnBean {

    private String sn;
    private long syncTime;

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public long getSyncTime() {
        return syncTime;
    }

    public void setSyncTime(long syncTime) {
        this.syncTime = syncTime;
    }
}
