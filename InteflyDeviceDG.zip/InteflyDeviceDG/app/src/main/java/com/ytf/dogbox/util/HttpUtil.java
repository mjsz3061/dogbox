package com.ytf.dogbox.util;


import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class HttpUtil {

    static boolean isFlag=true;
    //只需要ping api.intefly.cn就好了，另外一个地址不需要了。以免出现断断续续的情况
    public static final boolean ping(){
//        Log.e("tiwolf", "doClientConnection: mqtt设备ping服务器");
        String result=null;
        try {
            String ip="api.intefly.cn";

            Process p=Runtime.getRuntime().exec("ping -c 3 -w 100 "+ip);
//            Log.i("---ping---", "result content: "+stringBuffer.toString());
            //ping的状态
            int status=p.waitFor();
            if (status==0){
                result="success";
//                Log.e("TAG", "ping true: mqtt设备ping一次使用的时间="+(System.currentTimeMillis()-currentTime ));
                return true;
            }else {
                result="failed";
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            Log.i("---ping---", "result= "+result);
        }
//        Log.e("TAG", "ping: mqtt设备ping一次使用的时间="+(System.currentTimeMillis()-currentTime ));
        return false;
    }


    public static final boolean ping(String ipAddress){
        String result=null;
        try {
//            String ip="www.baidu.com";


            Process p=Runtime.getRuntime().exec("ping -c 3 -w 100 "+ipAddress);

//            Log.i("---ping---", "result content: "+stringBuffer.toString());
            //ping的状态
            int status=p.waitFor();
            if (status==0){
                result="success";
                return true;
            }else {
                result="failed";
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            Log.i("---ping---", "result= "+result);
        }
        return false;
    }

    static URL url=null;
    public static boolean isOnline(){
        InputStream stream = null;
        boolean isOnlineFlag=false;
        try {
            if (url==null){
                url = new URL("https://www.baidu.com");
            }
            stream = url.openStream();
            isOnlineFlag=true;
        }

        catch (Exception e) {
            e.printStackTrace();
            isOnlineFlag=false;
            Log.e("tiwolf", "isOnline: 是否能上网000"+isOnlineFlag);
        } finally {
            if (stream!=null){
                try {
                    stream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("tiwolf", "isOnline: 是否能上网111"+isOnlineFlag);
                }
                stream=null;
            }
        }
        Log.e("tiwolf", "isOnline: 是否能上网111"+isOnlineFlag);
        return isOnlineFlag;
    }

}
