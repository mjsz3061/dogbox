package com.ytf.dogbox.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ytf.dogbox.R;


public class CommandFragment extends Fragment {

    //是否可见
    private boolean isVisibleToUser;
    //是否初始化完成
    public boolean isInit = false;
    //全局的view
    private View view;

    private TextView quickWashTv,detailWashTv,shopTv;

    /*
     * 当前页面可见时和不可见的方法
     * */
//    @Override
//    public void setUserVisibleHint(boolean isVisibleToUser) {
//        super.setUserVisibleHint(isVisibleToUser);
//        this.isVisibleToUser = isVisibleToUser;
//        Log.e("TAG", "setUserVisibleHint: 命令Fragment1-显示数据====" );
//        setParam();
//    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       //1.创建View视图
        if (view==null){
            Log.e("TAG", "onCreateView: 命令Fragment1-显示数据" );
            view = inflater.inflate(R.layout.fragment_command,container,false);
            isInit=true;
            setParam();
        }
        Log.e("TAG", "onCreateView: 命令Fragment1-显示数据=========" );
        //2.返回view视图
        return  view ;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e("TAG", "onResume: 命令Fragment1-显示数据" );
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e("TAG", "onDestroyView: 命令Fragment1-停止显示" );
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("TAG", "onDestroy: 命令Fragment1-销毁控件" );
    }

    public void setButtonEnable(boolean flag){
        quickWashTv.setEnabled(flag);
        detailWashTv.setEnabled(flag);
    }

    //处理逻辑和网络请求等
    private void setParam() {
        Log.e("TAG", "setParam: 命令控件显示="+isInit+";显示1=" );
        if (isInit && quickWashTv==null) {
            quickWashTv=view.findViewById(R.id.quick_wash);
            detailWashTv=view.findViewById(R.id.detail_wash);
            shopTv=view.findViewById(R.id.shop);
            Log.e("tiwolf", "onCreateView: 命令Fragment1-创建ui" );
            quickWashTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (commandListener!=null){
                        commandListener.oneKeyWash();
                    }
                }
            });
            detailWashTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (commandListener!=null){
                        commandListener.detailWash();
                    }
                }
            });
            shopTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (commandListener!=null){
                        commandListener.dogShop();
                    }
                }
            });
        }
    }

    CommandListener commandListener;
    public void setCommandListener(CommandListener commandListener){
        this.commandListener=commandListener;
    }

    public interface CommandListener{
        void oneKeyWash();
        void detailWash();
        void dogShop();

    }




}
