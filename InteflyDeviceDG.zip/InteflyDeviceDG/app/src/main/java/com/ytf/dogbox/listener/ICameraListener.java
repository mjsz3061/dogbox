package com.ytf.dogbox.listener;


/**
 * @author tiwolf_li
 * @Date on 2021/8/17
 * @Description
 */
public interface ICameraListener {


    void setPictureParams(String picMd5, String date,int policeType);//报警使用，传送照片的md5和时间,报警的类型
    void setMp4Params(String mp4Md5, String mp4Name);//mp4名称，文件md5
    void isHasPic(boolean flag);//用来判断是否有图片数据
    void operationBack(String msg);//用来操作摄像头返回的数据
    void setPeopleDo(boolean flag);//设置是否是人为报警
    void setError(int code);//返回错误码
    void isCanCreateRecord(boolean flag);//是否能创建录制文件

    void setRecordPicture(String pictureName);//用于上传记录
}
