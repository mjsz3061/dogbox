package com.ytf.dogbox.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.ytf.dogbox.R;
import com.ytf.dogbox.adapter.FragAdapter;
import com.ytf.dogbox.util.Log;
import com.ytf.dogbox.view.MyViewpager;

import java.util.ArrayList;
import java.util.List;




/**
 * @author tiwolf_li
 * @Date on 2021/8/20
 * @Description 这部分主要是音频的部分界面，解决只用到部分界面的问题
 */
public class AvContentFragment extends Fragment{


    //todo 下面是没有分割前的
    private String TAG= AvContentFragment.class.getSimpleName();

    Context context;
    //播放音，视频
    private MyViewpager viewPager;

    //直接从activity获取语言，屏幕

    ImageFragment imageFragment;
    MusicFragment musicFragment;
    VideoFragment videoFragment;
    TextFragment textFragment;

    List<Fragment> fragments;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView=inflater.inflate(R.layout.fragment_viewpager,container,false);
        viewPager=rootView.findViewById(R.id.viewpager);

        //1.构造Fragment列表
        fragments = new ArrayList<Fragment>();
        imageFragment =new ImageFragment();
        musicFragment =new MusicFragment();
        videoFragment =new VideoFragment();
        textFragment =new TextFragment();
        //2.将前面定义的三个Fragment类对应的实例放入Fragment列表
        fragments.add(textFragment);
        fragments.add(imageFragment);

        fragments.add(videoFragment);
        fragments.add(musicFragment);
        //3.构造Fragment适配器
        FragAdapter adapter = new FragAdapter(getChildFragmentManager(),fragments);
        //4.创建ViewPager实例，并绑定适配器
        viewPager.setOffscreenPageLimit(fragments.size()-1);
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                Log.e(TAG, "onPageScrolled: 页面翻转" );
            }

            @Override
            public void onPageSelected(int position) {
                Log.e(TAG, "onPageScrolled: 页面选择="+position );
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                Log.e(TAG, "onPageScrolled: 页面变化" );
            }
        });


        return rootView;
    }

    public void showVideo(MediaPlayer mediaPlayer,String url){
        viewPager.setCurrentItem(2);
        videoFragment.setPlaySingleSv(mediaPlayer,url);
    }

    public void showMulVideo(MediaPlayer mediaPlayer,String url){
        viewPager.setCurrentItem(2);
        videoFragment.setPlaySv(mediaPlayer,url);
    }

    public void showMusic(){
        viewPager.setCurrentItem(3);
        musicFragment.setFly();
    }

    public void showImage(Bitmap bitmap){
        viewPager.setCurrentItem(1);
        imageFragment.setShowIv(bitmap);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {

        fragments.clear();
        fragments=null;
        super.onDestroy();
    }


}
