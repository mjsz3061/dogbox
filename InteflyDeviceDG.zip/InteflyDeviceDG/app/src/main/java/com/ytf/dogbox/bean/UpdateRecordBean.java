package com.ytf.dogbox.bean;

/**
 * @author tiwolf_li
 * @Date on 2021/3/12
 * @Description
 */
public class UpdateRecordBean {

//    vStringBuffer.append("rccontent varchar(200),");           //记录内容
//        vStringBuffer.append("updateType int,");                   //内容的类型，例如1表示增加mp4记录，2表示删除mp4记录
//        vStringBuffer.append("updateFlag int,");                    //待用
//        vStringBuffer.append("updateMsg varchar(20),");              //待用
//        vStringBuffer.append("updateMg varchar(20),");              //待用
//        vStringBuffer.append("dotime varchar(20))");               //时间戳
    //内容
    private String content;

    //内容的类型
    private int contentType;

    //待定
    private int updateFlag;

    //待定
    private String updateMsg;

    //待定
    private String updateMg;

    //第一次上传时间戳
    private String dotime;


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getContentType() {
        return contentType;
    }

    public void setContentType(int contentType) {
        this.contentType = contentType;
    }

    public int getUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(int updateFlag) {
        this.updateFlag = updateFlag;
    }

    public String getUpdateMsg() {
        return updateMsg;
    }

    public void setUpdateMsg(String updateMsg) {
        this.updateMsg = updateMsg;
    }

    public String getUpdateMg() {
        return updateMg;
    }

    public void setUpdateMg(String updateMg) {
        this.updateMg = updateMg;
    }

    public String getDotime() {
        return dotime;
    }

    public void setDotime(String dotime) {
        this.dotime = dotime;
    }

    public void clearNum(){
        content=null;
        contentType=0;
        updateFlag=0;
        updateMsg=null;
        updateMg=null;
        dotime=null;
    }
}
