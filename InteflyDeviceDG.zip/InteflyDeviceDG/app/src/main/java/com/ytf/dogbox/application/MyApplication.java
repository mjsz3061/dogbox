package com.ytf.dogbox.application;


import android.app.Application;
import android.content.Context;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.multidex.MultiDexApplication;

import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;
import com.ytf.dogbox.activity.CrashHandler;
import com.ytf.dogbox.activity.FlyUtil;
import com.ytf.dogbox.util.PreferenceUtil;


public class MyApplication extends MultiDexApplication {

    private static Context mContext;
//    public static final String clientId= Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?Build.getSerial():Build.SERIAL;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext=this;
        Logger.addLogAdapter(new AndroidLogAdapter());
        PreferenceUtil.init();
        System.setProperty("dexmaker.dexcache", this.getFilesDir().getAbsolutePath());


        String clientId= FlyUtil.getSn(mContext);
        Log.e("TAG", "onCreate: 获取到的sn为="+clientId );

        CrashHandler.getInstance().initCrashHandler();

//        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
//            @Override
//            public void uncaughtException(@NonNull Thread t, @NonNull Throwable e) {
//                //获取到异常则清除进程缓存
//                Log.e("tiwolf", "uncaughtException: app遭遇到未知错误，清除缓存，异常线程="+t.getName()+";异常线程id="+t.getId()+";异常信息："+e.getLocalizedMessage() );
//                Process.killProcess(Process.myPid());
//                try{
//                    System.exit(1);
//                }catch (Exception ex){
//                    ex.printStackTrace();
//                }
//
//            }
//        });

    }

    public static Context getContext(){
        return mContext;
    }
}
