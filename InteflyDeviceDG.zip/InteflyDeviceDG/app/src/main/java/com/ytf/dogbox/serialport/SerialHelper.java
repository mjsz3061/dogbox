package com.ytf.dogbox.serialport;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidParameterException;

import android_serialport_api.SerialPort;


/**
 * Created by tiwolf on 2017/1/17.
 */

public class SerialHelper {

    private static final String TAG=SerialHelper.class.getSimpleName();
    private SerialPort mSerialPort;
    private OutputStream mOutputStream;
    private InputStream mInputStream;
    private ReadThread mReadThread;
    private SendThread mSendThread;
    private String sPort="/dev/s3c2410_serial0";
    private int iBaudRate=9600;
    private boolean _isOpen=false;
    private byte[] _bLoopData=new byte[]{0x30};
    private int iDelay=500;
    //----------------------------------------------------
    public SerialHelper(String sPort, int iBaudRate){
        this.sPort = sPort;
        this.iBaudRate=iBaudRate;
    }
    public SerialHelper(){
        this("/dev/ttyS4",9600);
    }
    public SerialHelper(String sPort){
        this(sPort,9600);
    }
    public SerialHelper(String sPort, String sBaudRate){
        this(sPort,Integer.parseInt(sBaudRate));
    }
    //----------------------------------------------------
    public void open() throws SecurityException, IOException,InvalidParameterException {
        Log.e(TAG, "open: 打开了串口");
        mSerialPort =  new SerialPort(new File(sPort), iBaudRate, 0);
        mOutputStream = mSerialPort.getOutputStream();
        mInputStream = mSerialPort.getInputStream();
        mReadThread = new ReadThread();
        mReadThread.start();
        mSendThread = new SendThread();
        mSendThread.setSuspendFlag();
        mSendThread.start();
        _isOpen=true;
    }
    //----------------------------------------------------
    public void close(){
        if (mReadThread != null)
            mReadThread.interrupt();
        if (mSerialPort != null) {
            mSerialPort.close();
            mSerialPort = null;
        }
        _isOpen=false;
    }
    //----------------------------------------------------
    public synchronized void send(byte[] bOutArray){
        try
        {
            Log.e("TAG", "sendPortData: 下发指令 下发byte开关是否打开="+_isOpen );
            if(_isOpen){
                mOutputStream.write(bOutArray);
//                mOutputStream.flush();
            }else {
                openSerial();
                mOutputStream.write(bOutArray);
            }

        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * 串口打开方法
     */
    public void openSerial() {
        try {
            open();
            Log.i(TAG, "打开串口成功！");
        } catch (SecurityException e) {
            e.printStackTrace();
            Log.e(TAG, "打开串口失败:没有串口读/写权限!");
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "打开串口失败:未知错误!");
        } catch (InvalidParameterException e) {
            e.printStackTrace();
            Log.e(TAG, "打开串口失败:参数错误!");
        } catch (Exception e) {
            Log.e(TAG, "openComPort: 其他错误");
            e.printStackTrace();
        }
    }
    //----------------------------------------------------
    public void sendHex(String sHex){
        byte[] bOutArray = MyFunc.HexToByteArr(sHex);
        send(bOutArray);
    }
    //----------------------------------------------------
    public void sendTxt(String sTxt){
        byte[] bOutArray =sTxt.getBytes();
        send(bOutArray);
    }
    //----------------------------------------------------
    private class ReadThread extends Thread {
        @Override
        public void run() {
            super.run();
            while(!isInterrupted()) {
                try
                {
                    if (mInputStream == null) return;
                    byte[] buffer=new byte[512];
                    int size = mInputStream.read(buffer);
                    if (size > 0){
                        ComBean comRecData = new ComBean(sPort,buffer,size);
                        onSerialPortReceivedListener.onSerialPortDataReceived(comRecData);
                    }

                    Thread.sleep(50);

                } catch (Throwable e) {
                    e.printStackTrace();
                    return;
                }
            }
        }
    }
    //----------------------------------------------------
    private class SendThread extends Thread{
        public boolean suspendFlag = true;
        @Override
        public void run() {
            super.run();
            while(!isInterrupted()) {
                synchronized (this)
                {
                    while (suspendFlag)
                    {
                        try
                        {
                            wait();
                        } catch (InterruptedException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                send(getbLoopData());
                try
                {
                    Thread.sleep(iDelay);
                } catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
            }
        }

        //
        public void setSuspendFlag() {
            this.suspendFlag = true;
        }

        public synchronized void setResume() {
            this.suspendFlag = false;
            notify();
        }
    }
    //----------------------------------------------------
    public int getBaudRate()
    {
        return iBaudRate;
    }
    public boolean setBaudRate(int iBaud)
    {
        if (_isOpen)
        {
            return false;
        } else
        {
            iBaudRate = iBaud;
            return true;
        }
    }
    public boolean setBaudRate(String sBaud)
    {
        int iBaud = Integer.parseInt(sBaud);
        return setBaudRate(iBaud);
    }
    //----------------------------------------------------
    public String getPort()
    {
        return sPort;
    }
    public boolean setPort(String sPort)
    {
        if (_isOpen)
        {
            return false;
        } else
        {
            this.sPort = sPort;
            return true;
        }
    }
    //----------------------------------------------------
    public boolean isOpen()
    {
        return _isOpen;
    }
    //----------------------------------------------------
    public byte[] getbLoopData()
    {
        return _bLoopData;
    }
    //----------------------------------------------------
    public void setbLoopData(byte[] bLoopData)
    {
        this._bLoopData = bLoopData;
    }
    //----------------------------------------------------
    public void setTxtLoopData(String sTxt){
        this._bLoopData = sTxt.getBytes();
    }
    //----------------------------------------------------
    public void setHexLoopData(String sHex){
        this._bLoopData = MyFunc.HexToByteArr(sHex);
    }
    //----------------------------------------------------
    public int getiDelay()
    {
        return iDelay;
    }
    //----------------------------------------------------
    public void setiDelay(int iDelay)
    {
        this.iDelay = iDelay;
    }
    //----------------------------------------------------
    public void startSend()
    {
        if (mSendThread != null)
        {
            mSendThread.setResume();
        }
    }
    //----------------------------------------------------
    public void stopSend()
    {
        if (mSendThread != null)
        {
            mSendThread.setSuspendFlag();
        }
    }
    //----------------------------------------------------
//    protected abstract void onDataReceived(ComBean ComRecData);
    private OnSerialPortReceivedListener onSerialPortReceivedListener;
    public void setSerialPortReceivedListener(OnSerialPortReceivedListener onSerialPortReceivedListener) {
        this.onSerialPortReceivedListener = onSerialPortReceivedListener;
    }

    /**
     * 实现串口数据的接收监听
     */
    public interface OnSerialPortReceivedListener {
        /**
         * 串口接收到数据后的回调
         *
         * @param comRecData 接收到的数据类
         */
        void onSerialPortDataReceived(ComBean comRecData);
    }
}
