package com.ytf.dogbox.fragment;
 
import android.graphics.Outline;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ytf.dogbox.R;
import com.ytf.dogbox.util.Log;

import java.io.IOException;



public class VideoFragment extends Fragment implements SurfaceHolder.Callback {

    SurfaceView playSv;

    //是否可见
    private boolean isVisibleToUser;
    //是否初始化完成
    public boolean isInit = false;
    //全局的view
    private View view;

    SurfaceHolder holder;
    MediaPlayer mediaPlayer;

    private boolean isFocusCloseFlag=false;



    /*
     * 当前页面可见时和不可见的方法
     * */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        this.isVisibleToUser = isVisibleToUser;
//        setParam();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.i("TAG", "onCreateView: VideoFragment-这个界面开始创建" );
        //1.创建View视图
        if (view==null){
            view = inflater.inflate(R.layout.fragment_vedio,container,false);
            Log.i("TAG", "onCreateView: VideoFragment-这个界面开始创建playSv="+playSv+";isInit="+isInit+";isVisibleToUser="+isVisibleToUser );
            isInit=true;
            setParam();
        }

        return  view;
    }

    /**
     * 设置Surfaceviewl圆角
     */
    private void setSurfaceviewCorner(final float radius) {
        playSv.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                Rect rect = new Rect();
                view.getGlobalVisibleRect(rect);
                int leftMargin = 0;
                int topMargin = 0;
                Rect selfRect = new Rect(leftMargin, topMargin, rect.right - rect.left - leftMargin, rect.bottom - rect.top - topMargin);
                outline.setRoundRect(selfRect, radius);
            }
        });
        playSv.setClipToOutline(true);
    }


    @Override
    public void onResume() {
        super.onResume();
        Log.i("TAG", "onResume: VideoFragment-显示数据" );
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.i("TAG", "onDestroyView: VideoFragment-停止显示" );
    }

    @Override
    public void onDestroy() {
        Log.i("TAG", "onDestroy: VideoFragment-销毁控件" );
        // todo mediaPlayer控件不能放在这里，会出现Caused by: java.lang.IllegalStateException,所以只能放到CombinationFunctionActivity上面进行关闭
//        mediaPlayer.setDisplay(null);
//        if (mediaPlayer!=null){
//            if (mediaPlayer.isPlaying()){
//                mediaPlayer.stop();
//                mediaPlayer.reset();
//            }
//        }
        this.holder=null;
        super.onDestroy();

    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.i("TAG", "onDetach: VideoFragment" );
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        Log.i("TAG", "surfaceCreated: VideoFragment-创建了视频控件");
        this.holder=holder;
        if (mediaPlayer!=null){
            mediaPlayer.setDisplay(holder);
            if (!mediaPlayer.isPlaying() && isFocusCloseFlag){
                mediaPlayer.start();
            }
        }
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {
        Log.i("TAG", "surfaceChanged: VideoFragment-视频尺寸发生改变");
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
        Log.i("TAG", "surfaceDestroyed: VideoFragment-视频控件销毁");
        mediaPlayer.setDisplay(null);
        if (mediaPlayer!=null){
            if (mediaPlayer.isPlaying()){
                mediaPlayer.stop();
                isFocusCloseFlag=true;
//                mediaPlayer.reset();
            }
        }
        this.holder=null;
    }

    //处理逻辑和网络请求等
    private void setParam() {
        Log.i("tiwolf", "onCreateView: VideoFragment-当界面可见的时候-创建ui" );
        if (isInit && playSv==null) {

            playSv=view.findViewById(R.id.mySurface);
            playSv.setZOrderOnTop(false);
            playSv.getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
            playSv.getHolder().addCallback(this);
            Log.i("tiwolf", "onCreateView: VideoFragment-创建ui" );
            setSurfaceviewCorner(8);
        }
    }

    public synchronized int setPlaySv(MediaPlayer player,String file){
        Log.i("TAG", "setPlaySv: VideoFragment-开始准备播放视频" );
        if (holder!=null){
            Log.i("TAG", "setPlaySv: VideoFragment-开始准备播放视频,多视频设置了屏幕预览" );
            player.setDisplay(holder);
        }
        this.mediaPlayer=player;
        try {
            if (player.isPlaying()){
                player.stop();
                player.reset();
            }else{
                player.reset();
            }
            Thread.sleep(100);
            player.setDataSource(file);
            player.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        } catch (InterruptedException e) {
            e.printStackTrace();
            return -1;
        }

        return 0;
    }

    public synchronized int setPlaySingleSv(MediaPlayer player,String file){
        setParam();
        Log.i("TAG", "setPlaySv: 开始准备播放视频,url="+file );
        if (holder!=null){
            Log.i("TAG", "setPlaySv: VideoFragment-开始准备播放视频,设置了屏幕预览" );
            player.setDisplay(holder);
        }
        this.mediaPlayer=player;
        try {
            if (player.isPlaying()){
                player.stop();
                player.reset();
            }else{
                player.reset();
            }
            player.setDataSource(file);
            player.prepareAsync();
            player.setLooping(true);
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }

        return 0;
    }
}