package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/11/28
 * Describe:
 */
public class RefundParamBean {

    private double amout;
    private String orderNo;
    private String tradeNo;

    public double getAmout() {
        return amout;
    }

    public void setAmout(double amout) {
        this.amout = amout;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }
}
