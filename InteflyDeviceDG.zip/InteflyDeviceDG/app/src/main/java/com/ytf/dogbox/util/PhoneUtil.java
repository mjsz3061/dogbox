package com.ytf.dogbox.util;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Build;
import android.telephony.CellSignalStrength;
import android.telephony.CellSignalStrengthCdma;
import android.telephony.CellSignalStrengthGsm;
import android.telephony.CellSignalStrengthLte;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.RequiresApi;

import java.lang.reflect.Method;
import java.util.List;

/**
 * author:tiwolf
 * create date:2023/12/8
 * Describe:
 */
public class PhoneUtil {


    //判断是否有SIM卡
    public static boolean hasSimCard(Context context) {
        TelephonyManager telMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        int simState = telMgr.getSimState();
        boolean result = true;
        switch (simState) {
            case TelephonyManager.SIM_STATE_ABSENT:
            case TelephonyManager.SIM_STATE_UNKNOWN: {
                result = false;//没有SIM卡
                break;
            }//SIM卡认不出来

        }
        Log.i("TAG", "isConnectIsNormal: " + (result ? "有卡" : "无卡"));
        return result;
    }

    //隐藏底部虚拟
    public static void hideDownBar(Activity context) {
        Window _window = context.getWindow();
        WindowManager.LayoutParams params = _window.getAttributes();
        params.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE;
        _window.setAttributes(params);
    }

    /**
     * 获取手机信号强度，需添加权限 android.permission.ACCESS_COARSE_LOCATION <br>
     * API要求不低于17 <br>
     *
     * @return 当前手机主卡信号强度, 单位 dBm（-1是默认值，表示获取失败）
     */
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public static int getMobileDbm(SignalStrength signalStrength, TelephonyManager telephonyManager) {
        int dbm = -1;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            List<CellSignalStrength> cellSignalStrengths = signalStrength.getCellSignalStrengths();
            if (null!=cellSignalStrengths){
                for (CellSignalStrength cellSignalStrength:cellSignalStrengths){
                    if (cellSignalStrength instanceof CellSignalStrengthGsm){
                        android.util.Log.e("tiwolf", "getMobileDbm: Gsm 信号强度为="+cellSignalStrength.getDbm() );
                        if (telephonyManager.getNetworkType()==TelephonyManager.NETWORK_TYPE_GSM){
                            dbm= cellSignalStrength.getDbm();
                        }
                    }else if (cellSignalStrength instanceof CellSignalStrengthLte){
                        android.util.Log.e("tiwolf", "getMobileDbm: Lte 信号强度为="+cellSignalStrength.getDbm() );
                        if (telephonyManager.getNetworkType()==TelephonyManager.NETWORK_TYPE_LTE){
                            dbm= cellSignalStrength.getDbm();
                        }
                    }else if (cellSignalStrength instanceof CellSignalStrengthCdma){
                        android.util.Log.e("tiwolf", "getMobileDbm: Cdma 信号强度为="+cellSignalStrength.getDbm() );
                        if (telephonyManager.getNetworkType()==TelephonyManager.NETWORK_TYPE_CDMA){
                            dbm= cellSignalStrength.getDbm();
                        }
                    }

                }
            }
        }
        return dbm;
    }

    /***
     * 判断移动数据是否开启
     * @param context
     * @return
     */
    public static boolean isMobileEnableReflex(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            Method getMobileDataEnabledMethod = ConnectivityManager.class.getDeclaredMethod("getMobileDataEnabled");
            getMobileDataEnabledMethod.setAccessible(true);
            return (Boolean) getMobileDataEnabledMethod.invoke(connectivityManager);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @param telephonyManager  13为LTE，16为GSM，4为CDMA
     * @return
     */
    public static int getSignalType(TelephonyManager telephonyManager){
        if (telephonyManager.getNetworkType()==TelephonyManager.NETWORK_TYPE_LTE){
            return TelephonyManager.NETWORK_TYPE_LTE;
        }else if (telephonyManager.getNetworkType()==TelephonyManager.NETWORK_TYPE_CDMA){
            return TelephonyManager.NETWORK_TYPE_CDMA;
        }else if (telephonyManager.getNetworkType()==TelephonyManager.NETWORK_TYPE_GSM){
            return TelephonyManager.NETWORK_TYPE_GSM;
        }
        return TelephonyManager.NETWORK_TYPE_UNKNOWN;
    }
}
