package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2024/1/15
 * Describe:用于保存洗狗机的配置数据
 */
public class DogConfigBean {

//    sn
//    upTemp( 环境温度上限), downTemp(环境温度下限)
//    upWaterTemp(水温上限),downWaterTemp(水温下限)
//    firstWashTime(第一次清水时间),soapTime(沐浴露阶段时间),
//    soapUseTime(沐浴露喷出时间),
//    secondWashTime(第二次清水时间),
//    conditionerTime(护毛素阶段时间),
//    conditionerUseTime(喷护毛素时间),
//    thirdWashTime(第三次清水时间),
//    preHotTime(加热丝预热时间),
//    dryTime(烘干时间),
//    disinfectTime(消毒喷洗时间),
//    airExchangeTime(换风机时间)
//    fourthWashTime(第四次清水时间),
//    stepTime(步骤间隔时间),
//    phone(手机号码),
//    quickWashPrice(一键速洗价格)
//    highWashPrice(高端精洗价格)
//    smallMultiple(小型犬),
//    middleMultiple(中型犬),
//    largeMultiple(大型犬),
//    shortHairMultiple(短毛)
//    normalMultiple(一般)
//    longHairMultiple(长毛)
//    sparseMultiple(稀疏)
//    thickNormalMultiple(一般)
//    denseMultiple(浓密)
//    dryMultiple(烘干)
//    dryWashMultiple(洗澡+烘干)
//    upTime(上传时间)

    private String sn;
    private double upTemp;
    private double downTemp;
    private double upWaterTemp;
    private double downWaterTemp;
    private int firstWashTime;
    private int soapTime;
    private int soapUseTime;
    private int secondWashTime;
    private int conditionerTime;
    private int conditionerUseTime;
    private int thirdWashTime;
    private int preHotTime;
    private int dryTime;
    private int disinfectTime;
    private int airExchangeTime;
    private int fourthWashTime;
    private int stepTime;
    private String phone;
    private double quickWashPrice;
    private double highWashPrice;
    private double smallMultiple;
    private double middleMultiple;
    private double largeMultiple;
    private double shortHairMultiple;
    private double normalMultiple;
    private double longHairMultiple;
    private double sparseMultiple;
    private double thickNormalMultiple;
    private double denseMultiple;
    private double dryMultiple;
    private double dryWashMultiple;
    private String upTime;

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public double getUpTemp() {
        return upTemp;
    }

    public void setUpTemp(double upTemp) {
        this.upTemp = upTemp;
    }

    public double getDownTemp() {
        return downTemp;
    }

    public void setDownTemp(double downTemp) {
        this.downTemp = downTemp;
    }

    public double getUpWaterTemp() {
        return upWaterTemp;
    }

    public void setUpWaterTemp(double upWaterTemp) {
        this.upWaterTemp = upWaterTemp;
    }

    public double getDownWaterTemp() {
        return downWaterTemp;
    }

    public void setDownWaterTemp(double downWaterTemp) {
        this.downWaterTemp = downWaterTemp;
    }

    public int getFirstWashTime() {
        return firstWashTime;
    }

    public void setFirstWashTime(int firstWashTime) {
        this.firstWashTime = firstWashTime;
    }

    public int getSoapUseTime() {
        return soapUseTime;
    }

    public void setSoapUseTime(int soapUseTime) {
        this.soapUseTime = soapUseTime;
    }

    public int getSecondWashTime() {
        return secondWashTime;
    }

    public void setSecondWashTime(int secondWashTime) {
        this.secondWashTime = secondWashTime;
    }

    public int getConditionerTime() {
        return conditionerTime;
    }

    public void setConditionerTime(int conditionerTime) {
        this.conditionerTime = conditionerTime;
    }

    public int getConditionerUseTime() {
        return conditionerUseTime;
    }

    public void setConditionerUseTime(int conditionerUseTime) {
        this.conditionerUseTime = conditionerUseTime;
    }

    public int getThirdWashTime() {
        return thirdWashTime;
    }

    public void setThirdWashTime(int thirdWashTime) {
        this.thirdWashTime = thirdWashTime;
    }

    public int getPreHotTime() {
        return preHotTime;
    }

    public void setPreHotTime(int preHotTime) {
        this.preHotTime = preHotTime;
    }

    public int getDryTime() {
        return dryTime;
    }

    public void setDryTime(int dryTime) {
        this.dryTime = dryTime;
    }

    public int getDisinfectTime() {
        return disinfectTime;
    }

    public void setDisinfectTime(int disinfectTime) {
        this.disinfectTime = disinfectTime;
    }

    public int getAirExchangeTime() {
        return airExchangeTime;
    }

    public void setAirExchangeTime(int airExchangeTime) {
        this.airExchangeTime = airExchangeTime;
    }

    public int getFourthWashTime() {
        return fourthWashTime;
    }

    public void setFourthWashTime(int fourthWashTime) {
        this.fourthWashTime = fourthWashTime;
    }

    public int getStepTime() {
        return stepTime;
    }

    public void setStepTime(int stepTime) {
        this.stepTime = stepTime;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }



    public String getUpTime() {
        return upTime;
    }

    public void setUpTime(String upTime) {
        this.upTime = upTime;
    }

    public double getQuickWashPrice() {
        return quickWashPrice;
    }

    public void setQuickWashPrice(double quickWashPrice) {
        this.quickWashPrice = quickWashPrice;
    }

    public double getHighWashPrice() {
        return highWashPrice;
    }

    public void setHighWashPrice(double highWashPrice) {
        this.highWashPrice = highWashPrice;
    }

    public double getSmallMultiple() {
        return smallMultiple;
    }

    public void setSmallMultiple(double smallMultiple) {
        this.smallMultiple = smallMultiple;
    }

    public double getMiddleMultiple() {
        return middleMultiple;
    }

    public void setMiddleMultiple(double middleMultiple) {
        this.middleMultiple = middleMultiple;
    }

    public double getLargeMultiple() {
        return largeMultiple;
    }

    public void setLargeMultiple(double largeMultiple) {
        this.largeMultiple = largeMultiple;
    }

    public double getShortHairMultiple() {
        return shortHairMultiple;
    }

    public void setShortHairMultiple(double shortHairMultiple) {
        this.shortHairMultiple = shortHairMultiple;
    }

    public double getNormalMultiple() {
        return normalMultiple;
    }

    public void setNormalMultiple(double normalMultiple) {
        this.normalMultiple = normalMultiple;
    }

    public double getLongHairMultiple() {
        return longHairMultiple;
    }

    public void setLongHairMultiple(double longHairMultiple) {
        this.longHairMultiple = longHairMultiple;
    }

    public double getSparseMultiple() {
        return sparseMultiple;
    }

    public void setSparseMultiple(double sparseMultiple) {
        this.sparseMultiple = sparseMultiple;
    }

    public double getThickNormalMultiple() {
        return thickNormalMultiple;
    }

    public void setThickNormalMultiple(double thickNormalMultiple) {
        this.thickNormalMultiple = thickNormalMultiple;
    }

    public double getDenseMultiple() {
        return denseMultiple;
    }

    public void setDenseMultiple(double denseMultiple) {
        this.denseMultiple = denseMultiple;
    }

    public double getDryMultiple() {
        return dryMultiple;
    }

    public void setDryMultiple(double dryMultiple) {
        this.dryMultiple = dryMultiple;
    }

    public double getDryWashMultiple() {
        return dryWashMultiple;
    }

    public void setDryWashMultiple(double dryWashMultiple) {
        this.dryWashMultiple = dryWashMultiple;
    }

    public int getSoapTime() {
        return soapTime;
    }

    public void setSoapTime(int soapTime) {
        this.soapTime = soapTime;
    }
}
