package com.ytf.dogbox.dogHttp;

import com.ytf.dogbox.bean.AdvertBean;
import com.ytf.dogbox.bean.AlarmBean;
import com.ytf.dogbox.bean.CheckMsgBean;
import com.ytf.dogbox.bean.DogAlarmBean;
import com.ytf.dogbox.bean.DogExceBean;
import com.ytf.dogbox.bean.DogHttpKeyBean;
import com.ytf.dogbox.bean.DogSnBean;
import com.ytf.dogbox.bean.DogSyncConfigBean;
import com.ytf.dogbox.bean.DogTonkenBean;
import com.ytf.dogbox.bean.ErrorBean;
import com.ytf.dogbox.bean.HttpPayBean;
import com.ytf.dogbox.bean.KeyMsgBean;
import com.ytf.dogbox.bean.RefundBean;
import com.ytf.dogbox.bean.PayBean;
import com.ytf.dogbox.bean.QiniuMsgBean;
import com.ytf.dogbox.bean.RefundParamBean;
import com.ytf.dogbox.bean.UpLoadGetBean;
import com.ytf.dogbox.bean.UpLoadGetSubBean;

import java.util.List;
import java.util.Map;


import io.reactivex.Flowable;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

/**
 * @author tiwolf_li
 * @Date on 2020/6/24
 * @Description
 */
public interface DogApiService {

    //分片秒传验证

//    @GET("/user/system/config/bypass")
//    Flowable<UpLoadGetBean<CountBean>> getCount();
//    @GET("file/bigfile/chunk/check")
//    Flowable<UpLoadGetBean<UpLoadGetSubBean>> getCheck(@QueryMap Map<String, String> map);

    //获取七牛云的文件上传地址
    @GET("file/cloud/upload")
    Flowable<QiniuMsgBean> getQiniuKey(@QueryMap Map<String, Object> map);

    @GET("file/cloud/download")
    Flowable<KeyMsgBean> getQiniuDownloadUrl(@QueryMap Map<String,Object> map);
    //上传报警信息
    @POST("/device/alarm/report")
    Flowable<KeyMsgBean> getUpdatePolice(@Body Map<String,String> map);
    @POST("/device/terminalVideo/add")
    Flowable<KeyMsgBean> updateRecordMsg(@Body Map<String,Object> map);

    @POST("/device/terminalVideo/delete")
    Flowable<KeyMsgBean> delRecordMsg(@Body Map<String,Object> map);

    @GET("file/bigfile/chunk/merge")
    Flowable<UpLoadGetBean<UpLoadGetSubBean>> getMerge(@QueryMap Map<String, String> map);

    @POST("/device/deviceTrouble/add")
    Flowable<UpLoadGetBean<ErrorBean>> upSendError(@Body Map<String,String> map); //故障异常

    @POST("/ota/version/inquiry")
    Flowable<UpLoadGetBean<CheckMsgBean>> updateMsg(@Body Map<String,Object> map);


    @POST("/wash/openThird/applyToken")
    Flowable<UpLoadGetBean<DogTonkenBean>> getHttpKey(@Body DogHttpKeyBean dogHttpKeyBean);
    //获取下载秘钥
    @POST("/ota/token/fetch")
    Flowable<KeyMsgBean> getUpdateKey(@Body Map<String,Object> map);

    @POST("/wash/pay/huaPingPay")
    Flowable<UpLoadGetBean<PayBean>> orderPay(@Body HttpPayBean httpPayBean);

    @POST("/wash/pay/refund")
    Flowable<UpLoadGetBean<RefundBean>> refundPay(@Body RefundParamBean refundParamBean);

    @POST("/wash/exce/uploadExcption")
    Flowable<KeyMsgBean> upLoadDogException(@Body DogExceBean dogExceBean);

    @POST("/wash/deviceAlarm/add")
    Flowable<KeyMsgBean> upLoadAlarmWarning(@Body DogAlarmBean dogAlarmBean);

    @POST("/wash/config/syncData")
    Flowable<UpLoadGetBean<DogSyncConfigBean>> syncConfigData(@Body DogSnBean dogSnBean);

    @POST("/device/sync/devicedata/advert")
    Flowable<UpLoadGetBean<AdvertBean<List<AlarmBean>>>>  getDeviceDataAdvert(@Body Map<String,String> map); //同步广告
}
