package com.ytf.dogbox.qiniu;

import android.content.Context;

import com.qiniu.http.Response;
import com.qiniu.qvs.NameSpaceManager;
import com.qiniu.qvs.StreamManager;
import com.qiniu.qvs.model.StaticLiveRoute;
import com.qiniu.qvs.model.Stream;
import com.qiniu.util.Auth;
import com.qiniu.util.StringMap;
import com.ytf.dogbox.activity.FlyUtil;
import com.ytf.dogbox.util.HttpUtil;
import com.ytf.dogbox.util.Log;
import com.ytf.dogbox.util.PreferenceUtil;


/**
 * @author tiwolf_li
 * @Date on 2021/4/26
 * @Description
 */
public class QiNiuUtil {

    public static Auth getAuth(String accessKey,String secretKey){
        Log.e("tiwolf", "receiveWork: 七牛云创建流" );
        return Auth.create(accessKey, secretKey);
    }

    public static String getRtmpUrl(boolean qiniuFlag, String accessKey, String secretKey, Context context){
        if (!HttpUtil.ping("qvs-publish.stream.intefly.cn")){
            return null;
        }
        Auth auth=getAuth(accessKey,secretKey);
        NameSpaceManager nameSpaceManager = new NameSpaceManager(auth);
        StreamManager streamManager = new StreamManager(auth);
        StaticLiveRoute staticLiveRoute = new StaticLiveRoute("qvs-publish.stream.intefly.cn", "publishRtmp");
        Stream stream=new Stream(FlyUtil.getSn(context));

        if (!qiniuFlag){
            try {
                streamManager.createStream("2xenzwci8d1zt",stream);
                PreferenceUtil.commitBoolean(PreferenceUtil.QINIUROOM,true);
            } catch (Exception e) {
                Log.e("tiwolf", "receiveWork: 七牛云错误代码---"+e.getMessage() );
                e.printStackTrace();
            }
        }

        try {
            Response response=streamManager.staticPublishPlayURL("2xenzwci8d1zt",stream.getStreamID(),staticLiveRoute);
            StringMap stringMap = response.jsonToMap();
            String publishStr= (String) stringMap.get("publishUrl");
            Log.e("tiwolf", "receiveWork:七牛云获取到数据 "+response.address+";"+response.bodyString()+";推流地址="+publishStr);
//            Log.e("tiwolf", "receiveWork: 七牛云的推流地址==="+publishStr );
            return publishStr;
        } catch (Exception e) {
            Log.e("tiwolf", "receiveWork: 七牛云错误代码1111---"+e.getMessage() );
            e.printStackTrace();
            return null;
        }
    }


    public static String getHistoryRtmpUrl(boolean qiniuFlag,String accessKey,String secretKey,String room){
        if (!HttpUtil.ping("qvs-publish.stream.intefly.cn")){
            return null;
        }
        Auth auth=getAuth(accessKey,secretKey);
        NameSpaceManager nameSpaceManager = new NameSpaceManager(auth);
        StreamManager streamManager = new StreamManager(auth);
        StaticLiveRoute staticLiveRoute = new StaticLiveRoute("qvs-publish.stream.intefly.cn", "publishRtmp");
        Stream stream=new Stream(room);

        if (!qiniuFlag){
            try {
                streamManager.createStream("2xenzwci8d1zt",stream);
            } catch (Exception e) {
                Log.e("tiwolf", "receiveWork: 七牛云错误代码---"+e.getMessage() );
                e.printStackTrace();
            }
        }

        try {
            Response response=streamManager.staticPublishPlayURL("2xenzwci8d1zt",stream.getStreamID(),staticLiveRoute);
            StringMap stringMap = response.jsonToMap();
            String publishStr= (String) stringMap.get("publishUrl");
            Log.e("tiiwolf", "receiveWork:七牛云获取到数据 "+response.address+";"+response.bodyString());
            Log.e("tiwolf", "receiveWork: 七牛云的推流地址==="+publishStr );
            return publishStr;
        } catch (Exception e) {
            Log.e("tiwolf", "receiveWork: 七牛云错误代码1111---"+e.getMessage() );
            e.printStackTrace();
            return null;
        }
    }

}
