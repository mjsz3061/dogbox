package com.ytf.dogbox.bean;

import java.util.List;

/**
 * author:tiwolf
 * create date:2023/12/14
 * Describe:
 */
public class DogPriceBean {


    private long createTime;
    private int id;
    private List<PetTypeListDTO> petTypeList;
    private double price;
    private String typeName;
    private String washType;
    private String updateTime;//操作时间

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<PetTypeListDTO> getPetTypeList() {
        return petTypeList;
    }

    public void setPetTypeList(List<PetTypeListDTO> petTypeList) {
        this.petTypeList = petTypeList;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getWashType() {
        return washType;
    }

    public void setWashType(String washType) {
        this.washType = washType;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public static class PetTypeListDTO {
        private String createTime;//服务器使用的时间
        private int id;
        private double multiple;
        private String petFeature;
        private String petName;
        private String petType;
        private int washTypeId;

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public double getMultiple() {
            return multiple;
        }

        public void setMultiple(double multiple) {
            this.multiple = multiple;
        }

        public String getPetFeature() {
            return petFeature;
        }

        public void setPetFeature(String petFeature) {
            this.petFeature = petFeature;
        }

        public String getPetName() {
            return petName;
        }

        public void setPetName(String petName) {
            this.petName = petName;
        }

        public String getPetType() {
            return petType;
        }

        public void setPetType(String petType) {
            this.petType = petType;
        }

        public int getWashTypeId() {
            return washTypeId;
        }

        public void setWashTypeId(int washTypeId) {
            this.washTypeId = washTypeId;
        }

    }
}
