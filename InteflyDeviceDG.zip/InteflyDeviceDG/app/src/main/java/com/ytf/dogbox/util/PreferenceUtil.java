package com.ytf.dogbox.util;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.ytf.dogbox.application.MyApplication;


/**
 * @author tiwolf_li
 * @Date on 2020/6/24
 * @Description
 */
public class PreferenceUtil {

    public static String KEY="key"; //获取app下载包的密钥
    public static String BOARDKEY="boardkey";//获取固件下载包的密钥
    public static String DEVICESN="deviceSn";
    public static String LANGUAGE="language";
    public static String SYNCAD="syncad";//保存普通广告的操作时间
    public static String date="2021-01-17 15:54:06";//默认的一个时间
    public static String ALARMSIZE="alarmSize";
    public static String ALARMAVSIZE="alarmAvSize";
    public static String RESPONSEFLAG="responseflag";//应答标志
    public static String ALARMLIVESIZE="alarmLiveSize";//直播的列表
    public static String LIVEFLAG="liveFlag";//直播标志
    public static String SDCARDERRORFLAG="sdcardErrorFlag";//sdcard错误标志
    public static String PACKAGEFLAG="packageflag";//包裹是否在下载中
    public static String LENGTH="length";
    public static String BOARDLENGTH="boardlength";//固件下载长度
    public static String UPVERSION="upversion";//版本升级
    public static String BOARDVERSION="boardversion";//固件版本升级
    public static String VERSION="version"; //版本
    public static String WIFIFLAG="wifiFlag";//打开wifi开关，主要用于wifi直连设置wifi账号和密码，断电重连之后，跳过4G直接开启wifi开关
    public static String WIFISWITCH="wifiSwitch";
    public static String WIFINAME="wifiName";
    public static String WIFIPW="wifiPw";
    public static String WIFITYPE="wifitype";
    public static String APSWITCH="ApSwitch";
    public static String APNAME="ApName";
    public static String APPW="ApPw";
    public static String APTYPE="Aptype";
    public static String GPSLATLNG="gpslatlng";
    public static String SYNCLIVE="synclive";//保存直播的操作时间
    public static String QINIUROOM="qiniuroom";//是否创建了七牛云房间
    public static String DOGTOKEN="dogToken";//洗狗机token
    /**============配置item价格存储==============*/
    public static String DOGCONFIGTIME="dogConfigTime";
    public static String ONEDOGPRICETIME="oneDogPriceTime";//一键洗狗的下发时间，用来同步相关
    public static String ONEWASHPRICE="oneWashPrice";//一键洗澡的价格
    public static String DETAILDOGPRICETIME="detailDogPriceTime";//高端洗狗的下发时间，用来同步相关
    public static String DETAILWASHPRICE="detailWashPrice";//高端洗澡的基础价格
    public static String SMALLDOG="smallDog";   //小狗价格
    public static String MIDDOG="midDog";       //中狗价格
    public static String BIGDOG="bigDog";       //大狗价格
    public static String NONHAIR="nonHair";     //无毛价格
    public static String SHORTHAIR="shortHair"; //短毛价格
    public static String NORMALLONGHAIR="normalLongHair";//一般长度
    public static String LONGHAIR="longHair";   //长毛价格
    public static String CURLHAIR="curlHair";   //卷毛价格
    public static String THINHAIR="thinHair";   //薄毛价格
    public static String NORMALHAIR="normalHair"; //一般厚度价格
    public static String THICKHAIR="thickHair"; //厚毛价格
    public static String DRYDOG="dryDog";   //烘干价格
    public static String WASHDRYDOG="washDryDog";   //洗烘价格
    public static String WATERTEM="waterTem";//水温
    /**=====================配置每个阶段洗漱时间===========================*/
    public static String FLOWTIME="flowTime";//流程时间更新时间
    public static String FIRSTWATERTIME="firstWaterTime";   //第一次冲水清洗
    public static String BODYWASHTIME="bodyWashTime";       //沐浴露
    public static String SECONDWATERTIME="secondWaterTime";       //第二次冲水清洗
    public static String CONDITIONERTIME="conditionerTime";     //护毛素
    public static String THIRDWATERTIME="thirdWaterTime"; //第三次冲水清洗
    public static String PREHEATTIME="preHeatTime";//预热时间
    public static String DRYTIME="dryTime";   //烘干时间
    public static String DISINFECTANTTIME="disinfectantTime";   //消毒液时间
    public static String WINDINPUTTIME="windInputTime";   //吹风时间
    public static String FOURTHWATERTIME="FourthWaterTime"; //第四次充水时间
    public static String BODYWASHUSE="bodyWashUse";//实际使用的沐浴露
    public static String CONDITIONERUSE="conditionerUse";//使用使用的护毛素
    public static String STEPINTERVAL="stepInterval";//步骤的间隔时间
    /**=============================电话号码==============================*/
    public static String OTHERTIME="otherTime";//其他设置更新时间
    public static String BSIZEPHONE="bSizePhone";//B端的电话号码
    public static String LOWTEM="lowTem";//低温加热
    public static String HIGHTEM="highTem";//高温停止加热
    public static String LOWINVIRTEM="lowInvirTem";//环境温度低温加热丝打开
    public static String HIGHINVIRTEM="highInvirTem";//环境温度高温加热丝关闭



    private static SharedPreferences mSharedPreferences=null;
    private static SharedPreferences.Editor mEditor=null;

    public static void init(){
        if (null==mSharedPreferences){
            mSharedPreferences= PreferenceManager.getDefaultSharedPreferences(MyApplication.getContext());
        }
    }

    public static void commitString(String key, String value){
        mEditor=mSharedPreferences.edit();
        mEditor.putString(key,value);
        mEditor.commit();
    }

    public static String getString(String key, String failValue){
        return mSharedPreferences.getString(key,failValue);
    }

    public static void commitInt(String key, int value){
        mEditor = mSharedPreferences.edit();
        mEditor.putInt(key, value);
        mEditor.commit();
    }

    public static int getInt(String key, int failValue){
        return mSharedPreferences.getInt(key, failValue);
    }

    public static void commitLong(String key, long value){
        mEditor = mSharedPreferences.edit();
        mEditor.putLong(key, value);
        mEditor.commit();
    }

    public static long getLong(String key, long failValue) {
        return mSharedPreferences.getLong(key, failValue);
    }

    public static void commitFloat(String key, float value){
        mEditor = mSharedPreferences.edit();
        mEditor.putFloat(key, value);
        mEditor.commit();
    }

    public static float getFloat(String key, float failValue) {
        return mSharedPreferences.getFloat(key, failValue);
    }

    public static void commitBoolean(String key, boolean value){
        mEditor = mSharedPreferences.edit();
        mEditor.putBoolean(key, value);
        mEditor.commit();
    }

    public static Boolean getBoolean(String key, boolean failValue){
        return mSharedPreferences.getBoolean(key, failValue);
    }

    //清除偏好设置参数
    public static void clear(){
        mEditor = mSharedPreferences.edit();
        mEditor.clear();
        mEditor.commit();
    }

}
