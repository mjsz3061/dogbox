package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2022/3/10
 * Describe:
 */
public class ErrorBean {

    private int id;
    private String sn;
    private int tf;
    private int camera;
    private int controller;
    private int lamppost;
    private int network;
    private int screen;
    private int speaker;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public int getTf() {
        return tf;
    }

    public void setTf(int tf) {
        this.tf = tf;
    }

    public int getCamera() {
        return camera;
    }

    public void setCamera(int camera) {
        this.camera = camera;
    }

    public int getController() {
        return controller;
    }

    public void setController(int controller) {
        this.controller = controller;
    }

    public int getLamppost() {
        return lamppost;
    }

    public void setLamppost(int lamppost) {
        this.lamppost = lamppost;
    }

    public int getNetwork() {
        return network;
    }

    public void setNetwork(int network) {
        this.network = network;
    }

    public int getScreen() {
        return screen;
    }

    public void setScreen(int screen) {
        this.screen = screen;
    }

    public int getSpeaker() {
        return speaker;
    }

    public void setSpeaker(int speaker) {
        this.speaker = speaker;
    }
}
