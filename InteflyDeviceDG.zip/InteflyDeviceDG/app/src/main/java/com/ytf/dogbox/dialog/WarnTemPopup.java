package com.ytf.dogbox.dialog;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.animator.PopupAnimator;
import com.lxj.xpopup.core.CenterPopupView;
import com.ytf.dogbox.R;

/**
 * author:tiwolf
 * create date:2023/11/29
 * Describe:
 */
public class WarnTemPopup extends CenterPopupView {

    private String warn;

    public WarnTemPopup(Context context, String warn){
        this(context);
        this.warn=warn;
    }

    public WarnTemPopup(@NonNull Context context) {
        super(context);
    }

    // 返回自定义弹窗的布局
    @Override
    protected int getImplLayoutId() {
        return R.layout.dialog_waterless;
    }
    // 执行初始化操作，比如：findView，设置点击，或者任何你弹窗内的业务逻辑
    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        TextView warnTv=findViewById(R.id.warn_tv);
        warnTv.setText(warn);
    }
    // 设置最大宽度，看需要而定
    @Override
    protected int getMaxWidth() {
        return 1536;
    }
    // 设置最大高度，看需要而定
    @Override
    protected int getMaxHeight() {
        return 864;
    }
    // 设置自定义动画器，看需要而定
    @Override
    protected PopupAnimator getPopupAnimator() {
        return super.getPopupAnimator();
    }
}
