package com.ytf.dogbox.dogHttp;


/**
 * @author tiwolf_li
 * @Date on 2020/6/24
 * @Description
 */
public interface OnThreadResultListener {

    void onProgressChange(int persent);

    void onUpFinish();

    void onUpInterrupted();

    void upFailed();

    void onDownloadFinish();

    void onDownloadInterrupted();

    void downloadFailed();

    void downloadError(int flag);

    void downloadPackageSuccess();

    void downloadPackageFail();

    void onBoardProgressChange(int persent);//固件下载成功

    void onBoardDownloadSuccess();//固件下载成功

    void onBoardDownloadFail(); //固件下载失败
}
