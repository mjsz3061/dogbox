package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/11/18
 * Describe:
 */
public class PayBean {


    private String qrCode;
    private OrderInfoDTO orderInfo;

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public OrderInfoDTO getOrderInfo() {
        return orderInfo;
    }

    public void setOrderInfo(OrderInfoDTO orderInfo) {
        this.orderInfo = orderInfo;
    }

    public static class OrderInfoDTO {
        private String orderNo;
        private Object custId;
        private double amount;
        private String createTime;
        private String washType;
        private String bodyFeature;
        private String hairFeature;
        private String washFeature;
        private String tickFeature;
        private int status;

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public Object getCustId() {
            return custId;
        }

        public void setCustId(Object custId) {
            this.custId = custId;
        }

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public String getWashType() {
            return washType;
        }

        public void setWashType(String washType) {
            this.washType = washType;
        }

        public String getBodyFeature() {
            return bodyFeature;
        }

        public void setBodyFeature(String bodyFeature) {
            this.bodyFeature = bodyFeature;
        }

        public String getHairFeature() {
            return hairFeature;
        }

        public void setHairFeature(String hairFeature) {
            this.hairFeature = hairFeature;
        }

        public String getWashFeature() {
            return washFeature;
        }

        public void setWashFeature(String washFeature) {
            this.washFeature = washFeature;
        }

        public String getTickFeature() {
            return tickFeature;
        }

        public void setTickFeature(String tickFeature) {
            this.tickFeature = tickFeature;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }
    }
}
