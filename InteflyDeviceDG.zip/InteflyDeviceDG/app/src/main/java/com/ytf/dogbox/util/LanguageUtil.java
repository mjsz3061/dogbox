package com.ytf.dogbox.util;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.LocaleList;
import android.util.DisplayMetrics;

import androidx.annotation.RequiresApi;

import java.util.Locale;

public class LanguageUtil {


    public static void switchLanguage(Context context,String language) {
        //设置应用语言类型
        Resources resources = context.getResources();
        Configuration config = resources.getConfiguration();
        DisplayMetrics dm = resources.getDisplayMetrics();
        if (language.equals("zh")) {
//            config.locale = Locale.ENGLISH;
            config.locale= Locale.SIMPLIFIED_CHINESE;
        } else{
            config.locale = Locale.ENGLISH;
        }
        resources.updateConfiguration(config, dm);

        //保存设置语言的类型
//        PreferenceUtil.commitString(PreferenceUtil.LANGUAGE, language);
    }

    //跟随系统语言变化
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static void followSystemLanguage(Context context){
        //设置应用语言类型
        Resources resources=context.getResources();
        Configuration config=resources.getConfiguration();
        DisplayMetrics dm=resources.getDisplayMetrics();
        LocaleList locales = config.getLocales();
        String lan=locales.get(0).getLanguage();
        switch (lan){
            case "zh":{
//                Log.e("tiwolf","当前系统语言为中文");
                config.locale= Locale.SIMPLIFIED_CHINESE;
                resources.updateConfiguration(config, dm);
                break;
            }
            case "en":{
//                Log.e("tiwolf","当前系统语言为英语");
                config.locale= Locale.ENGLISH;
                resources.updateConfiguration(config, dm);
                break;
            }
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String currentLanguage(Context context){
        //设置应用语言类型
        Resources resources=context.getResources();
        Configuration config=resources.getConfiguration();
        DisplayMetrics dm=resources.getDisplayMetrics();
        LocaleList locales = config.getLocales();
        String lan=locales.get(0).getLanguage();
        return lan;

    }

}
