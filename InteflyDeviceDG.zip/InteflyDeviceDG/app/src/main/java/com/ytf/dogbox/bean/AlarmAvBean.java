package com.ytf.dogbox.bean;

/**
 * @author tiwolf_li
 * @Date on 2020/6/19
 * @Description
 */
public class AlarmAvBean {

    private int broadcastId;
    private String content;  //广告内容
    private int id;
    private String startTime;   //开始时间
    private int status;     //播放状态
    private int times;      //播放次数
    private int volume;     //音量大小


    public int getBroadcastId() {
        return broadcastId;
    }

    public void setBroadcastId(int broadcastId) {
        this.broadcastId = broadcastId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getTimes() {
        return times;
    }

    public void setTimes(int times) {
        this.times = times;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }
}
