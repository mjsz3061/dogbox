package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2022/1/14
 * Describe:  广告列表
 */
public class AdvertBean<T> {


    private String optCode;
    private String attrCode;
    private String time;
    private int partId;
    private T value;


    public String getOptCode() {
        return optCode;
    }

    public void setOptCode(String optCode) {
        this.optCode = optCode;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAttrCode() {
        return attrCode;
    }

    public void setAttrCode(String attrCode) {
        this.attrCode = attrCode;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
}
