package com.ytf.dogbox.dialog;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.icu.text.DecimalFormat;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.*;

import com.wang.avi.AVLoadingIndicatorView;
import com.warkiz.widget.IndicatorSeekBar;
import com.ytf.dogbox.R;
import com.ytf.dogbox.dialog.CustomDialog;
import com.ytf.dogbox.dogHttp.DogWashType;
import com.ytf.dogbox.util.Log;

/**
 * author:tiwolf
 * create date:2023/12/1
 * Describe:
 */
public class PayDialogUtil {

    public PayDialogUtil(Context context,IPayDialogListener iPayDialogListener){
        this.payDialogListener=iPayDialogListener;

        dogtypes=context.getResources().getStringArray(R.array.dog_type);
        dogHairLongs=context.getResources().getStringArray(R.array.dog_hair_type);
        dogHairThins=context.getResources().getStringArray(R.array.dog_thin_type);
        dogWashTypes=context.getResources().getStringArray(R.array.dog_wash_type);
    }


    private static String TAG=PayDialogUtil.class.getSimpleName();

    /**==============一键洗狗页面==================*/
    CustomDialog payOneDialog;
    TextView numOneNoTv;
    ImageView payOneUrlTitleIv;    //支付名称
    TextView payOneUrldetailTv;   //支付内容
    RadioGroup payOneUrlTypeRg;    //支付类型
    ImageView codeOneUrlIv;        //支付二维码
    AVLoadingIndicatorView codeOneAliv;//二维码展示前预览
    TextView payOneWarnTv;          //支持的内容显示
    TextView ordersOneTv;          //订单号
    TextView moneyOneTv;           //支付金额
    TextView payOneContentTv;      //一键洗狗
    TextView cancelPayOneTv;           //取消订单
    CountDownTimer countDownTimer;
    boolean isFirstFlag=false;
    //一键洗狗支付界面
    public synchronized boolean showPayOneDialog(Activity activity,Context context){
        if (payOneDialog!=null && payOneDialog.isShowing()){
            return false;
        }
        if (payOneDialog==null){
            View view=activity.getLayoutInflater().inflate(R.layout.dialog_payone,null);
            payOneDialog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
            numOneNoTv=payOneDialog.findViewById(R.id.pay_num_tv);
            payOneUrlTitleIv=payOneDialog.findViewById(R.id.pay_title_Iv);
            payOneUrldetailTv=payOneDialog.findViewById(R.id.pay_content_tv);
            payOneUrlTypeRg=payOneDialog.findViewById(R.id.pay_rg);
            payOneWarnTv=payOneDialog.findViewById(R.id.code_warn_tv);
//        payFl=payDialog.findViewById(R.id.paydetail_fl);
            codeOneUrlIv=payOneDialog.findViewById(R.id.code_iv);
            codeOneAliv=payOneDialog.findViewById(R.id.code_aliv);
            ordersOneTv=payOneDialog.findViewById(R.id.orders_tv);
            moneyOneTv=payOneDialog.findViewById(R.id.money_tv);
            payOneContentTv=payOneDialog.findViewById(R.id.order_content_tv);
            cancelPayOneTv=payOneDialog.findViewById(R.id.cancel_pay_tv);
        }

        payOneUrlTypeRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.wechat_crb:{

                        break;
                    }
                    case R.id.ali_crb:{

                        break;
                    }
                    case R.id.third_crb:{

                        break;
                    }

                }
            }
        });
        cancelPayOneTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (payOneDialog.isShowing()){
                    payOneDialog.dismiss();
                }
            }
        });
        payOneDialog.show();
        payOneDialog.setCancelable(true);

        if (codeOneAliv!=null){
            codeOneAliv.setVisibility(View.VISIBLE);
            codeOneAliv.smoothToShow();
        }

        setCountDown(60,numOneNoTv,payOneDialog);
        return true;
    }

    public void dismissPayOnedialog(){
        if (payOneDialog!=null && payOneDialog.isShowing()){
            payOneDialog.dismiss();
        }
    }

    public void changePayOneMsg(Bitmap bitmap,String orderNo,double orderAmount){

        if (codeOneAliv!=null){
            codeOneAliv.smoothToHide();
            codeOneAliv.setVisibility(View.GONE);
        }
        if (codeOneUrlIv!=null){
            codeOneUrlIv.setImageBitmap(bitmap);
            ordersOneTv.setText("订单号："+orderNo);
            moneyOneTv.setText("支付金额："+orderAmount);
        }
    }

    /**==============一键洗狗页面end==================*/
    /**==============高端洗狗页面==================*/
    CustomDialog payDialog;
    TextView numNoTv;
    ImageView payUrlTitleIv;    //支付名称
    TextView payUrldetailTv;   //支付内容
    RadioGroup payUrlTypeRg;    //支付类型
    //    FrameLayout payFl;          //支付板块
    ImageView codeUrlIv;        //支付二维码
    AVLoadingIndicatorView codeAliv;//二维码展示前预览
    TextView payWarnTv;         //支持支付内容
    TextView ordersTv;          //订单号
    TextView moneyTv;           //支付金额
    TextView payContentTv;      //一键洗狗
    TextView charTv;            //狗的特征以及洗的类型
    TextView temTv;             //水温
    TextView cancelPayTv;       //取消订单按键
    //高端精洗的支付页面
    public synchronized void showPayDialog(Activity activity,Context context){
        if (payDialog!=null && payDialog.isShowing()){
            return;
        }
        if (payDialog==null){
            View view=activity.getLayoutInflater().inflate(R.layout.dialog_pay,null);
            payDialog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
            numNoTv=payDialog.findViewById(R.id.pay_num_tv);
            payUrlTitleIv=payDialog.findViewById(R.id.pay_title_Iv);
            payUrldetailTv=payDialog.findViewById(R.id.pay_content_tv);
            payUrlTypeRg=payDialog.findViewById(R.id.pay_rg);
//        payFl=payDialog.findViewById(R.id.paydetail_fl);
            payWarnTv=payDialog.findViewById(R.id.code_warn_tv);
            codeUrlIv=payDialog.findViewById(R.id.code_iv);
            codeAliv=payDialog.findViewById(R.id.code_aliv);
            ordersTv=payDialog.findViewById(R.id.orders_tv);
            moneyTv=payDialog.findViewById(R.id.money_tv);
            payContentTv=payDialog.findViewById(R.id.order_content_tv);
            charTv=payDialog.findViewById(R.id.char_tv);
            temTv=payDialog.findViewById(R.id.tem_tv);
            cancelPayTv=payDialog.findViewById(R.id.cancel_pay_tv);
        }

        cancelPayTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (payDialog!=null){
                    payDialog.dismiss();
                }
            }
        });
        payDialog.show();
        payDialog.setCancelable(true);
        if (codeAliv!=null){
            codeAliv.setVisibility(View.VISIBLE);
            codeAliv.smoothToShow();
        }
        setCountDown(60,numNoTv,payDialog);

    }

    public void dismissPaydialog(){
        if (payDialog!=null && payDialog.isShowing()){
            payDialog.dismiss();
        }
    }

    public void changePayMsg(Bitmap bitmap,String orderNo,double orderAmount,String dogType,String hairType,String hairthick,String washTp,String tem){

        if (codeAliv!=null){
            codeAliv.smoothToHide();
            codeAliv.setVisibility(View.GONE);
        }
        if (codeOneUrlIv!=null){
            codeOneUrlIv.setImageBitmap(bitmap);
            ordersOneTv.setText("订单号："+orderNo);
            moneyOneTv.setText("支付金额："+orderAmount);
        }
        if (codeUrlIv!=null){
            codeUrlIv.setImageBitmap(bitmap);
            ordersTv.setText("订单号："+orderNo);
            moneyTv.setText("支付金额："+orderAmount);
            charTv.setText("特征使用类型："+dogType+"、"+hairType+"、"+hairthick+"、"+washTp);
            temTv.setText("水温："+tem+"°");
        }
    }

    /**========================支付成功页面=========================*/
    CustomDialog paySuccessDialog;
    TextView ordersSuccessTv;          //订单号
    TextView moneySuccessTv;           //支付金额
    TextView payContentSuccessTv;      //一键洗狗
    TextView paySuccessNumTv;
    public void showPaySuccessDialog(Activity activity,Context context,String order_No,double order_amount,String washContent){
        if (paySuccessDialog==null){
            View view=activity.getLayoutInflater().inflate(R.layout.dialog_pay_success,null);
            paySuccessDialog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
            ordersSuccessTv=paySuccessDialog.findViewById(R.id.orders_tv);
            moneySuccessTv=paySuccessDialog.findViewById(R.id.money_tv);
            payContentSuccessTv=paySuccessDialog.findViewById(R.id.order_content_tv);
            paySuccessNumTv=paySuccessDialog.findViewById(R.id.pay_num_tv);
        }
        ordersSuccessTv.setText("订单号："+order_No);
        moneySuccessTv.setText("支付金额："+order_amount);
        payContentSuccessTv.setText("服务项目："+washContent);
        paySuccessDialog.show();
        paySuccessDialog.setCancelable(false);
        setCountDown(30,paySuccessNumTv,paySuccessDialog);
    }

    public void dismissPaySuccessDialog(){
        if (paySuccessDialog!=null){
            if (countDownTimer!=null)
                countDownTimer.cancel();
            paySuccessDialog.dismiss();
        }
    }

    /**============================洗狗机详情页面===============================*/
    private String[] dogtypes;
    private String[] dogHairLongs;
    private String[] dogHairThins;
    private String[] dogWashTypes;
    private IndicatorSeekBar temIs;
    private RadioGroup dogRg,hairRg,thinRg,washRg;
    private TextView washTimeTv,washMoneyTv;
    private TextView submitTv;
    private ImageView cancelTv;
    private int totalTime;
    private double totalMoney;
    private String dogTypeStr,hairLongStr,hairLessStr,washTypeStr;//爱犬类型，毛发类型，稀疏程度，洗宠类型
    private double chooseInt1,chooseInt2,chooseInt3,chooseInt4;
    CustomDialog detailDialog;
    boolean detailFlag=false;
    private int oneWaterInt,bodyWashInt,twoWaterInt,conditionerInt,threeWaterInt,preheatInt,dryInt;
    private double detailWashPrice;
    public synchronized void showDetailDialog(Activity activity,
                                              Context context,
                                              double smallDogPrice,
                                              double midDogPrice,
                                              double bigDogPrice,
                                              double shortHairPrice,
                                              double normalLongHairPrice,
                                              double longHairPrice,
                                              double thinHairPrice,
                                              double normalHairPrice,
                                              double thickHairPrice,
                                              double washDryPrice,
                                              double dryDogPrice,
                                              int oneWaterInt,
                                              int bodyWashInt,
                                              int twoWaterInt,
                                              int conditionerInt,
                                              int threeWaterInt,
                                              int preheatInt,
                                              int dryInt,
                                              double detailWashPrice){
        if (detailDialog!=null && detailDialog.isShowing()){
            return;
        }
        View view=activity.getLayoutInflater().inflate(R.layout.dialog_detail_dog,null);
        detailDialog=new CustomDialog(context,1536,864,view,R.style.DialogTheme);
        temIs=detailDialog.findViewById(R.id.tem_is);
        dogRg=detailDialog.findViewById(R.id.dog_rg);
        hairRg=detailDialog.findViewById(R.id.hair_rg);
        thinRg=detailDialog.findViewById(R.id.thin_rg);
        washRg=detailDialog.findViewById(R.id.wash_rg);
        washTimeTv=detailDialog.findViewById(R.id.wash_time_tv);
        washMoneyTv=detailDialog.findViewById(R.id.wash_money_tv);
        submitTv=detailDialog.findViewById(R.id.character_submit_tv);
        cancelTv=detailDialog.findViewById(R.id.character_cancel_iv);

        chooseInt1=midDogPrice;
        chooseInt2=normalLongHairPrice;
        chooseInt3=normalHairPrice;
        chooseInt4=washDryPrice;

        this.oneWaterInt=oneWaterInt;
        this.bodyWashInt=bodyWashInt;
        this.twoWaterInt=twoWaterInt;
        this.conditionerInt=conditionerInt;
        this.threeWaterInt=threeWaterInt;
        this.preheatInt=preheatInt;
        this.dryInt=dryInt;
        this.detailWashPrice=detailWashPrice;

        dogRg.check(R.id.mid_rb);
        hairRg.check(R.id.normal_hair_rb);
        thinRg.check(R.id.normal_rb);
        washRg.check(R.id.washdry_rb);

        dogTypeStr=dogtypes[1];
        hairLongStr=dogHairLongs[1];
        hairLessStr=dogHairThins[1];
        washTypeStr=dogWashTypes[1];
        getWashTime();


        dogRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                setCountDown(120,null,detailDialog);
                switch (checkedId){
                    case R.id.small_rb:{
                        Log.e(TAG, "onCheckedChanged: 点击了小型犬" );
                        chooseInt1=smallDogPrice;
                        dogTypeStr=dogtypes[0];
                        getWashTime();
                        break;
                    }
                    case R.id.mid_rb:{
                        Log.e(TAG, "onCheckedChanged: 点击了中型犬" );
                        chooseInt1=midDogPrice;
                        dogTypeStr=dogtypes[1];
                        getWashTime();
                        break;
                    }
                    case R.id.big_rb:{
                        Log.e(TAG, "onCheckedChanged: 点击了大型犬" );
                        chooseInt1=bigDogPrice;
                        dogTypeStr=dogtypes[2];
                        getWashTime();
                        break;
                    }
                }
            }
        });

        hairRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                setCountDown(120,null,detailDialog);
                switch (checkedId){
                    case R.id.short_hair_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了短毛" );
                        chooseInt2=shortHairPrice;
                        hairLongStr=dogHairLongs[0];
                        getWashTime();
                        break;
                    }
                    case R.id.normal_hair_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了一般毛发" );
                        chooseInt2=normalLongHairPrice;
                        hairLongStr=dogHairLongs[1];
                        getWashTime();
                        break;
                    }
                    case R.id.long_hair_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了长毛发" );
                        chooseInt2=longHairPrice;
                        hairLongStr=dogHairLongs[2];
                        getWashTime();
                        break;
                    }
                }
            }
        });

        thinRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                setCountDown(120,null,detailDialog);
                switch (checkedId){
                    case R.id.thin_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了薄毛" );
                        chooseInt3=thinHairPrice;
                        hairLessStr=dogHairThins[0];
                        getWashTime();
                        break;
                    }
                    case R.id.normal_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了一般厚毛发" );
                        chooseInt3=normalHairPrice;
                        hairLessStr=dogHairThins[1];
                        getWashTime();
                        break;
                    }
                    case R.id.thick_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了厚毛发" );
                        chooseInt3=thickHairPrice;
                        hairLessStr=dogHairThins[2];
                        getWashTime();
                        break;
                    }
                }
            }
        });

        washRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                setCountDown(120,null,detailDialog);
                switch (checkedId){
                    case R.id.washdry_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了烘洗一体" );
                        chooseInt4=washDryPrice;
                        washTypeStr=dogWashTypes[1];
                        getWashTime();
                        break;
                    }
                    case R.id.dry_rb:{
                        Log.e(TAG, "onCheckedChanged: 选择了烘干" );
                        chooseInt4=dryDogPrice;
                        washTypeStr=dogWashTypes[0];
                        getWashTime();
                        break;
                    }

                }
            }
        });

        submitTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detailDialog.isShowing()){
                    if (countDownTimer!=null){
                        countDownTimer.cancel();
                    }
                    detailDialog.dismiss();
                }
//                totalMul=chooseInt1*chooseInt2*chooseInt3*chooseInt4;
//                Log.e(TAG, "onClick: 高端精洗当前的倍数="+totalMul );
//                dogWashType=DogWashType.DETAILWASH;
//                handler.sendEmptyMessage(DOGPAYURL);
//                // todo 这里的话也会显示二维码弹窗特别慢。所以直接使用handler.sendEmptyMessage(DOGPAYURL);
////                getPayUrl(DogWashType.DETAILWASH);
//                showPayDialog();
                payDialogListener.detailSubmit(chooseInt1*chooseInt2*chooseInt3*chooseInt4,totalMoney,dogTypeStr,hairLongStr,hairLessStr,washTypeStr);
            }
        });

        cancelTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detailDialog.isShowing()){
                    if (countDownTimer!=null){
                        countDownTimer.cancel();
                    }
                    detailDialog.dismiss();
                }
            }
        });

        temIs.setIndicatorTextFormat("当前温度为 ${TICK_TEXT} °");
        detailDialog.show();
        detailDialog.setCancelable(true);
        setCountDown(120,null,detailDialog);
    }

    private void getWashTime(){
        totalTime=(int)((oneWaterInt+bodyWashInt+twoWaterInt+conditionerInt+threeWaterInt+preheatInt+dryInt)*(chooseInt1*chooseInt2*chooseInt3*chooseInt4)/1000.0/60.0);
        totalMoney=detailWashPrice*(chooseInt1*chooseInt2*chooseInt3*chooseInt4);
        android.util.Log.e(TAG, "getWashTime: 高端精洗的值为="+totalMoney );
        String moneyStr;
        if (totalMoney==0){
            totalMoney=0.01;
            moneyStr="0.01";
        }else{
            DecimalFormat df = new DecimalFormat ("0.00");
            moneyStr = df.format (totalMoney);
        }

        washTimeTv.setText(""+totalTime);
        washMoneyTv.setText(moneyStr);
        totalMoney=Double.valueOf(moneyStr);
    }



    private synchronized void setCountDown(int num,TextView textView,CustomDialog dialog){
        if (countDownTimer!=null){
            countDownTimer.cancel();
        }
        countDownTimer=new CountDownTimer(num*1000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (textView!=null){
                    textView.setText(""+(int)(millisUntilFinished/1000));
                }
            }

            @Override
            public void onFinish() {
                if (dialog!=null){
                    dialog.dismiss();
                }
            }
        };
        countDownTimer.start();
    }

    IPayDialogListener payDialogListener;
    public void setPayDialogListener(IPayDialogListener payDialogListener){
        this.payDialogListener=payDialogListener;
    }

    public interface IPayDialogListener{
        void backPayParam();
        void detailSubmit(double totalMul,double totalMoney,String dogTypeStr,String hairLongStr,String hairLessStr,String washTypeStr);
    }

}
