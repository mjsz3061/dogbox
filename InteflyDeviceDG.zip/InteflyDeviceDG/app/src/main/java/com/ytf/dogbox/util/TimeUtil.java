package com.ytf.dogbox.util;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeUtil {

    /**
     *date类型转换成String类型
     * @param date Date类型的时间
     * @param formatType 格式为yyyymmddhhmmss
     * @return
     */
    public static String dateToString(Date date,String formatType){
        return new SimpleDateFormat(formatType).format(date);
    }

    /**
     * long类型转换成String类型
     * @param currentTime 时间戳
     * @param formatType 格式
     * @return
     * @throws ParseException
     */
    public static String longToString(long currentTime,String formatType) throws ParseException {
        Date date=longToDate(currentTime,formatType);
        String strTime=dateToString(date,formatType);
        return strTime;
    }

    /**
     * String类型转换成date类型
     * @param strTime 时间字符串
     * @param formatType 格式
     * @return
     * @throws ParseException
     */
    public static Date stringToDate(String strTime,String formatType) throws ParseException{
        SimpleDateFormat formatter=new SimpleDateFormat(formatType);
        Date date=formatter.parse(strTime);
        return date;
    }

    /**
     * Long类型转换成Date类型
     * @param currentTime 时间戳
     * @param formatType 格式
     * @return
     * @throws ParseException
     */
    public static Date longToDate(long currentTime,String formatType) throws ParseException{
        Date dateOld=new Date(currentTime);
        Log.e("tiwolf", "longToDate111111111: "+dateOld+"========"+dateOld.getTime() );
        String sDateTime=dateToString(dateOld,formatType);
        Date date=stringToDate(sDateTime,formatType);
        Log.e("tiwolf", "longToDate22222222: "+date+"========"+date.getTime() );
        return date;
    }

    /**
     * 字符串转成时间戳类型
     * @param strTime 时间字符串
     * @param formatType 格式
     * @return
     * @throws ParseException
     */
    public static long stringToLong(String strTime,String formatType) throws ParseException{
        Date date=stringToDate(strTime,formatType);
        if (date==null){
            return 0;
        }else {
            long currentTime=dateToLong(date);
            return currentTime;
        }
    }

    /**
     * Date类型转换成时间戳
     * @param date 日期
     * @return
     */
    public static long dateToLong(Date date){
        return date.getTime();
    }

    /**
     * 获取前些天的数据
     * @param day 提前天数  负数为提前几天，正数为向后几天
     * @return 返回长整形 long
     */
    public static long getMillisLastDay(int day){
        Calendar cal=Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR,-day);
        return cal.getTimeInMillis();
    }

    /**
     * 日期转换成字符串
     * @param date
     * @return str
     */
    public static String DateToStr(Date date) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String str = format.format(date);
        return str;
    }

    /**
     * 字符串转换成日期
     * @param str
     * @return date
     */
    public static Date StrToDate(String str) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }



    /**
     * 字符串转换成日期
     * @param str
     * @return date
     */
    public static Date StrToDateNone(String str) {

        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = null;
        try {
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }


    public static String getTime() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date now = new Date();
        return format.format(now);
    }


    public static Date turnStringToDate(String sTime){
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date now = null;
        try {
            now =format.parse(sTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return now;
    }

    public static String turnDateToString(Date date){
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        String time;
        time =format.format(date);
        return time;

    }

    public static String turnDateToStringonlyTime(Date date){
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        String time;
        time =format.format(date);
        return time;
    }

    public static long getDiffTime(Date offTime_date, Date nowTime_date) {
        long offTime=offTime_date.getTime();
        long nowTime=nowTime_date.getTime();
        long diffTime=nowTime-offTime;
        return diffTime;

    }

    public static String turnMiuTimeToString(long time){
        long hour=time/(1000*60*60);
        long min = (time-hour*(1000*60*60))/(1000*60);
        return hour+":"+min;
    }

    public static long turnTimeToMin(long time){
        return time/(1000*60);
    }



    public static Calendar getCaledar(int minuteInt){
        //得到日历
        Calendar calendar=Calendar.getInstance();
        //获取当前毫秒值
        long systemTime=System.currentTimeMillis();

        long noiseReceiveTime=systemTime+minuteInt*60*1000;

        calendar.setTimeInMillis(noiseReceiveTime);
        return calendar;
    }
}
