package com.ytf.dogbox.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.List;

public class FragAdapter extends FragmentStatePagerAdapter {
    //1.创建Fragment数组
    private List<Fragment> mFragments;
    //2.接收从Activity页面传递过来的Fragment数组
    public FragAdapter(FragmentManager fm, List<Fragment> fragments){
        super(fm);
        mFragments = fragments;
    }
    @Override
    public Fragment getItem(int i) {
//        Log.e("tiwolf", "getItem: 是一个item="+i );
        return mFragments.get(i);
    }
    @Override
    public int getCount() {
//        Log.e("tiwolf", "getCount: 总共的数量为="+mFragments.size() );
        return mFragments==null?0:mFragments.size();
    }


}