package com.ytf.dogbox.bean;

/**
 * @author tiwolf_li
 * @Date on 2021/6/25
 * @Description
 */
public class LiveBean {

//        vStringBuffer.append("liveContent varchar(400),");              //直播url
//        vStringBuffer.append("alarmId int,");                           //闹钟id
//        vStringBuffer.append("volume int,");                            //音量大小
//        vStringBuffer.append("startTime varchar(30),");                 //开始时间段
//        vStringBuffer.append("endTime varchar(30),");                   //结束时间段
//        vStringBuffer.append("startDay varchar(30),");                  //开始日期
//        vStringBuffer.append("endDay varchar(30),");                    //结束日期
//        vStringBuffer.append("flag int,");                              //是否可用
//        vStringBuffer.append("alarm1 int,");                            //闹钟直接操作
//        vStringBuffer.append("alarm2 int,");                            //闹钟直接操作2
//        vStringBuffer.append("item1 varchar(30),");                     //备用1
//        vStringBuffer.append("item2 varchar(30),");                     //备用2
//        vStringBuffer.append("item3 int,");                             //备用3
//        vStringBuffer.append("item4 int,");                             //备用4
//        vStringBuffer.append("dotime varchar(20))");                    //下发时间戳

    private int playId;             //播放id
    private String url;                //播放url
    private int volume;             //播放音量
    private String startTime;       //开始时间
    private String endTime;         //关闭时间
    private String startDay;        //开始日期
    private String endDay;          //关闭日期
    private int flag;               //可用标志
    private String alarm1;          //开始闹钟 定时标志
    private String alarm2;          //结束闹钟 定时标志
    private String item1;           //备用string
    private String item2;           //备用string
    private int item3;              //备用int
    private int item4;              //备用int
    private String doTime;


    public int getPlayId() {
        return playId;
    }

    public void setPlayId(int playId) {
        this.playId = playId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStartDay() {
        return startDay;
    }

    public void setStartDay(String startDay) {
        this.startDay = startDay;
    }

    public String getEndDay() {
        return endDay;
    }

    public void setEndDay(String endDay) {
        this.endDay = endDay;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getAlarm1() {
        return alarm1;
    }

    public void setAlarm1(String alarm1) {
        this.alarm1 = alarm1;
    }

    public String getAlarm2() {
        return alarm2;
    }

    public void setAlarm2(String alarm2) {
        this.alarm2 = alarm2;
    }

    public String getItem1() {
        return item1;
    }

    public void setItem1(String item1) {
        this.item1 = item1;
    }

    public String getItem2() {
        return item2;
    }

    public void setItem2(String item2) {
        this.item2 = item2;
    }

    public int getItem3() {
        return item3;
    }

    public void setItem3(int item3) {
        this.item3 = item3;
    }

    public int getItem4() {
        return item4;
    }

    public void setItem4(int item4) {
        this.item4 = item4;
    }

    public String getDoTime() {
        return doTime;
    }

    public void setDoTime(String doTime) {
        this.doTime = doTime;
    }
}
