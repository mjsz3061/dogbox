package com.ytf.dogbox.dogHttp;

import static com.ytf.dogbox.util.TestConfig.HOST;
import static com.ytf.dogbox.util.TestConfig.httpheader;


import android.util.Log;

import com.ytf.dogbox.bean.AdvertBean;
import com.ytf.dogbox.bean.AlarmBean;
import com.ytf.dogbox.bean.CheckMsgBean;
import com.ytf.dogbox.bean.DogAlarmBean;
import com.ytf.dogbox.bean.DogExceBean;
import com.ytf.dogbox.bean.DogHttpKeyBean;
import com.ytf.dogbox.bean.DogSnBean;
import com.ytf.dogbox.bean.DogSyncConfigBean;
import com.ytf.dogbox.bean.DogTonkenBean;
import com.ytf.dogbox.bean.ErrorBean;
import com.ytf.dogbox.bean.HttpPayBean;
import com.ytf.dogbox.bean.KeyMsgBean;
import com.ytf.dogbox.bean.PayBean;
import com.ytf.dogbox.bean.QiniuMsgBean;
import com.ytf.dogbox.bean.RefundBean;
import com.ytf.dogbox.bean.RefundParamBean;
import com.ytf.dogbox.bean.UpLoadGetBean;
import com.ytf.dogbox.bean.UpLoadGetSubBean;

import java.util.List;
import java.util.Map;

import io.reactivex.Flowable;

/**
 * author:tiwolf
 * create date:2023/11/1
 * Describe:
 */
public class DogModel implements DogContract.Model{
    @Override
    public Flowable<KeyMsgBean> getDogState() {
        return null;
    }

    @Override
    public Flowable<UpLoadGetBean<UpLoadGetSubBean>> getMerge(Map<String, String> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).getMerge(map);
    }

    @Override
    public Flowable<QiniuMsgBean> getQiniuKey(Map<String, Object> map) {
        Log.e("tiwolf", "getQiniuKey: 七牛云获取密钥" );
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).getQiniuKey(map);
    }

    @Override
    public Flowable<KeyMsgBean> getQiniuDownloadUrl(Map<String, Object> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).getQiniuDownloadUrl(map);
    }

    @Override
    public Flowable<KeyMsgBean> getUpdatePolice(Map<String, String> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).getUpdatePolice(map);
    }

    @Override
    public Flowable<KeyMsgBean> updateRecordMsg(Map<String, Object> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).updateRecordMsg(map);
    }

    @Override
    public Flowable<KeyMsgBean> delRecordMsg(Map<String, Object> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).delRecordMsg(map);
    }

    @Override
    public Flowable<UpLoadGetBean<ErrorBean>> upSendError(Map<String, String> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).upSendError(map);
    }

    @Override
    public Flowable<UpLoadGetBean<CheckMsgBean>> updateMsg(Map<String, Object> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).updateMsg(map);
    }

    @Override
    public Flowable<UpLoadGetBean<DogTonkenBean>> getHttpKey(DogHttpKeyBean dogHttpKeyBean) {
        return RetrofitClient.getInstance().getApi(httpheader+HOST).getHttpKey(dogHttpKeyBean);
    }

    @Override
    public Flowable<KeyMsgBean> getUpdateKey(Map<String, Object> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).getUpdateKey(map);
    }

    @Override
    public Flowable<UpLoadGetBean<PayBean>> orderPay(HttpPayBean httpPayBean,String token) {
        return RetrofitClient.getInstance().getHeaderApi(httpheader+HOST,token).orderPay(httpPayBean);
    }

    @Override
    public Flowable<UpLoadGetBean<RefundBean>> refundPay(RefundParamBean refundParamBean,String token) {
        return RetrofitClient.getInstance().getHeaderApi(httpheader+HOST,token).refundPay(refundParamBean);
    }

    @Override
    public Flowable<KeyMsgBean> upLoadDogException(DogExceBean dogExceBean,String token) {
        return RetrofitClient.getInstance().getHeaderApi(httpheader+HOST,token).upLoadDogException(dogExceBean);
    }

    @Override
    public Flowable<KeyMsgBean> upLoadAlarmWarning(DogAlarmBean dogAlarmBean, String token) {
        return RetrofitClient.getInstance().getHeaderApi(httpheader+HOST,token).upLoadAlarmWarning(dogAlarmBean);
    }

    @Override
    public Flowable<UpLoadGetBean<DogSyncConfigBean>> syncConfigData(DogSnBean dogSnBean, String token) {
        return RetrofitClient.getInstance().getHeaderApi(httpheader+HOST,token).syncConfigData(dogSnBean);
    }

    @Override
    public Flowable<UpLoadGetBean<AdvertBean<List<AlarmBean>>>> getDeviceDataAdvert(Map<String, String> map) {
        return RetrofitClient.getInstance().getApi(httpheader+ HOST).getDeviceDataAdvert(map);
    }
}
