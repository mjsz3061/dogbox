package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/11/18
 * Describe:
 */
public class HttpPayBean {
    private String upTime;
    private PayValue value;

    public String getUpTime() { return upTime; }
    public void setUpTime(String value) { this.upTime = value; }

    public PayValue getValue() { return value; }
    public void setValue(PayValue value) { this.value = value; }
}
