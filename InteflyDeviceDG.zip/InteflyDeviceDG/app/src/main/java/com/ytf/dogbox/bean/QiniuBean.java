package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2021/12/14
 * Describe:
 */
public class QiniuBean {

    private String fid;
    private String key;
    private String token;
    private String md5;

    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }
}
