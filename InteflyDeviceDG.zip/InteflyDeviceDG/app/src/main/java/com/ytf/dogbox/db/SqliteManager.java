package com.ytf.dogbox.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ytf.dogbox.bean.AlarmAvBean;
import com.ytf.dogbox.bean.BmpRecordBean;
import com.ytf.dogbox.bean.DownloadItem;
import com.ytf.dogbox.bean.LedScreenAlarmBean;
import com.ytf.dogbox.bean.LiveBean;
import com.ytf.dogbox.bean.ScreenAlarmBean;
import com.ytf.dogbox.bean.UpdateRecordBean;
import com.ytf.dogbox.player.PlayItem;
import com.ytf.dogbox.util.Log;
import com.ytf.dogbox.util.UploadConfig;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;


/**
 * @author tiwolf_li
 * @Date on 2020/1/3
 * @Description
 */
public class SqliteManager {

    private SqliteHelper sqliteHelper;
    private static SqliteManager sqliteManager;


    private SqliteManager(Context context, String name, int version){
        this.sqliteHelper=new SqliteHelper(context,name,null,version);
    }

    public static SqliteManager getInstance(Context context, String name, int version){
        if (sqliteManager==null){
            synchronized (SqliteManager.class){
                sqliteManager=new SqliteManager(context,name,version);
            }
        }
        return sqliteManager;
    }

    public SQLiteDatabase getMdb(){
        SQLiteDatabase mdb=sqliteHelper.getWritableDatabase();
        return mdb;
    }

    /**
     * 使用歌曲的md5查询普通广告，公益广告列表里面是否有播放歌曲。如果有则返回true，没有则返回false
     * @param md5
     * @return
     */
    public boolean isPlayListHave(String md5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        boolean isHave=false;
        Cursor cursor=null;
        try {
            cursor= sdb.query("play_list",new String[]{"startTime","endTime","content","downloadMd5","playExt","playName","playType","downloadTotal","downloadId","playTime","playIndex","mediaName","volumn"},"downloadMd5=?",new String[]{md5},null,null,"playIndex asc");
            if (cursor.moveToFirst()){
                //说明有，则不删除
                isHave=true;
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return isHave;
        }
    }


    /**
     * =============================上传的增删改查=================================
     */
    /**
     * 添加一个item进去
     * @param contentValues
     */
    public void saveItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("upload_file",null,contentValues);
        Log.e("tiwolf", "receiveWork saveItem: "+contentValues.get("filePath") );
    }

    /**
     * 如果没有相关参数则添加
     * @param contentValues
     */
    public void saveUploadItem(ContentValues contentValues){
        String name=contentValues.getAsString(UploadConfig.lastModifiedTime);
        Log.e("tiwolf", "saveUploadItem: 上传参数="+name);
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Cursor cursor = sdb.rawQuery("select * from upload_file where lastModifiedTime=?", new String[]{name});
        if (cursor.moveToFirst()) {
            // 数据已存在，不进行插入操作
            cursor.close();
            return;
        }
        sdb.insert("upload_file",null,contentValues);
    }

    /**
     * 删除某一个item
     * @param filePath
     */
    public void delete(String filePath){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from upload_file where filePath=?",new Object[]{filePath});
        Log.e("tiwolf", "delete: "+filePath );
    }

    /**
     * 删除上传的某一个item
     * @param md5
     */
    public void deleteByMd5(String md5){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from upload_file where md5=?",new Object[]{md5});
        Log.e("tiwolf", "delete: "+md5 );
    }

    public String queryByMd5(String md5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        String filePath=null;
        try {
            //        sdb.execSQL("select FilePath from upload_file where UploadState=?");
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            cursor = sdb.rawQuery("select filePath,upstate,ext,originName,size,lastModifiedTime from upload_file where md5=?", new String[]{md5});
//        Cursor cursor = sdb.rawQuery("select FilePath from upload_file where UploadState=?", new String[]{fileState});

//        cursor.moveToLast();
            if(cursor.moveToFirst()){
                //一开始我在select 后面写少了FileSize，结果老是报错
                //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                filePath=cursor.getString(cursor.getColumnIndex("filePath"));
//                String ext=cursor.getString(cursor.getColumnIndex("ext"));
//                String md5=cursor.getString(cursor.getColumnIndex("md5"));
//                String originName=cursor.getString(cursor.getColumnIndex("originName"));
//                String size=cursor.getString(cursor.getColumnIndex("size"));
//                String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));
            }
            Log.e("tiwolf", "check:"+filePath );
        }finally {
            if (cursor!=null)
                cursor.close();
            return filePath;
        }
    }

    public String queryByPath(String filePath){
        Log.e("TAG", "queryByPath: 根据上传的路径查询="+filePath );
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            //        sdb.execSQL("select FilePath from upload_file where UploadState=?");
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            cursor = sdb.rawQuery("select md5,upstate,ext,originName,size,lastModifiedTime,chunkNumber,chunkIndex from upload_file where filePath=?", new String[]{filePath});
//        Cursor cursor = sdb.rawQuery("select FilePath from upload_file where UploadState=?", new String[]{fileState});

//        cursor.moveToLast();
            if(cursor.moveToFirst()){
                //一开始我在select 后面写少了FileSize，结果老是报错
                //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                int fileState=cursor.getInt(cursor.getColumnIndex("upstate"));
                int chunkIndex=cursor.getInt(cursor.getColumnIndex("chunkIndex"));
                int chunkNumber=cursor.getInt(cursor.getColumnIndex("chunkNumber"));
                String ext=cursor.getString(cursor.getColumnIndex("ext"));
                String md5=cursor.getString(cursor.getColumnIndex("md5"));
                String originName=cursor.getString(cursor.getColumnIndex("originName"));
                String size=cursor.getString(cursor.getColumnIndex("size"));
                String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));

                Log.e("tiwolf", "handleUploadPartFile:post上传---------------------------------------------------------" );
                Log.e("tiwolf", "handleUploadPartFile:post上传 上传状态="+fileState );
                Log.e("tiwolf", "handleUploadPartFile:post上传 已上传数据="+chunkIndex );
                Log.e("tiwolf", "handleUploadPartFile:post上传 总共需要上传数据="+chunkNumber );
                Log.e("tiwolf", "handleUploadPartFile:post上传 mp4路径="+filePath );
                Log.e("tiwolf", "handleUploadPartFile:post上传 后缀="+ext );
                Log.e("tiwolf", "handleUploadPartFile:post上传 md5="+md5 );
                Log.e("tiwolf", "handleUploadPartFile:post上传 originName="+originName );
                Log.e("tiwolf", "handleUploadPartFile:post上传 尺寸="+size );
                Log.e("tiwolf", "handleUploadPartFile:post上传 更改时间="+lastModifiedTime );
                Log.e("tiwolf", "handleUploadPartFile:post上传---------------------------------------------------------" );
            }
            Log.e("tiwolf", "check:"+filePath );
        }finally {
            if (cursor!=null)
                cursor.close();
            return filePath;
        }
    }

    /**
     * 更新某一条数据,这个需要注意符号
     * @param contentValues
     */
    public void update(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: "+contentValues.get("filePath")+"--"+contentValues.get("upstate") );
//        sdb.update("upload_file",contentValues,null,null);
        //修改SQL语句
        String sql="update upload_file set upstate = "+contentValues.get("upstate")+" where filePath = '"+contentValues.get("filePath")+"'";
        sdb.execSQL(sql);

    }

    /**
     * 仅仅查询一条数据
     * @param fileState
     * @return
     */
    public String check(String fileState){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        String filePath="kong";
        try {
            //        sdb.execSQL("select FilePath from upload_file where UploadState=?");
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            cursor = sdb.rawQuery("select filePath,ext,md5,originName,size,lastModifiedTime from upload_file where upstate=?", new String[]{fileState});
//        Cursor cursor = sdb.rawQuery("select FilePath from upload_file where UploadState=?", new String[]{fileState});

//        cursor.moveToLast();
            if(cursor.moveToFirst()){
                //一开始我在select 后面写少了FileSize，结果老是报错
                //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                filePath=cursor.getString(cursor.getColumnIndex("filePath"));
//                String ext=cursor.getString(cursor.getColumnIndex("ext"));
//                String md5=cursor.getString(cursor.getColumnIndex("md5"));
//                String originName=cursor.getString(cursor.getColumnIndex("originName"));
//                String size=cursor.getString(cursor.getColumnIndex("size"));
//                String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));
            }
            Log.e("tiwolf", "check:"+filePath );
        }finally {
            if (cursor!=null)
                cursor.close();
            return filePath;
        }


//        return filePath;
    }

    /**
     * 更新md5,这个需要注意符号
     * @param filePath
     */
    public void update(String filePath,String md5){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: "+filePath );
//        sdb.update("upload_file",contentValues,null,null);
        //修改SQL语句
        String sql="update upload_file set md5 = "+md5+" where filePath = '"+filePath+"'";
        sdb.execSQL(sql);

    }


    /**
     * 更新分片文件的上传状态,这个是在上传开始之前，对上传的大文件进行的设置。这个需要注意符号
     * @param filePath 根据上传的路径去更新上传状态和数量
     * @param upState 上传状态
     * @param num   上传数量
     */
    public void updateUpState(String filePath,String upState,String num,String total){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update:路径= "+filePath+",已上传数量="+num+";上传的状态为="+upState );
//        sdb.update("upload_file",contentValues,null,null);
        //修改SQL语句
        String sql="update upload_file set upstate = "+upState+",chunkNumber = "+total+",chunkIndex = "+num+" where filePath = '"+filePath+"'";
        sdb.execSQL(sql);

    }

    /**
     * 2023-3-1 这里有点问题，第二个分片出现混乱。需要重新规划。无上传时的休息时间后面要还原
     * 这里主要对.mp4记录进行一个已上传分片数据和总分片数记录和比较，以及结果处理
     * 这个功能可以做成一个专利
     * 这个是分片上传之间，每个分片上传之后对源文件进行的更改。如果当前的分片还没上传完，则num++；如果当前分片++之后
     * @param filePath  根据文件路径
     *
     */
    public String handleUploadPartFile(String filePath){
        /**
         *  上传完成
         *  1,从数据库获取当前上传的分片数量，
         *  2,进行分片上传数量+1
         *  3,分片上传数量和这个文件分片总数对比：3-1 如果不相等，则说明还未上传完，将+1后的分片上传数量替换之前的分片上传数量； 3-2 如果相等，则说明分片文件已经上传完毕。进行上报合并操作。合并操作如果错误，则可以将其放到update_record表格进行处理
         */
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            //        sdb.execSQL("select FilePath from upload_file where UploadState=?");
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            cursor = sdb.rawQuery("select upstate,ext,md5,originName,size,lastModifiedTime,chunkNumber,chunkIndex from upload_file where filePath=?", new String[]{filePath});
            int fileState=-1;
            if(cursor.moveToFirst()){
                //一开始我在select 后面写少了FileSize，结果老是报错
                //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                fileState=cursor.getInt(cursor.getColumnIndex("upstate"));
                int chunkIndex=cursor.getInt(cursor.getColumnIndex("chunkIndex"));
                int chunkNumber=cursor.getInt(cursor.getColumnIndex("chunkNumber"));
                String ext=cursor.getString(cursor.getColumnIndex("ext"));
                String md5=cursor.getString(cursor.getColumnIndex("md5"));
                String originName=cursor.getString(cursor.getColumnIndex("originName"));
                String size=cursor.getString(cursor.getColumnIndex("size"));
                String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));

                Log.e("tiwolf", "handleUploadPartFile:post上传 mp4路径="+filePath );
                Log.e("tiwolf", "handleUploadPartFile:post上传 后缀="+ext );
                Log.e("tiwolf", "handleUploadPartFile:post上传 md5="+md5 );
                Log.e("tiwolf", "handleUploadPartFile:post上传 originName="+originName );
                Log.e("tiwolf", "handleUploadPartFile:post上传 尺寸="+size );
                Log.e("tiwolf", "handleUploadPartFile:post上传 更改时间="+lastModifiedTime );


                Log.e("TAG", "handleUploadPartFile: 分片上传数量="+chunkIndex+";分片总数量="+chunkNumber+";mp4路径为="+filePath );
                // 2 进行2步骤
                chunkIndex=chunkIndex+1;
                Log.e("TAG", "handleUploadPartFile: 分片已经上传数量000="+chunkIndex);
                if (chunkIndex==chunkNumber){
                    //如果数量相等,通知服务器进行分片合并
                    Log.e("TAG", "handleUploadPartFile: 分片通知合并,并且将mp4上传表格里面的记录删除" );
                    delete(filePath);
                    return lastModifiedTime+";"+md5;
                }else {
                    //如果数量不相等，进行分片+1更新
                    updateUpState(filePath,"100",""+chunkIndex,""+chunkNumber);
//                    queryByPath(filePath);
                    return null;
                }

            }

            return null;

        }finally {
            if (cursor!=null)
                cursor.close();

        }

    }

    /**
     *
     * @param filePath 根据文件地址查看上传数据
     * @return
     */
    public UploadItem checkFilePathUploadRecord(String filePath){
        UploadItem uploadItem=null;
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            //        sdb.execSQL("select FilePath from upload_file where UploadState=?");
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            cursor = sdb.rawQuery("select upstate,ext,md5,originName,size,lastModifiedTime from upload_file where filePath=?", new String[]{filePath});
            int fileState=-1;
//        cursor.moveToLast();
            if(cursor.moveToFirst()){
                uploadItem=new UploadItem();
                //一开始我在select 后面写少了FileSize，结果老是报错
                //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                fileState=cursor.getInt(cursor.getColumnIndex("upstate"));
                String ext=cursor.getString(cursor.getColumnIndex("ext"));
                String md5=cursor.getString(cursor.getColumnIndex("md5"));
                String originName=cursor.getString(cursor.getColumnIndex("originName"));
                String size=cursor.getString(cursor.getColumnIndex("size"));
                String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));

                uploadItem.setUploadState(fileState);
                uploadItem.setExt(ext);
                uploadItem.setMd5(md5);
                uploadItem.setOriginName(originName);
                uploadItem.setSize(size);
                uploadItem.setLastModifiedTime(lastModifiedTime);
//            Log.e("tiwolf", "check:"+filePath );
//            Log.e("tiwolf", "check:"+ext );
//            Log.e("tiwolf", "check:"+md5 );
//            Log.e("tiwolf", "check:"+originName );
//            Log.e("tiwolf", "check:"+size );
//            Log.e("tiwolf", "check:"+lastModifiedTime );
            }
            if (fileState==-1){
                return null;
            }

            Log.e("tiwolf", "check:"+fileState );
        }finally {
            if (cursor!=null)
                cursor.close();
            return uploadItem;
        }

//        cursor.close();
//        return uploadItem;
    }

    /**
     * 仅仅查询最近添加一条数据来上传
     * @param fileState
     * @return
     */
    public synchronized UploadItem checkIsUploading(String fileState){
        UploadItem uploadItem=null;
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            String filePath="kong";
            //        sdb.execSQL("select FilePath from upload_file where UploadState=?");
            cursor = sdb.rawQuery("select filePath,ext,md5,originName,size,lastModifiedTime from upload_file where upstate=?", new String[]{"9"});
            if (cursor.moveToFirst()){
                if(cursor.moveToFirst()){
                    uploadItem=new UploadItem();
                    //一开始我在select 后面写少了FileSize，结果老是报错
                    //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                    filePath=cursor.getString(cursor.getColumnIndex("filePath"));
                    String ext=cursor.getString(cursor.getColumnIndex("ext"));
                    String md5=cursor.getString(cursor.getColumnIndex("md5"));
                    String originName=cursor.getString(cursor.getColumnIndex("originName"));
                    String size=cursor.getString(cursor.getColumnIndex("size"));
                    String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));

                    uploadItem.setFilePath(filePath);
                    uploadItem.setExt(ext);
                    uploadItem.setMd5(md5);
                    uploadItem.setOriginName(originName);
                    uploadItem.setSize(size);
                    uploadItem.setLastModifiedTime(lastModifiedTime);
//            Log.e("tiwolf", "check:"+filePath );
//            Log.e("tiwolf", "check:"+ext );
//            Log.e("tiwolf", "check:"+md5 );
//            Log.e("tiwolf", "check:"+originName );
//            Log.e("tiwolf", "check:"+size );
//            Log.e("tiwolf", "check:"+lastModifiedTime );
                }
            }else{
                //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
                cursor = sdb.rawQuery("select filePath,ext,md5,originName,size,lastModifiedTime from upload_file where upstate=?", new String[]{fileState});
//        Cursor cursor = sdb.rawQuery("select FilePath from upload_file where UploadState=?", new String[]{fileState});

//        cursor.moveToLast();
                if(cursor.moveToFirst()){
                    uploadItem=new UploadItem();
                    //一开始我在select 后面写少了FileSize，结果老是报错
                    //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                    filePath=cursor.getString(cursor.getColumnIndex("filePath"));
                    String ext=cursor.getString(cursor.getColumnIndex("ext"));
                    String md5=cursor.getString(cursor.getColumnIndex("md5"));
                    String originName=cursor.getString(cursor.getColumnIndex("originName"));
                    String size=cursor.getString(cursor.getColumnIndex("size"));
                    String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));

                    uploadItem.setFilePath(filePath);
                    uploadItem.setExt(ext);
                    uploadItem.setMd5(md5);
                    uploadItem.setOriginName(originName);
                    uploadItem.setSize(size);
                    uploadItem.setLastModifiedTime(lastModifiedTime);
//            Log.e("tiwolf", "check:"+filePath );
//            Log.e("tiwolf", "check:"+ext );
//            Log.e("tiwolf", "check:"+md5 );
//            Log.e("tiwolf", "check:"+originName );
//            Log.e("tiwolf", "check:"+size );
//            Log.e("tiwolf", "check:"+lastModifiedTime );
                }
            }

            if ("kong".equals(filePath)){
                return null;
            }

            Log.e("tiwolf", "check:"+filePath );
        }finally {
            if (cursor!=null)
                cursor.close();
            return uploadItem;
        }

//        cursor.close();
//        return uploadItem;
    }

//    public static String chunkSize="chunkSize";
//    public static String index="index";
//    public static String md5="md5";
//    public static String owner="owner";
//    public static String endUser="endUser";
//    public static String chunkIndex="chunkIndex";
//    public static String chunkNumber="chunkNumber";
//    public static String ext="ext";
//    public static String file="file";
//    public static String lastModifiedTime="lastModifiedTime";
//    public static String originName="originName";
//    public static String filePath="filePath";
//    public static String size="size";
//    public static String devicelig="DEVICELIG";
//    public static String upstate="upstate";

    /**
     * 仅仅查询最近添加一条数据来上传
     * @return
     */
    public synchronized UploadItem checkIsUploadingFile(){
        UploadItem uploadItem=null;
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        uploadItem=getUploadFileItem(sdb,uploadItem,"9");    //报警文件
        if (uploadItem!=null){
            return uploadItem;
        }else{
            uploadItem=getUploadFileItem(sdb,uploadItem,"2");  //普通文件 上传失败或者正在上传;
            if (uploadItem!=null){
                return uploadItem;
            }else{
                uploadItem=getUploadFileItem(sdb,uploadItem,"100");    //分片上传
                if (uploadItem!=null){
                    return uploadItem;
                }else{
                    uploadItem=getUploadFileItem(sdb,uploadItem,"0");    //文件未上传状态
                    if (uploadItem!=null){
                        return uploadItem;
                    }else{
                        //当前没有上传的文件
                        return null;
                    }
                }
            }
        }

    }

    private UploadItem getUploadFileItem(SQLiteDatabase sdb,UploadItem uploadItem,String update){
        String filePath="kong";
        //        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor = null;
        try {
            cursor = sdb.rawQuery("select filePath,ext,md5,originName,size,lastModifiedTime,chunkNumber,chunkIndex from upload_file where upstate=?", new String[]{update});
            if (cursor.moveToFirst()){
                if(cursor.moveToFirst()){
                    uploadItem=new UploadItem();
                    //一开始我在select 后面写少了FileSize，结果老是报错
                    //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                    filePath=cursor.getString(cursor.getColumnIndex("filePath"));
                    String ext=cursor.getString(cursor.getColumnIndex("ext"));
                    String md5=cursor.getString(cursor.getColumnIndex("md5"));
                    String originName=cursor.getString(cursor.getColumnIndex("originName"));
                    String size=cursor.getString(cursor.getColumnIndex("size"));
                    String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));
                    int chunkIndex=cursor.getInt(cursor.getColumnIndex("chunkIndex"));
                    int chunkNumber=cursor.getInt(cursor.getColumnIndex("chunkNumber"));

                    uploadItem.setFilePath(filePath);
                    uploadItem.setExt(ext);
                    uploadItem.setMd5(md5);
                    uploadItem.setOriginName(originName);
                    uploadItem.setSize(size);
                    uploadItem.setLastModifiedTime(lastModifiedTime);
                    uploadItem.setChunkIndex(chunkIndex);
                    uploadItem.setChunkNumber(chunkNumber);
                    uploadItem.setUploadState(Integer.valueOf(update));


//            Log.e("tiwolf", "check:"+filePath );
//            Log.e("tiwolf", "check:"+ext );
//            Log.e("tiwolf", "check:"+md5 );
//            Log.e("tiwolf", "check:"+originName );
//            Log.e("tiwolf", "check:"+size );
//            Log.e("tiwolf", "check:"+lastModifiedTime );
                }else{
                    return null;
                }
                if ("kong".equals(filePath)){
                    return null;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }finally {
            if (cursor!=null)
                cursor.close();
            return uploadItem;
        }
    }

    /**
     * 查询全部正在上传的数据
     * @param fileSate
     * @return
     */
    public List<String> chechAll(String fileSate){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        List<String> list=null;
        try {
            cursor= sdb.query("upload_file",new String[]{"chunkNumber","chunkIndex","filePath","ext","md5","originName","size","chunkSize","lastModifiedTime"},"upstate=?",new String[]{fileSate},null,null,null);
            list=new ArrayList<>();
            while (cursor.moveToNext()){
                Log.e("tiwolf", "chechAll:"+cursor.getString(0));
                list.add("路径："+cursor.getString(cursor.getColumnIndex("FilePath"))+",大小为："+cursor.getString(cursor.getColumnIndex("FileSize"))+",已上传："+cursor.getString(cursor.getColumnIndex("FileUploadSize")));
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return list;
        }

//        cursor.close();
//        return list;
    }

    /**
     * 查询全部正在上传的数据
     * @param md5
     * @return
     */
    public List<UploadItem> checkIsUpload(String md5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        List<UploadItem> list=null;
        try {
            cursor= sdb.query("upload_file",new String[]{"chunkNumber","chunkIndex","filePath","ext","originName","size","chunkSize","lastModifiedTime"},"md5=?",new String[]{md5},null,null,null);
            list=new ArrayList<>();
            while (cursor.moveToNext()){
//            Log.e("tiwolf", "chechAll:"+cursor.getString(0));

                UploadItem uploadItem=new UploadItem();
                String filePath=cursor.getString(cursor.getColumnIndex("filePath"));
                String ext=cursor.getString(cursor.getColumnIndex("ext"));
                String originName=cursor.getString(cursor.getColumnIndex("originName"));
                String size=cursor.getString(cursor.getColumnIndex("size"));
                int  chunkNumber=cursor.getInt(cursor.getColumnIndex("chunkNumber"));
                int chunkIndex=cursor.getInt(cursor.getColumnIndex("chunkIndex"));
                String chunkSize=cursor.getString(cursor.getColumnIndex("chunkSize"));
                String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));

                uploadItem.setFilePath(filePath);
                uploadItem.setExt(ext);
                uploadItem.setMd5(md5);
                uploadItem.setOriginName(originName);
                uploadItem.setSize(size);
                uploadItem.setChunkIndex(chunkIndex);
                uploadItem.setChunkNumber(chunkNumber);
                uploadItem.setChunkSize(chunkSize);
                uploadItem.setLastModifiedTime(lastModifiedTime);
                list.add(uploadItem);
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return list;
        }

//        return list;
    }

    /**
     * 查询全部正在上传的数据
     * @param fileSate
     * @return
     */
    public ArrayList<UploadItem> chechUploadAll(String fileSate){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        ArrayList<UploadItem> list=null;
        try {
            cursor= sdb.query("upload_file",new String[]{"chunkNumber","chunkIndex","filePath","ext","md5","originName","size","chunkSize","lastModifiedTime"},"upstate=?",new String[]{fileSate},null,null,null);
            list=new ArrayList<>();
            while (cursor.moveToNext()){
                Log.i("tiwolf", "chechAll:"+cursor.getString(0));
//            list.add("路径："+cursor.getString(cursor.getColumnIndex("FilePath"))+",大小为："+cursor.getString(cursor.getColumnIndex("FileSize"))+",已上传："+cursor.getString(cursor.getColumnIndex("FileUploadSize")));
                UploadItem uploadItem=new UploadItem();
                String filePath=cursor.getString(cursor.getColumnIndex("filePath"));
                String ext=cursor.getString(cursor.getColumnIndex("ext"));
                String md5=cursor.getString(cursor.getColumnIndex("md5"));
                String originName=cursor.getString(cursor.getColumnIndex("originName"));
                String size=cursor.getString(cursor.getColumnIndex("size"));
                int  chunkNumber=cursor.getInt(cursor.getColumnIndex("chunkNumber"));
                int chunkIndex=cursor.getInt(cursor.getColumnIndex("chunkIndex"));
                String chunkSize=cursor.getString(cursor.getColumnIndex("chunkSize"));
                String lastModifiedTime=cursor.getString(cursor.getColumnIndex("lastModifiedTime"));

                uploadItem.setFilePath(filePath);
                uploadItem.setExt(ext);
                uploadItem.setMd5(md5);
                uploadItem.setOriginName(originName);
                uploadItem.setSize(size);
                uploadItem.setChunkIndex(chunkIndex);
                uploadItem.setChunkNumber(chunkNumber);
                uploadItem.setChunkSize(chunkSize);
                uploadItem.setLastModifiedTime(lastModifiedTime);

                list.add(uploadItem);
            }
        }finally {
            if (cursor!=null){
                cursor.close();
            }
            return list;
        }

//        cursor.close();
//        return list;
    }

    public void clearUploadTab(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from upload_file;");
    }


    /**
     * =============================上传=================================
     */

    /**
     * =============================播放的增删改查=================================
     */
    /**
     * @param alarm  //根据闹钟获取到播放列表,根据升序排列添加到list里面
     * @return
     */
    public ArrayList<PlayItem> playCheckSingleUrl(String alarm){

        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        ArrayList<PlayItem> list=null;
        try {
            if (Integer.valueOf(alarm)%2==0){
                cursor= sdb.query("play_list",new String[]{"startTime","endTime","content","downloadMd5","playExt","playName","playType","downloadTotal","downloadId","playTime","playIndex","volumn","mediaName","avTime"},"alarm2=?",new String[]{alarm},null,null,"playIndex asc");

            }else {

                cursor= sdb.query("play_list",new String[]{"startTime","endTime","content","downloadMd5","playExt","playName","playType","downloadTotal","downloadId","playTime","playIndex","volumn","mediaName","avTime"},"alarm1=?",new String[]{alarm},null,null,"playIndex asc");
            }
            list=new ArrayList<>();
            while(cursor.moveToNext()){
                PlayItem playItem=new PlayItem();
                String playExt=cursor.getString(cursor.getColumnIndex("playExt"));
                String downloadTotal=cursor.getString(cursor.getColumnIndex("downloadTotal"));
                int downloadId=cursor.getInt(cursor.getColumnIndex("downloadId"));
                String downloadMd5=cursor.getString(cursor.getColumnIndex("downloadMd5"));
                String downloadName=cursor.getString(cursor.getColumnIndex("playName"));
                int playTime=cursor.getInt(cursor.getColumnIndex("playTime"));
                int playIndex=cursor.getInt(cursor.getColumnIndex("playIndex"));
                int playType=cursor.getInt(cursor.getColumnIndex("playType"));
                String content=cursor.getString(cursor.getColumnIndex("content"));
                String startTime=cursor.getString(cursor.getColumnIndex("startTime"));
                String endTime=cursor.getString(cursor.getColumnIndex("endTime"));
                int volumn=cursor.getInt(cursor.getColumnIndex("volumn"));
                String avTime=cursor.getString(cursor.getColumnIndex("avTime"));
                String mediaName=cursor.getString(cursor.getColumnIndex("mediaName"));
                playItem.setDownloadMd5(downloadMd5);
                playItem.setPlayExt(playExt);
                playItem.setDownloadTotal(downloadTotal);
                playItem.setDownloadId(downloadId);
                playItem.setPlayName(downloadName);
                playItem.setPlayTime(playTime);
                playItem.setPlayIndex(playIndex);
                playItem.setPlayType(playType);
                playItem.setContent(content);
                playItem.setStartTime(startTime);
                playItem.setEndTime(endTime);
                playItem.setVolumn(volumn);
                playItem.setAvTime(avTime);
                playItem.setMediaName(mediaName);
                list.add(playItem);
            }
        }finally {
            if (cursor!=null){
                cursor.close();
            }
            return list;
        }

//        cursor.close();
//        return list;
    }

    /**
     * 更新某一条数据音量,这个需要注意符号
     * @param voice
     * @param alarm
     */
    public void updatePlayVolumn(String voice,String alarm){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: voice"+voice+"--"+"id="+alarm);
//        sdb.update("upload_file",contentValues,null,null);
        String sql;
        if (Integer.valueOf(alarm)%2==0){
            sql="update play_list set volumn = "+voice+" where alarm2 = '"+alarm+"'";
        }else {
            sql="update play_list set volumn = "+voice+" where alarm1 = '"+alarm+"'";
        }
        //修改SQL语句

        sdb.execSQL(sql);

    }

    /**
     * 更新整个播放列表的音量
     * @param voice
     */
    public void updateAllPlayVolume(String voice){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        String sql="update play_list set volumn ="+voice;
        sdb.execSQL(sql);
    }

    /**
     * 根据MD5判断是否已经添加过
     * @param downloadMd5
     * @return
     */
    public boolean playCheckAllUrl(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            cursor = sdb.rawQuery("select downloadId from play_list where downloadMd5=?", new String[]{downloadMd5});
//            Log.e("播放问题", "playCheckAllUrl: 1111111111111");
            return cursor.moveToFirst();
        }finally {
            if (cursor!=null)
                cursor.close();
//            Log.e("播放问题", "playCheckAllUrl: 22222222222222222");
        }

    }

    /**
     * 添加到数据库
     */
    public void addPlayItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("play_list",null,contentValues);
    }

    /**
     * 更新下载进度
     * @param downloadLength  当前下载的进度
     * @param downloadFlag   下载的标志
     * @param downloadMd5   md5
     */
    public void updatePlayer(String downloadLength,int downloadFlag,String downloadMd5){

        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.i("tiwolf", "update: downloadMd5="+downloadMd5+";downloadLength="+downloadLength+";downloadFlag="+downloadFlag );
//        sdb.update("upload_file",contentValues,null,null);
        String sql=null;
        if (downloadFlag==2){
            //说明已经下载完成了
            sql="update download_file set downloadFlag = "+downloadFlag+" where downloadMd5 = '"+downloadMd5+"'";
        }else {
            //修改SQL语句,更改进度
            sql="update download_file set downloadLength = "+downloadLength+",downloadFlag = "+downloadFlag+" where downloadMd5 = '"+downloadMd5+"'";
        }
        sdb.execSQL(sql);
    }

    /**
     * 更新下载进度
     * @param downloadLength  当前下载的进度
     * @param downloadMd5   md5
     */
    public void updatePlayer(String downloadLength,String downloadMd5){

        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.i("tiwolf", "update: downloadMd5="+downloadMd5+";downloadLength="+downloadLength );
//        sdb.update("upload_file",contentValues,null,null);
        String sql=null;
        //修改SQL语句,更改进度
        sql="update download_file set downloadLength = "+downloadLength+" where downloadMd5 = '"+downloadMd5+"'";

        sdb.execSQL(sql);
    }

    /**
     * 根据闹钟id删除广告list
     * @param alarmId
     */
    public void deleteMusicList(String alarmId){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from play_list where alarmId=?",new Object[]{alarmId});
    }

    /**
     * 删除整个表格数据
     */
    public void clearTable(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from play_list;");
    }

    /**
     * 根据闹钟id删除广告list
     * @param downloadMd5
     */
    public void deleteMusicFile(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from play_list where downloadMd5=?",new Object[]{downloadMd5});
    }


    /**
     * ==============================下载的增删改查===================================
     */

    /**
     * 使用下载状态来查询是否已经下载过，主要是在断网重连时使用  这个主要是获取一个列表下载
     * @param downloadFlag
     * @return
     */
    public ArrayList<DownloadItem> downloadFlagCheck(String downloadFlag){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        ArrayList<DownloadItem> list=null;
        try {
            cursor= sdb.query("download_file",new String[]{"downloadLength","downloadTotal","downloadId","downloadMd5","downloadName","downloadExt","playType"},"downloadFlag=?",new String[]{downloadFlag},null,null,null);
            list=new ArrayList<>();
            while(cursor.moveToNext()){
                DownloadItem downloadItem=new DownloadItem();
                String downloadLength=cursor.getString(cursor.getColumnIndex("downloadLength"));
                String downloadTotal=cursor.getString(cursor.getColumnIndex("downloadTotal"));
                int downloadId=cursor.getInt(cursor.getColumnIndex("downloadId"));
                String downloadMd5=cursor.getString(cursor.getColumnIndex("downloadMd5"));
                String downloadName=cursor.getString(cursor.getColumnIndex("downloadName"));
                String downloadExt=cursor.getString(cursor.getColumnIndex("downloadExt"));
                int playType=cursor.getInt(cursor.getColumnIndex("playType"));
                downloadItem.setDownloadLength(downloadLength);
                downloadItem.setDownloadTotal(downloadTotal);
                downloadItem.setDownloadId(downloadId);
                downloadItem.setDownloadMd5(downloadMd5);
                downloadItem.setDownloadName(downloadName);
                downloadItem.setDownloadExt(downloadExt);
                downloadItem.setPlayType(playType);
                list.add(downloadItem);
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return list;
        }

//        cursor.close();
//        return list;
    }

    /**
     * 使用下载状态来查询是否已经下载过，主要是在断网重连时使用 这里只会获取一个文件
     * @param downloadFlag
     * @return
     */
    public DownloadItem downloadFlagCheckSingleFile(String downloadFlag){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        DownloadItem downloadItem=null;
        try {
            cursor= sdb.query("download_file",new String[]{"downloadLength","downloadTotal","downloadId","downloadMd5","downloadName","downloadExt","playType"},"downloadFlag=?",new String[]{downloadFlag},null,null,null);

            while(cursor.moveToFirst()){
                downloadItem=new DownloadItem();
                String downloadLength=cursor.getString(cursor.getColumnIndex("downloadLength"));
                String downloadTotal=cursor.getString(cursor.getColumnIndex("downloadTotal"));
                int downloadId=cursor.getInt(cursor.getColumnIndex("downloadId"));
                String downloadMd5=cursor.getString(cursor.getColumnIndex("downloadMd5"));
                String downloadName=cursor.getString(cursor.getColumnIndex("downloadName"));
                String downloadExt=cursor.getString(cursor.getColumnIndex("downloadExt"));
                int playType=cursor.getInt(cursor.getColumnIndex("playType"));
                downloadItem.setDownloadLength(downloadLength);
                downloadItem.setDownloadTotal(downloadTotal);
                downloadItem.setDownloadId(downloadId);
                downloadItem.setDownloadMd5(downloadMd5);
                downloadItem.setDownloadName(downloadName);
                downloadItem.setDownloadExt(downloadExt);
                downloadItem.setPlayType(playType);
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return downloadItem;
        }

//        cursor.close();
//        return list;
    }

    /**
     * 使用md5来查询是否已经下载（如果未下载完，去下载，如果标志下载完，那么去播放），然后在使用url播放的时候，看是否为空，如果为空，则重新下载
     * @param downloadMd5
     * @return
     */
    public DownloadItem downloadIdCheck(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);

        Cursor cursor=null;
        DownloadItem downloadItem=null;
        try {
            cursor= sdb.query("download_file",new String[]{"downloadLength","downloadId","downloadTotal","downloadFlag","downloadName","downloadExt","playType"},"downloadMd5=?",new String[]{downloadMd5},null,null,null);
//        ArrayList<DownloadItem> list=new ArrayList<>();
//        cursor.moveToFirst();
            downloadItem=new DownloadItem();
//        Log.e("tiwolf", "downloadIdCheck: 是否有数据"+cursor.moveToNext() );
            if (cursor.moveToFirst()){
                String downloadLength=cursor.getString(cursor.getColumnIndex("downloadLength"));
                String downloadTotal=cursor.getString(cursor.getColumnIndex("downloadTotal"));
                int downloadId=cursor.getInt(cursor.getColumnIndex("downloadId"));
                int downloadFlag=cursor.getInt(cursor.getColumnIndex("downloadFlag"));
                String downloadName=cursor.getString(cursor.getColumnIndex("downloadName"));
                String downloadExt=cursor.getString(cursor.getColumnIndex("downloadExt"));
                int playType=cursor.getInt(cursor.getColumnIndex("playType"));
                downloadItem.setDownloadLength(downloadLength);
                downloadItem.setDownloadTotal(downloadTotal);
                downloadItem.setDownloadId(downloadId);
                downloadItem.setDownloadMd5(downloadMd5);
                downloadItem.setDownloadName(downloadName);
                downloadItem.setDownloadExt(downloadExt);
                downloadItem.setPlayType(playType);
                downloadItem.setDownloadFlag(downloadFlag);
            }

        }finally {
            if (cursor!=null)
                cursor.close();
            return downloadItem;
        }

//        cursor.close();
//        return downloadItem;
    }

    //根据 MD5来获取当前的下载状态
    public int AvDownloadFlag(String md5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        int downloadFlag=1;
        try {
            cursor= sdb.query("download_file",new String[]{"downloadLength","downloadId","downloadTotal","downloadFlag","downloadName","downloadExt","playType"},"downloadMd5=?",new String[]{md5},null,null,null);
//        ArrayList<DownloadItem> list=new ArrayList<>();
//        cursor.moveToFirst();

//        Log.e("tiwolf", "downloadIdCheck: 是否有数据"+cursor.moveToNext() );
            if (cursor.moveToFirst()){
//            String downloadLength=cursor.getString(cursor.getColumnIndex("downloadLength"));
//            String downloadTotal=cursor.getString(cursor.getColumnIndex("downloadTotal"));
//            int downloadId=cursor.getInt(cursor.getColumnIndex("downloadId"));
                downloadFlag=cursor.getInt(cursor.getColumnIndex("downloadFlag"));
//            String downloadName=cursor.getString(cursor.getColumnIndex("downloadName"));
//            String downloadExt=cursor.getString(cursor.getColumnIndex("downloadExt"));
//            int playType=cursor.getInt(cursor.getColumnIndex("playType"));
            }

        }finally {
            if (cursor!=null)
                cursor.close();
        }

//        cursor.close();
        return downloadFlag;
    }

    /**
     * 如果未下载完，去下载，如果标志下载完，那么去播放
     * @param downloadMd5
     * @return
     */
    public boolean canPlayOrNot(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);
        Cursor cursor=null;
        int downloadFlag=1;
        try {
            cursor= sdb.query("download_file",new String[]{"downloadFlag"},"downloadMd5=?",new String[]{downloadMd5},null,null,null);
//        ArrayList<DownloadItem> list=new ArrayList<>();
//        cursor.moveToFirst();
//            DownloadItem downloadItem=new DownloadItem();

//        Log.e("tiwolf", "downloadIdCheck: 是否有数据"+cursor.moveToNext() );
            if (cursor.moveToFirst()){
//            String downloadLength=cursor.getString(cursor.getColumnIndex("downloadLength"));
//            String downloadTotal=cursor.getString(cursor.getColumnIndex("downloadTotal"));
//            int downloadId=cursor.getInt(cursor.getColumnIndex("downloadId"));
                downloadFlag=cursor.getInt(cursor.getColumnIndex("downloadFlag"));
//            String downloadName=cursor.getString(cursor.getColumnIndex("downloadName"));
//            String downloadExt=cursor.getString(cursor.getColumnIndex("downloadExt"));
//            int playType=cursor.getInt(cursor.getColumnIndex("playType"));
//            downloadItem.setDownloadFlag(downloadFlag);
            }

        }finally {
            if (cursor!=null)
                cursor.close();
        }



//        cursor.close();
        if (downloadFlag==1){
            return false;
        }else {
            return true;
        }
    }


    /**
     * 添加数据库前，先查询是否有过这个md5，防止多个出现 这个是下载列表
     * @param downloadMd5
     * @return
     */
    public boolean downloadCheckSingleUrl(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            cursor = sdb.rawQuery("select downloadId from download_file where downloadMd5=?", new String[]{downloadMd5});
//            Log.e("下载步骤", "downloadCheckSingleUrl: 111111111111" );
            return cursor.moveToFirst();
        }finally {
            if (cursor!=null)
                cursor.close();
//            Log.e("下载步骤", "downloadCheckSingleUrl: 22222222222" );
        }
    }

    /**
     * 添加到数据库
     */
    public void addDownLoadItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("download_file",null,contentValues);
    }

    /**
     * 更新下载进度
     * @param downloadLength  当前下载的进度
     * @param downloadFlag   下载的标志
     * @param downloadMd5   md5
     */
    public void updateDownloadLength(String downloadLength,int downloadFlag,String downloadMd5){

        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: downloadMd5="+downloadMd5+";downloadLength="+downloadLength+";downloadFlag="+downloadFlag );
//        sdb.update("upload_file",contentValues,null,null);
        String sql=null;
        if (downloadFlag==2){
            //说明已经下载完成了
            sql="update download_file set downloadFlag = "+downloadFlag+" where downloadMd5 = '"+downloadMd5+"'";
        }else {
            //修改SQL语句,更改进度和标志
            sql="update download_file set downloadLength = "+downloadLength+",downloadFlag = "+downloadFlag+" where downloadMd5 = '"+downloadMd5+"'";
        }
        sdb.execSQL(sql);
    }

    /**
     * 更新下载标志，避免多次下载
     * @param downloadFlag   下载的标志
     * @param downloadMd5   md5
     */
    public void updateDownloadFlag(int downloadFlag,String downloadMd5){

        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: downloadMd5="+downloadMd5+";downloadFlag="+downloadFlag );
//        sdb.update("upload_file",contentValues,null,null);
        String sql=null;

        sql="update download_file set downloadFlag = "+downloadFlag+" where downloadMd5 = '"+downloadMd5+"'";

        sdb.execSQL(sql);
    }

    //设备启动的时候将downloadFlag下载的时候为3变回为1，主要是为了突然断电导致的问题
    public void updateAllDownloadFlag(int status){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        String sql="update download_file set downloadFlag = "+status+" where downloadFlag = 3";
        Log.e("tiwolf", "updateAllDownloadFlag: 将3状态变成1" );
        sdb.execSQL(sql);
    }

    public void updateDownloadFlags(int status){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        String sql="update download_file set downloadFlag = "+status;
        Log.e("tiwolf", "updateAllDownloadFlag: 格式化TFcard的时候将全部状态变成1" );
        sdb.execSQL(sql);
    }


    /**
     * 根据某个地址删除item
     * @param downloadMd5
     */
    public void deleteDownloadItem(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from download_file where downloadMd5=?",new Object[]{downloadMd5});
    }



    public void clearDownloadTab(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from download_file;");
    }



    public void closeDb(){
        if (sqliteHelper!=null){
            SQLiteDatabase sqlDb=sqliteHelper.getWritableDatabase();
            if (sqlDb!=null)sqlDb.close();
        }
    }


    /**
     * ===========================广播的增删改查=================================
     */

    /**
     * 添加一个item进去
     * @param contentValues
     */
    public void saveAvItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("text_list",null,contentValues);
        Log.e("tiwolf", "saveAvItem: "+contentValues.get("alarmId") );
    }

    /**
     * 删除某一个item
     * @param id
     */
    public void deleteAv(String id){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from text_list where id=?",new Object[]{id});
        Log.e("tiwolf", "delete: "+id );
    }

    /**
     * 更新某一条数据内容,这个需要注意符号
     * @param contentValues
     */
    public void updateAv(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: "+contentValues.get("content")+"--"+contentValues.get("id") );
//        sdb.update("upload_file",contentValues,null,null);
        //修改SQL语句
        String sql="update text_list set content = "+contentValues.get("content")+" where id = '"+contentValues.get("id")+"'";
        sdb.execSQL(sql);

    }

    /**
     * 更新某一条数据音量,这个需要注意符号
     * @param voice
     * @param id
     */
    public void updateAvVolumn(String voice,String id){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: voice"+voice+"--"+"id="+id);
//        sdb.update("upload_file",contentValues,null,null);
        //修改SQL语句
        String sql="update text_list set volumn = "+voice+" where alarmId = '"+id+"'";
        sdb.execSQL(sql);

    }

    /**
     * 仅仅查询一条数据
     * @param alarm1
     * @return
     */
    public AlarmAvBean checkAv(String alarm1){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        AlarmAvBean alarmAvBean = null;
        try {
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            cursor = sdb.rawQuery("select content,broadcastId,times,status,alarmId,startTime,volumn from text_list where alarm1=?", new String[]{alarm1});
//        Cursor cursor = sdb.rawQuery("select FilePath from upload_file where UploadState=?", new String[]{fileState});
            String content="kong";
//        cursor.moveToLast();
            if(cursor.moveToFirst()){
                //一开始我在select 后面写少了FileSize，结果老是报错
                //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                content=cursor.getString(cursor.getColumnIndex("content"));
                int broadcastId=cursor.getInt(cursor.getColumnIndex("broadcastId"));
                int times=cursor.getInt(cursor.getColumnIndex("times"));
                int status=cursor.getInt(cursor.getColumnIndex("status"));
                int alarmId=cursor.getInt(cursor.getColumnIndex("alarmId"));
                String startTime=cursor.getString(cursor.getColumnIndex("startTime"));
                int volumn=cursor.getInt(cursor.getColumnIndex("volumn"));
                if (content.trim().length()==0){
                    return null;
                }else {
                    alarmAvBean=new AlarmAvBean();
                    alarmAvBean.setBroadcastId(broadcastId);
                    alarmAvBean.setContent(content);
                    alarmAvBean.setId(alarmId);
                    alarmAvBean.setStartTime(startTime);
                    alarmAvBean.setStatus(status);
                    alarmAvBean.setTimes(times);
                    alarmAvBean.setVolume(volumn);
                }

            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return alarmAvBean;
        }

//        return alarmAvBean;
    }

    /**
     * 删除整个表格数据
     */
    public void clearAvTable(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from text_list;");
    }
    /**
     * ==============================广播End====================================
     */

    /**
     * =============================公益广告的增删改查=================================
     */
    /**
     * @param alarm  //根据闹钟获取到播放列表,根据升序排列添加到list里面
     * @return
     */
    public ArrayList<PlayItem> playCountryUrl(String alarm){

        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        ArrayList<PlayItem> list=null;
        try {
            if (Integer.valueOf(alarm)%2==0){
                cursor= sdb.query("country_list",new String[]{"startTime","endTime","content","downloadMd5","playExt","playName","playType","downloadTotal","downloadId","playTime","playIndex","volumn","avTime"},"alarm2=?",new String[]{alarm},null,null,"playIndex asc");

            }else {

                cursor= sdb.query("country_list",new String[]{"startTime","endTime","content","downloadMd5","playExt","playName","playType","downloadTotal","downloadId","playTime","playIndex","volumn","avTime"},"alarm1=?",new String[]{alarm},null,null,"playIndex asc");
            }
            list=new ArrayList<>();
            while(cursor.moveToNext()){
                PlayItem playItem=new PlayItem();
                String playExt=cursor.getString(cursor.getColumnIndex("playExt"));
                String downloadTotal=cursor.getString(cursor.getColumnIndex("downloadTotal"));
                int downloadId=cursor.getInt(cursor.getColumnIndex("downloadId"));
                String downloadMd5=cursor.getString(cursor.getColumnIndex("downloadMd5"));
                String downloadName=cursor.getString(cursor.getColumnIndex("playName"));
                int playTime=cursor.getInt(cursor.getColumnIndex("playTime"));
                int playIndex=cursor.getInt(cursor.getColumnIndex("playIndex"));
                int playType=cursor.getInt(cursor.getColumnIndex("playType"));
                String content=cursor.getString(cursor.getColumnIndex("content"));
                String startTime=cursor.getString(cursor.getColumnIndex("startTime"));
                String endTime=cursor.getString(cursor.getColumnIndex("endTime"));
                int volumn=cursor.getInt(cursor.getColumnIndex("volumn"));
                String avTime=cursor.getString(cursor.getColumnIndex("avTime"));
                playItem.setDownloadMd5(downloadMd5);
                playItem.setPlayExt(playExt);
                playItem.setDownloadTotal(downloadTotal);
                playItem.setDownloadId(downloadId);
                playItem.setPlayName(downloadName);
                playItem.setPlayTime(playTime);
                playItem.setPlayIndex(playIndex);
                playItem.setPlayType(playType);
                playItem.setContent(content);
                playItem.setStartTime(startTime);
                playItem.setEndTime(endTime);
                playItem.setVolumn(volumn);
                playItem.setAvTime(avTime);
                list.add(playItem);
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return list;
        }
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);

//        cursor.close();
//        return list;
    }

    /**
     * 更新某一条数据音量,这个需要注意符号
     * @param voice
     * @param alarm
     */
    public void updateCountryVolumn(String voice,String alarm){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: voice"+voice+"--"+"id="+alarm);
//        sdb.update("upload_file",contentValues,null,null);
        String sql;
        if (Integer.valueOf(alarm)%2==0){
            sql="update country_list set volumn = "+voice+" where alarm2 = '"+alarm+"'";
        }else {
            sql="update country_list set volumn = "+voice+" where alarm1 = '"+alarm+"'";
        }
        //修改SQL语句

        sdb.execSQL(sql);

    }

    /**
     * 更新整个播放列表的音量
     * @param voice
     */
    public void updateAllCountryVolume(String voice){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        String sql="update country_list set volumn ="+voice;
        sdb.execSQL(sql);
    }

    /**
     * 根据MD5判断是否已经添加过
     * @param downloadMd5
     * @return
     */
    public boolean playCountryCheckAllUrl(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            cursor = sdb.rawQuery("select downloadId from country_list where downloadMd5=?", new String[]{downloadMd5});
            if (cursor.moveToFirst()){
                return true;
            }else {
                return false;
            }
        }finally {
            if (cursor!=null)
                cursor.close();
        }

    }

    /**
     * 添加到数据库
     */
    public void addCountryItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("country_list",null,contentValues);
    }

    /**
     * 根据闹钟id删除广告list
     * @param alarmId
     */
    public void deleteCountryMusicList(String alarmId){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from country_list where alarmId=?",new Object[]{alarmId});
    }

    /**
     * 删除整个表格数据
     */
    public void clearCountryTable(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from country_list;");
    }

    /**
     * 根据闹钟id删除广告list
     * @param downloadMd5
     */
    public void deleteCountryMusicFile(String downloadMd5){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from country_list where downloadMd5=?",new Object[]{downloadMd5});
    }

    //*******************************update_record上传TFcard信息的增删改查**********************************
    /**
     * 添加到数据库
     */
    public void addUpdateRecord(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("update_record",null,contentValues);
        Log.e("tiwolf", "addUpdateRecord: 写入一条历史记录" );
    }

    /**
     * 根据已经上传的数据删除数据
     * @param content
     */
    public void deleteUpdateRecord(String content){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from update_record where rccontent=?",new Object[]{content});
        Log.e("tiwolf", "deleteUpdateRecord: 删除一条已上传的历史记录" );
    }

    /**
     * 删除整个表格数据 格式化的时候将用到这条指令
     */
    public void clearUpdateRecordTable(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from update_record;");
        Log.e("tiwolf", "clearUpdateRecordTable: 清空历史记录列表" );
    }

    //根据内容查询是否有这条数据
    public synchronized boolean updateRecordCheck(String recordContent){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor =null;
        boolean isUpdateFlag=false;
        try {
//            cursor= sdb.query("update_record",new String[]{"updateType","updateFlag","updateMsg","updateMg","dotime"},"rccontent=?",new String[]{recordContent},null,null,null);
            cursor = sdb.rawQuery("select * from update_record where rccontent=?", new String[]{recordContent});
            Log.e("tiwolf", "UpdateRecordCheck: 查询是否有这条历史记录  更新记录查询");
            if (cursor.moveToFirst()){
                isUpdateFlag=true;
            }
//            isUpdateFlag=cursor.moveToNext();
        }
        finally {
            if (cursor!=null)
                cursor.close();
            Log.e("tiwolf", "UpdateRecordCheck: 查询是否有这条历史记录得到的返回值为="+isUpdateFlag);
            return isUpdateFlag;
        }

//        cursor.close();
//        return isUpdateFlag;
    }

    //删掉数据库的一条数据之后，开始提取最前面的那条数据继续上传（上传到我司路由器获取到）
    public UpdateRecordBean recordCheckByType(){

        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        UpdateRecordBean updateRecordBean=new UpdateRecordBean();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        try {
            //这个是报警记录
            cursor = sdb.rawQuery("select rccontent,updateFlag,updateMsg,updateMg,dotime from update_record where updateType=?", new String[]{"9"});
            if (cursor.moveToFirst()){
                String rccontent=cursor.getString(cursor.getColumnIndex("rccontent"));
//                int updateType=cursor.getInt(cursor.getColumnIndex("updateType"));
                int updateFlag=cursor.getInt(cursor.getColumnIndex("updateFlag"));
                String updateMsg=cursor.getString(cursor.getColumnIndex("updateMsg"));
                String updateMg=cursor.getString(cursor.getColumnIndex("updateMg"));
                String dotime=cursor.getString(cursor.getColumnIndex("dotime"));
                updateRecordBean.setContent(rccontent);
                updateRecordBean.setUpdateFlag(updateFlag);
                updateRecordBean.setContentType(9);
                updateRecordBean.setUpdateMg(updateMg);
                updateRecordBean.setDotime(dotime);
                updateRecordBean.setUpdateMsg(updateMsg);
            }else {
                //这个是历史记录上传记录
                cursor = sdb.rawQuery("select rccontent,updateFlag,updateMsg,updateMg,dotime from update_record where updateType=?", new String[]{"8"});
                if (cursor.moveToFirst()){
                    String rccontent=cursor.getString(cursor.getColumnIndex("rccontent"));
//                int updateType=cursor.getInt(cursor.getColumnIndex("updateType"));
                    int updateFlag=cursor.getInt(cursor.getColumnIndex("updateFlag"));
                    String updateMsg=cursor.getString(cursor.getColumnIndex("updateMsg"));
                    String updateMg=cursor.getString(cursor.getColumnIndex("updateMg"));
                    String dotime=cursor.getString(cursor.getColumnIndex("dotime"));
                    updateRecordBean.setContent(rccontent);
                    updateRecordBean.setUpdateFlag(updateFlag);
                    updateRecordBean.setContentType(8);
                    updateRecordBean.setUpdateMg(updateMg);
                    updateRecordBean.setDotime(dotime);
                    updateRecordBean.setUpdateMsg(updateMsg);
                }else {
                    cursor = sdb.rawQuery("select rccontent,updateFlag,updateMsg,updateMg,dotime from update_record where updateType=?", new String[]{"2"});
                    if (cursor.moveToFirst()){
                        String rccontent=cursor.getString(cursor.getColumnIndex("rccontent"));
//                int updateType=cursor.getInt(cursor.getColumnIndex("updateType"));
                        int updateFlag=cursor.getInt(cursor.getColumnIndex("updateFlag"));
                        String updateMsg=cursor.getString(cursor.getColumnIndex("updateMsg"));
                        String updateMg=cursor.getString(cursor.getColumnIndex("updateMg"));
                        String dotime=cursor.getString(cursor.getColumnIndex("dotime"));
                        updateRecordBean.setContent(rccontent);
                        updateRecordBean.setUpdateFlag(updateFlag);
                        updateRecordBean.setContentType(2);
                        updateRecordBean.setUpdateMg(updateMg);
                        updateRecordBean.setDotime(dotime);
                        updateRecordBean.setUpdateMsg(updateMsg);
                    }else {
                        cursor = sdb.rawQuery("select rccontent,updateFlag,updateMsg,updateMg,dotime from update_record where updateType=?", new String[]{"10"});
                        if (cursor.moveToFirst()){

                            int updateFlag=cursor.getInt(cursor.getColumnIndex("updateFlag"));
                            String updateMsg=cursor.getString(cursor.getColumnIndex("updateMsg"));
                            updateRecordBean.setUpdateFlag(updateFlag);
                            updateRecordBean.setContentType(10);
                            updateRecordBean.setUpdateMsg(updateMsg);
                        }else {
                            cursor = sdb.query("update_record", null, null, null, null, null, null);
                            if (cursor.moveToFirst()){
                                String rccontent=cursor.getString(cursor.getColumnIndex("rccontent"));
                                int updateType=cursor.getInt(cursor.getColumnIndex("updateType"));
                                int updateFlag=cursor.getInt(cursor.getColumnIndex("updateFlag"));
                                String updateMsg=cursor.getString(cursor.getColumnIndex("updateMsg"));
                                String updateMg=cursor.getString(cursor.getColumnIndex("updateMg"));
                                String dotime=cursor.getString(cursor.getColumnIndex("dotime"));
                                Log.e("tiwolf", "recordCheck: 上传历史参数recontent:"+rccontent+";"+updateType+";"+updateFlag+";"+updateMsg+";"+updateMg+";"+dotime);
                                if (rccontent!=null)
                                    updateRecordBean.setContent(rccontent);
                                updateRecordBean.setContentType(updateType);
                                updateRecordBean.setUpdateFlag(updateFlag);
                                if (updateMsg!=null)
                                    updateRecordBean.setUpdateMsg(updateMsg);
                                if (updateMg!=null)
                                    updateRecordBean.setUpdateMg(updateMg);
                                if (dotime!=null)
                                    updateRecordBean.setDotime(dotime);
                            }else{
                                updateRecordBean=null;
                            }

                        }

                    }
                }
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return updateRecordBean;
        }


//        cursor.close();
//        return updateRecordBean;
    }

    //删掉数据库的一条数据之后，开始提取最前面的那条数据继续上传（上传到我司路由器获取到）
    public UpdateRecordBean recordCheckByType(String updateType){

        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        UpdateRecordBean updateRecordBean=new UpdateRecordBean();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        try {
            cursor = sdb.rawQuery("select rccontent,updateFlag,updateMsg,updateMg,dotime from update_record where updateType=?", new String[]{updateType});
            if (cursor.moveToFirst()){
                String rccontent=cursor.getString(cursor.getColumnIndex("rccontent"));
//                int updateType=cursor.getInt(cursor.getColumnIndex("updateType"));
                int updateFlag=cursor.getInt(cursor.getColumnIndex("updateFlag"));
                String updateMsg=cursor.getString(cursor.getColumnIndex("updateMsg"));
                String updateMg=cursor.getString(cursor.getColumnIndex("updateMg"));
                String dotime=cursor.getString(cursor.getColumnIndex("dotime"));
                updateRecordBean.setContent(rccontent);
                updateRecordBean.setUpdateFlag(updateFlag);
                updateRecordBean.setContentType(Integer.valueOf(updateType));
                updateRecordBean.setUpdateMg(updateMg);
                updateRecordBean.setDotime(dotime);
                updateRecordBean.setUpdateMsg(updateMsg);
            }else {
                updateRecordBean=null;
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return updateRecordBean;
        }


//        cursor.close();
//        return updateRecordBean;
    }

    //删掉数据库的一条数据之后，开始提取最前面的那条数据继续上传（上传到我司路由器获取到）
    public UpdateRecordBean recordCheck(UpdateRecordBean updateRecordBean){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        try {
            cursor = sdb.query("update_record", null, null, null, null, null, null);
            if (cursor.moveToFirst()){
                String rccontent=cursor.getString(cursor.getColumnIndex("rccontent"));
                int updateType=cursor.getInt(cursor.getColumnIndex("updateType"));
                int updateFlag=cursor.getInt(cursor.getColumnIndex("updateFlag"));
                String updateMsg=cursor.getString(cursor.getColumnIndex("updateMsg"));
                String updateMg=cursor.getString(cursor.getColumnIndex("updateMg"));
                String dotime=cursor.getString(cursor.getColumnIndex("dotime"));
                Log.e("tiwolf", "recordCheck: 上传历史参数recontent:"+rccontent+";"+updateType+";"+updateFlag+";"+updateMsg+";"+updateMg+";"+dotime);
                if (rccontent!=null)
                    updateRecordBean.setContent(rccontent);
                updateRecordBean.setContentType(updateType);
                updateRecordBean.setUpdateFlag(updateFlag);
                if (updateMsg!=null)
                    updateRecordBean.setUpdateMsg(updateMsg);
                if (updateMg!=null)
                    updateRecordBean.setUpdateMg(updateMg);
                if (dotime!=null)
                    updateRecordBean.setDotime(dotime);
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            Log.e("tiwolf", "recordCheck: 获取最新插入的上传历史记录" );
            return updateRecordBean;
        }


//        cursor.close();
//        return updateRecordBean;
    }
    /**
     * =============================上传设备图片照片记录update_record====================================
     */

    /**
     * ===========================直播内容的增删改查=================================
     */

    /**
     * 添加一个item进去
     * @param contentValues
     */
    public void saveLiveItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("live_tab",null,contentValues);
        Log.e("tiwolf", "saveAvItem: "+contentValues.get("alarmId") );
    }

    /**
     * 删除某一个item
     * @param id
     */
    public void deleteLive(String id){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from live_tab where id=?",new Object[]{id});
        Log.e("tiwolf", "delete: "+id );
    }

    /**
     * 更新某一条数据内容,这个需要注意符号
     * @param contentValues
     */
    public void updateLive(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: "+contentValues.get("content")+"--"+contentValues.get("id") );
//        sdb.update("upload_file",contentValues,null,null);
        //修改SQL语句
        String sql="update live_tab set content = "+contentValues.get("content")+" where id = '"+contentValues.get("id")+"'";
        sdb.execSQL(sql);

    }

    /**
     * 更新某一条数据音量,这个需要注意符号
     * @param voice
     * @param id
     */
    public void updateLiveVolume(String voice,String id){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        Log.e("tiwolf", "update: voice"+voice+"--"+"id="+id);
//        sdb.update("upload_file",contentValues,null,null);
        //修改SQL语句
        String sql="update live_tab set volumn = "+voice+" where alarmId = '"+id+"'";
        sdb.execSQL(sql);

    }

    /**
     * 仅仅查询一条数据
     * @param alarm
     * @return
     */
    public LiveBean checkLive(String alarm){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        LiveBean liveBean = null;
        try {
            if (Integer.valueOf(alarm)%2==0){
                cursor = sdb.rawQuery("select liveContent,alarmId,volume,startTime,endTime,startDay,endDay,flag,alarm1,item1,item2,item3,item4,dotime from live_tab where alarm2=?", new String[]{alarm});
            }else {
                cursor = sdb.rawQuery("select liveContent,alarmId,volume,startTime,endTime,startDay,endDay,flag,alarm2,item1,item2,item3,item4,dotime from live_tab where alarm1=?", new String[]{alarm});
            }
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
//        Cursor cursor = sdb.rawQuery("select FilePath from upload_file where UploadState=?", new String[]{fileState});
            String url;
//        cursor.moveToLast();
            if(cursor.moveToFirst()){
                //一开始我在select 后面写少了FileSize，结果老是报错
                //java.lang.IllegalStateException: Couldn't read row 1, col -1 from CursorWindow.  Make sure the Cursor is initialized correctly before accessing data from it.
                url=cursor.getString(cursor.getColumnIndex("liveContent"));
                int broadcastId=cursor.getInt(cursor.getColumnIndex("alarmId"));
                int volume=cursor.getInt(cursor.getColumnIndex("volume"));
                String startTime=cursor.getString(cursor.getColumnIndex("startTime"));
                String endTime=cursor.getString(cursor.getColumnIndex("endTime"));
                String startDay=cursor.getString(cursor.getColumnIndex("startDay"));
                String endDay=cursor.getString(cursor.getColumnIndex("endDay"));
                int flag=cursor.getInt(cursor.getColumnIndex("flag"));
//                String alarm1=cursor.getString(cursor.getColumnIndex("alarm1"));
//                String alarm2=cursor.getString(cursor.getColumnIndex("alarm2"));
                String doTime=cursor.getString(cursor.getColumnIndex("dotime"));
                if (url==null){
                    return null;
                }else {
                    liveBean=new LiveBean();
                    liveBean.setUrl(url);
                    liveBean.setPlayId(broadcastId);
                    liveBean.setStartTime(startTime);
                    liveBean.setEndTime(endTime);
                    liveBean.setVolume(volume);
//                    liveBean.setAlarm1(alarm1);
//                    liveBean.setAlarm2(alarm2);
                    liveBean.setDoTime(doTime);
                }

            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return liveBean;
        }

//        return liveBean;
    }

    public ArrayList<LiveBean> getTabList(){

        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
        Cursor cursor=null;
        ArrayList<LiveBean> list=null;
        try {
            cursor = sdb.rawQuery("select liveContent,alarmId,volume,startTime,endTime,startDay,endDay,flag,alarm1,alarm2,item1,item2,item3,item4,dotime from live_tab", null);

            list=new ArrayList<>();
            while(cursor.moveToNext()){
                LiveBean liveBean=new LiveBean();
                String url=cursor.getString(cursor.getColumnIndex("liveContent"));
                int broadcastId=cursor.getInt(cursor.getColumnIndex("alarmId"));
                int volume=cursor.getInt(cursor.getColumnIndex("volume"));
                String startTime=cursor.getString(cursor.getColumnIndex("startTime"));
                String endTime=cursor.getString(cursor.getColumnIndex("endTime"));
                String startDay=cursor.getString(cursor.getColumnIndex("startDay"));
                String endDay=cursor.getString(cursor.getColumnIndex("endDay"));
                int flag=cursor.getInt(cursor.getColumnIndex("flag"));
                String alarm1=cursor.getString(cursor.getColumnIndex("alarm1"));
                String alarm2=cursor.getString(cursor.getColumnIndex("alarm2"));
                String doTime=cursor.getString(cursor.getColumnIndex("dotime"));
                liveBean.setUrl(url);
                liveBean.setPlayId(broadcastId);
                liveBean.setStartTime(startTime);
                liveBean.setEndTime(endTime);
                liveBean.setAlarm1(alarm1);
                liveBean.setAlarm2(alarm2);
                liveBean.setDoTime(doTime);
                liveBean.setVolume(volume);
                list.add(liveBean);
            }
        }finally {
            if (cursor!=null)
                cursor.close();
            return list;
        }
//        vCursor=vReadSQLite.query("t_upload_head",new String[]{"BillID","FilePath","FileSize"},"UploadState=?",new String[]{"0"},null,null,null);

//        cursor.close();
//        return list;
    }

    /**
     * 删除整个表格数据
     */
    public void clearLiveTable(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from live_tab;");
    }
    /**
     * ==============================直播内容End====================================
     */


    /**
     * ===========================息屏的增删改查=================================
     */

    /**
     * 添加一个item进去
     * @param contentValues
     */
    public void saveScreenTimeItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("screen_tab",null,contentValues);
    }

    /**
     * 根据开关删除
     * @param switchflag
     */
    public void deleteScreenTime(String switchflag){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from screen_tab where switchflag=?",new Object[]{switchflag});
        Log.e("tiwolf", "delete: "+switchflag );
    }

    /**
     * 仅仅查询一条数据 进行一次
     * 将查出来的item按照大小排序
     * @param time
     * @return
     */
    public ScreenAlarmBean checkScreenTime(String time){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        ScreenAlarmBean screenAlarmBean = null;
        try {
//            cursor= sdb.query("screen_tab",new String[]{"timedo","timeInt","switchflag"},"timeInt>?",new String[]{time},null,null,"timeInt asc");
            cursor=sdb.query("screen_tab",null,"timeInt>?",new String[]{time},null,null,"timeInt asc");
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            if (cursor.moveToFirst()){
                //如果有大于的项，选择第一条
                String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                int timeInt=cursor.getInt(cursor.getColumnIndex("timeInt"));
                int switchFlag=cursor.getInt(cursor.getColumnIndex("switchflag"));
                Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作444="+timeDo+";timeInt="+timeInt+";time="+time);
                screenAlarmBean=new ScreenAlarmBean();
                screenAlarmBean.setTimeStr(timeDo);
                screenAlarmBean.setTimeInt(timeInt);
                screenAlarmBean.setSwitchFlag(switchFlag);
                screenAlarmBean.setIstomorrowflag(false);
                return screenAlarmBean;

            }else{
                //如果没有，选择最小的那条。然后加上24小时进行定时
                cursor=sdb.query("screen_tab",null,null,null,null,null,"timeInt asc");
                if (cursor.moveToFirst()){
                    String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                    int timeInt=cursor.getInt(cursor.getColumnIndex("timeInt"));
                    int switchFlag=cursor.getInt(cursor.getColumnIndex("switchflag"));
                    Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作4444="+timeDo+";timeInt="+timeInt);
                    screenAlarmBean=new ScreenAlarmBean();
                    screenAlarmBean.setTimeStr(timeDo);
                    screenAlarmBean.setTimeInt(timeInt);
                    screenAlarmBean.setSwitchFlag(switchFlag);
                    screenAlarmBean.setIstomorrowflag(true);
                    return screenAlarmBean;
                }else {
                    Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作444=没搞到数据");
                    //没有数据
                    return null;
                }

            }
        }finally {
            if (cursor!=null)
                cursor.close();
            Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作444=最后拿到的数据为");
        }

    }

    /**
     *
     * @param time
     * @return 返回true表明这个值是开，返回false表明这个值是关屏
     */
    public boolean checkScreenFlag(String time){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        try {
            cursor=sdb.query("screen_tab",null,"timeInt<=?",new String[]{time},null,null,"timeInt desc");//desc是降序
            if (cursor.moveToFirst()){
                //如果有小于的项，选择第一条
                String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                int switchFlag=cursor.getInt(cursor.getColumnIndex("switchflag"));
                Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作777="+switchFlag+";timeDo="+timeDo);
                if (switchFlag==1){
                    return true;//
                }else{
                    return false;
                }

            }else{
                //如果没有，选择最大的那条。然后加上24小时进行定时,拿到最大的值
                cursor=sdb.query("screen_tab",null,null,null,null,null,"timeInt desc");
                if (cursor.moveToFirst()){
                    String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                    int switchFlag=cursor.getInt(cursor.getColumnIndex("switchflag"));
                    Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作7777="+switchFlag+";timeDo="+timeDo);
                    if (switchFlag==1){
                        return true;//
                    }else{
                        return false;
                    }
                }else {
                    Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作7777=没搞到数据");
                    //没有数据
                    return true;
                }

            }
        }finally {
            if (cursor!=null)
                cursor.close();
            Log.e("tiwolf", "sendMsgToActivity: 开始进行开息屏操作778888=没搞到数据");
        }
    }

    /**
     * 删除整个表格数据
     */
    public void clearScreenTimeTable(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from screen_tab;");
    }
    /**
     * ==============================息屏End====================================
     */

    /**
     * ===========================led亮度值的增删改查=================================
     *  修改亮度 Util.setBright(int bright); bright 取值 0-255
     *  修改对比度 Util.setContrast(int contrast); contrast 取值 0-255
     */

    /**
     * 添加一个led亮度值item进去
     * @param contentValues
     */
    public void saveLedScreenTimeItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.insert("ledscreen_tab",null,contentValues);
    }

    /**
     * 根据亮度值删除
     * @param light
     */
    public void deleteLedScreenTime(int light){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from ledscreen_tab where screenlight=?",new Object[]{light});
        Log.e("tiwolf", "delete: "+light );
    }

    /**
     * 仅仅查询一条数据 进行一次.这条数据主要用来进行下一个时间段定时使用
     * 将查出来的item按照
     * @param time
     * @return
     */
    public LedScreenAlarmBean checkLedScreenTime(String time){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        LedScreenAlarmBean ledscreenAlarmBean = null;
        try {
//            cursor= sdb.query("screen_tab",new String[]{"timedo","timeInt","switchflag"},"timeInt>?",new String[]{time},null,null,"timeInt asc");
            cursor=sdb.query("ledscreen_tab",null,"timeInt>?",new String[]{time},null,null,"timeInt asc");
            //获取FilePath，FileSize 在条件是什么的时候。如果这个缺少，则缺少哪个，下面哪个就会报错
            if (cursor.moveToFirst()){
                //如果有大于的项，选择第一条
                String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                int timeInt=cursor.getInt(cursor.getColumnIndex("timeInt"));
                int light=cursor.getInt(cursor.getColumnIndex("screenlight"));
                Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作444="+timeDo+";timeInt="+timeInt+";time="+time);
                ledscreenAlarmBean=new LedScreenAlarmBean();
                ledscreenAlarmBean.setTimeStr(timeDo);
                ledscreenAlarmBean.setTimeInt(timeInt);
                ledscreenAlarmBean.setLedLight(light);
                cursor.close();
                cursor=null;
                return ledscreenAlarmBean;

            }else{
                //如果没有，选择最小的那条。然后加上24小时进行定时
                cursor=sdb.query("ledscreen_tab",null,null,null,null,null,"timeInt asc");
                if (cursor.moveToFirst()){
                    String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                    int timeInt=cursor.getInt(cursor.getColumnIndex("timeInt"));
                    int light=cursor.getInt(cursor.getColumnIndex("screenlight"));
                    Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作4444="+timeDo+";timeInt="+timeInt);
                    ledscreenAlarmBean=new LedScreenAlarmBean();
                    ledscreenAlarmBean.setTimeStr(timeDo);
                    ledscreenAlarmBean.setTimeInt(timeInt);
                    ledscreenAlarmBean.setLedLight(light);
                    cursor.close();
                    cursor=null;
                    return ledscreenAlarmBean;
                }else {
                    Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作444=没搞到数据");
                    //没有数据
                    cursor.close();
                    cursor=null;
                    return null;
                }

            }
        }finally {
            if (cursor!=null)
                cursor.close();
            Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作444=最后拿到的数据为");
        }

    }



    /**
     *
     * @param time
     * @return 返回值为led当前所需亮度值，主要用于程序重启，初步获取亮度值的时候
     */
    public int checkLedScreenLight(String time){
        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        try {
            cursor=sdb.query("ledscreen_tab",null,"timeInt<=?",new String[]{time},null,null,"timeInt desc");//desc是降序
            if (cursor.moveToFirst()){
                //如果有小于的项，选择第一条
                String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                int light=cursor.getInt(cursor.getColumnIndex("screenlight"));
                Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作777="+light+";timeDo="+timeDo);
                cursor.close();
                cursor=null;
                return light;

            }else{
                //如果没有，选择最大的那条。然后加上24小时进行定时,拿到最大的值
                cursor=sdb.query("ledscreen_tab",null,null,null,null,null,"timeInt desc");
                if (cursor.moveToFirst()){
                    String timeDo=cursor.getString(cursor.getColumnIndex("timedo"));
                    int light=cursor.getInt(cursor.getColumnIndex("screenlight"));
                    Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作7777="+light+";timeDo="+timeDo);
                    cursor.close();
                    cursor=null;
                    return light;
                }else {
                    Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作7777=没搞到数据");
                    //没有数据
                    cursor.close();
                    cursor=null;
                    return -1;
                }

            }
        }finally {
            if (cursor!=null)
                cursor.close();
            Log.e("tiwolf", "sendMsgToActivity: led屏幕亮度操作778888=没搞到数据");
        }
    }

    /**
     * 删除整个表格数据
     */
    public void clearLedScreenTimeTable(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        try {
            sdb.execSQL("delete from ledscreen_tab;");
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    /**
     * ==============================led屏幕亮度End====================================
     */


    /**
     * ===========================图片记录的增删改查=================================
     * 用于图片记录的保存，主要用于替换直接使用文件夹查找相关日期的文件情况。提高效率和优化空间
     */

    /**
     * 添加一个封面进去
     * @param contentValues
     */
    public void savePicItem(ContentValues contentValues){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
//        sdb.insert("pic_tab",null,contentValues);
        sdb.insertWithOnConflict("picrecord_tab",null,contentValues,SQLiteDatabase.CONFLICT_IGNORE);//这个是为了输入同一条数据的时候起冲突选择不更新数据
        Log.e("tiwolf", "receiveWork saveItem: "+contentValues.get("filePath") );
    }

    DecimalFormat decimalFormat=new DecimalFormat("00");

    /**
     * 获取封面记录数组
     * @param date
     * @return
     */
    public ArrayList<BmpRecordBean> getDataFromDate(String date){

        ArrayList<BmpRecordBean> bmpRecordBeans=new ArrayList<>();
        if (date.length()==8){
            return getBmpList(bmpRecordBeans,date);
        }else{
            //说明是要每个小时具体的封面图片的
            return getHourBmpList(bmpRecordBeans,date);
        }

    }

    /**
     * 删除图片记录
     * @param name
     */
    public void delBmpRecord(String name){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from picrecord_tab where name=?",new Object[]{name});
        Log.e("tiwolf", "delete bmp record: "+name );
    }

    /**
     * 清除图片记录数据
     */
    public void clearPicTab(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        sdb.execSQL("delete from picrecord_tab;");
    }

    /**
     * 删除大于60天前的记录
     */
    public void delData(int day){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        String sqlStr="DELETE FROM picrecord_tab WHERE date('now', '-"+day+" day') >= date(date);";
        Log.i("TAG", "delData: 删除之前的数据的sql Str="+sqlStr);
        sdb.execSQL(sqlStr);
    }

    /**
     * 获取24小时 每个小时的第一张图片
     * @param bmpRecordBeanArrayList
     * @param date
     * @return
     */
    private ArrayList<BmpRecordBean> getBmpList(ArrayList<BmpRecordBean> bmpRecordBeanArrayList,String date){
        //说明是要24小时，每个小时封面的
        for (int i = 0; i < 24; i++) {
            String hour=decimalFormat.format(i);
            String picDate=date+hour;
            SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
            Cursor cursor=null;
            BmpRecordBean bmpRecordBean=null;
            try {
                cursor = sdb.rawQuery("select filename,ext,name,filePath,date from picrecord_tab where name like ?", new String[]{picDate+"%"});
                if (cursor.moveToFirst()){
                    bmpRecordBean=new BmpRecordBean();
                    String filename=cursor.getString(cursor.getColumnIndex("filename"));
                    String ext=cursor.getString(cursor.getColumnIndex("ext"));
                    String name=cursor.getString(cursor.getColumnIndex("name"));
                    String filepath=cursor.getString(cursor.getColumnIndex("filePath"));
                    String date1=cursor.getString(cursor.getColumnIndex("date"));
                    bmpRecordBean.setFileName(filename);
                    bmpRecordBean.setExt(ext);
                    bmpRecordBean.setName(name);
                    bmpRecordBean.setFilePath(filepath);
                    bmpRecordBean.setDate(date1);
                    bmpRecordBeanArrayList.add(bmpRecordBean);
                    //获取数据之后进行记录删除
                    delBmpRecord(name);
                }

            }catch (Exception e){
                e.printStackTrace();
            }finally {
                if (cursor!=null)
                    cursor.close();
            }

        }
        return bmpRecordBeanArrayList;
    }

    private ArrayList<BmpRecordBean> getHourBmpList(ArrayList<BmpRecordBean> bmpRecordBeanArrayList,String date){

        SQLiteDatabase sdb=sqliteHelper.getReadableDatabase();
//        sdb.execSQL("select FilePath from upload_file where UploadState=?");
        Cursor cursor=null;
        BmpRecordBean bmpRecordBean=null;
//        Log.e("TAG", "sendMsgToActivity: 文件拿到解析的时间11111111="+date );
        try {
            cursor = sdb.rawQuery("select filename,ext,name,filePath,date from picrecord_tab where name like ?", new String[]{date+"%"});
//            Log.e("TAG", "sendMsgToActivity: 文件拿到解析的时间2222222222="+date );
            while (cursor.moveToNext()){
//                Log.e("TAG", "sendMsgToActivity: 文件拿到解析的时间3333333333="+date );
                bmpRecordBean=new BmpRecordBean();
                String filename=cursor.getString(cursor.getColumnIndex("filename"));
                String ext=cursor.getString(cursor.getColumnIndex("ext"));
                String name=cursor.getString(cursor.getColumnIndex("name"));
                String filepath=cursor.getString(cursor.getColumnIndex("filePath"));
                String date1=cursor.getString(cursor.getColumnIndex("date"));
                bmpRecordBean.setFileName(filename);
                bmpRecordBean.setExt(ext);
                bmpRecordBean.setName(name);
                bmpRecordBean.setFilePath(filepath);
                bmpRecordBean.setDate(date1);
                bmpRecordBeanArrayList.add(bmpRecordBean);
                //获取数据之后进行记录删除
                delBmpRecord(name);
            }
//            Log.e("TAG", "sendMsgToActivity: 文件拿到解析的时间4444444="+date );
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (cursor!=null)
                cursor.close();
        }
        return bmpRecordBeanArrayList;
    }

    /**
     * ==============================图片记录End====================================
     */


    public void clearAllData(){
        SQLiteDatabase sdb=sqliteHelper.getWritableDatabase();
        try {
            sdb.execSQL("delete from text_list;");
        }catch (Exception e){
            e.printStackTrace();
        }

        try {
            sdb.execSQL("delete from upload_file;");
        }catch (Exception e){
            e.printStackTrace();
        }

        try {
            sdb.execSQL("delete from download_file;");
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            sdb.execSQL("delete from play_list;");
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            sdb.execSQL("delete from country_list;");
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            sdb.execSQL("delete from update_record;");
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            sdb.execSQL("delete from live_tab;");
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            sdb.execSQL("delete from screen_tab;");
        }catch (Exception e){
            e.printStackTrace();
        }

        try {
            sdb.execSQL("delete from ledscreen_tab");
        }catch (Exception e){
            e.printStackTrace();
        }


        try {
            sdb.execSQL("delete from picrecord_tab;");
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
