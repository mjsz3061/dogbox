package com.ytf.dogbox.bean;

/**
 * @author tiwolf_li
 * @Date on 2020/6/23
 * @Description
 */
public class KeyMsgBean {
    private String code;
    private String data;
    private int dataFlag;
    private String msg;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getDataFlag() {
        return dataFlag;
    }

    public void setDataFlag(int dataFlag) {
        this.dataFlag = dataFlag;
    }

}
