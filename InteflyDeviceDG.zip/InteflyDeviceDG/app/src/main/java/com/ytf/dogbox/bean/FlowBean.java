package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/12/14
 * Describe:
 */
public class FlowBean {


    private int id;
    private double step1;
    private double step2;
    private double step3;
    private double step4;
    private double step5;
    private double step6;
    private double step7;
    private double step8;
    private double step9;
    private double step10;
    private double conditionerUseTime;
    private double soapUseTime;
    private double stepTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getStep1() {
        return step1;
    }

    public void setStep1(double step1) {
        this.step1 = step1;
    }

    public double getStep2() {
        return step2;
    }

    public void setStep2(double step2) {
        this.step2 = step2;
    }

    public double getStep3() {
        return step3;
    }

    public void setStep3(double step3) {
        this.step3 = step3;
    }

    public double getStep4() {
        return step4;
    }

    public void setStep4(double step4) {
        this.step4 = step4;
    }

    public double getStep5() {
        return step5;
    }

    public void setStep5(double step5) {
        this.step5 = step5;
    }

    public double getStep6() {
        return step6;
    }

    public void setStep6(double step6) {
        this.step6 = step6;
    }

    public double getStep7() {
        return step7;
    }

    public void setStep7(double step7) {
        this.step7 = step7;
    }

    public double getStep8() {
        return step8;
    }

    public void setStep8(double step8) {
        this.step8 = step8;
    }

    public double getStep9() {
        return step9;
    }

    public void setStep9(double step9) {
        this.step9 = step9;
    }

    public double getStep10() {
        return step10;
    }

    public void setStep10(double step10) {
        this.step10 = step10;
    }

    public double getConditionerUseTime() {
        return conditionerUseTime;
    }

    public void setConditionerUseTime(double conditionerUseTime) {
        this.conditionerUseTime = conditionerUseTime;
    }

    public double getSoapUseTime() {
        return soapUseTime;
    }

    public void setSoapUseTime(double soapUseTime) {
        this.soapUseTime = soapUseTime;
    }

    public double getStepTime() {
        return stepTime;
    }

    public void setStepTime(double stepTime) {
        this.stepTime = stepTime;
    }
}
