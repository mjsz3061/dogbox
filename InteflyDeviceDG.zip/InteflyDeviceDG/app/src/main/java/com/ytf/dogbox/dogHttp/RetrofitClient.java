package com.ytf.dogbox.dogHttp;

import android.util.Log;

import androidx.annotation.NonNull;

import com.ytf.dogbox.util.MD5Util;
import com.ytf.dogbox.util.MD5UtilException;
import com.ytf.dogbox.util.TimeUtil;

import java.io.IOException;
import java.util.Date;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    private static volatile RetrofitClient instance;
    private DogApiService apiService;

    private RetrofitClient(){}

    public static RetrofitClient getInstance(){
        if (instance==null){
            synchronized (RetrofitClient.class){
                if (instance==null){
                    instance=new RetrofitClient();
                }
            }
        }
        return instance;
    }

    /**
     * 设置header
     * @return
     */
    private Interceptor getHeaderInterceptor(String token){
//        final String token= PreferenceUtil.getString("token","");

        Date date=new Date(System.currentTimeMillis());
        String dateStr= TimeUtil.DateToStr(date);

        return new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {

                String md5Sign="null";
                try {
                    md5Sign= MD5Util.md5(token+date);
                } catch (MD5UtilException e) {
                    throw new RuntimeException(e);
                }

                Log.e("TAG", "获取请求头getHeaderInterceptor: token="+token );
                Log.e("TAG", "获取请求头getHeaderInterceptor: date="+dateStr );
                Log.e("TAG", "获取请求头getHeaderInterceptor: md5="+md5Sign );

                Request original=chain.request();
                Request.Builder requestBuilder=original.newBuilder()
                        .addHeader("Authtication","Bearer "+token)
                        .addHeader("AccessTime",dateStr)
                        .addHeader("AccessKey", md5Sign);
                Request request=requestBuilder.build();
                return chain.proceed(request);
            }
        };
    }

    private Interceptor getHeaderInterceptor1(){
        return new Interceptor() {
            @NonNull
            @Override
            public Response intercept(@NonNull Chain chain) throws IOException {
                Request original=chain.request();
                Request.Builder requestBuilder=original.newBuilder()
                        .addHeader("Accept-Language","zh-CN,zh;q=0.9");
                Request request=requestBuilder.build();
                return chain.proceed(request);
            }
        };
    }

    /**
     * 设置拦截器
     * @return
     */
    private Interceptor getInterceptor(){
        HttpLoggingInterceptor interceptor=new HttpLoggingInterceptor();
        //显示日志
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        return interceptor;
    }

    public DogApiService getApi(String baseUrl){
        //初始化一个client，不然retrofit会自己默认添加一个
        OkHttpClient client=new OkHttpClient().newBuilder()
                .addInterceptor(getInterceptor())
                .build();

        Retrofit retrofit=new Retrofit.Builder()
                .client(client)
                //设置网络请求的url地址
                .baseUrl(baseUrl)
                //设置数据解析器
                .addConverterFactory(GsonConverterFactory.create())
                //设置网络请求适配器，使其支持Rxjava与RxAndroid
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
        //创建----网络请求接口----实例化
        apiService=retrofit.create(DogApiService.class);
        return apiService;
    }

    public DogApiService getHeaderApi(String baseUrl,String token){
        //初始化一个client，不然retrofit会自己默认添加一个
        OkHttpClient client=new OkHttpClient().newBuilder()
                //设置Header
                .addInterceptor(getHeaderInterceptor(token))
                //设置拦截器
                .addInterceptor(getInterceptor())
                .build();

        Retrofit retrofit=new Retrofit.Builder()
                .client(client)
                //设置网络请求的url地址
                .baseUrl(baseUrl)
                //设置数据解析器
                .addConverterFactory(GsonConverterFactory.create())
                //设置网络请求适配器，使其支持Rxjava与RxAndroid
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
        //创建----网络请求接口----实例化
        apiService=retrofit.create(DogApiService.class);
        return apiService;
    }


}
