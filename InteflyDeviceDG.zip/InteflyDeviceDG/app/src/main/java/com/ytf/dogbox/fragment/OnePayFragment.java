package com.ytf.dogbox.fragment;
 
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ytf.dogbox.R;


public class OnePayFragment extends Fragment {

    //是否可见
    private boolean isVisibleToUser;
    //是否初始化完成
    public boolean isInit = false;
    //全局的view
    private View view;

    ImageView codeOneUrlIv;        //支付二维码
    TextView ordersOneTv;          //订单号
    TextView moneyOneTv;           //支付金额
    TextView payOneContentTv;      //一键洗狗
    TextView cancelPayOneTv;           //取消订单


    /*
     * 当前页面可见时和不可见的方法
     * */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        this.isVisibleToUser = isVisibleToUser;
        setParam();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.e("tiwolf", "onCreateView: payFragment-创建ui" );
        //1.创建View视图
        if (view==null){
            view = inflater.inflate(R.layout.fragment_onepay,container,false);

            isInit=true;
            setParam();
        }
        return  view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e("TAG", "onResume: payFragment-显示数据" );
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e("TAG", "onDestroyView: payFragment-停止显示" );
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("TAG", "onDestroy: payFragment-销毁控件" );
    }


    //处理逻辑和网络请求等
    private void setParam() {
        if (isInit && isVisibleToUser) {
            codeOneUrlIv=view.findViewById(R.id.code_iv);
            ordersOneTv=view.findViewById(R.id.orders_tv);
            moneyOneTv=view.findViewById(R.id.money_tv);
            payOneContentTv=view.findViewById(R.id.order_content_tv);
            cancelPayOneTv=view.findViewById(R.id.cancel_pay_tv);
            Log.e("tiwolf", "setParam: payFragment-创建ui" );
        }
    }
}