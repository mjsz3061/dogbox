package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2022/1/14
 * Describe:  广告列表
 */
public class LiveContentBean {


    private int volume;
    private String startTime;
    private String endTime;
    private String url;

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
