package com.ytf.dogbox.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ytf.dogbox.R;
import com.ytf.dogbox.util.LanguageUtil;
import com.ytf.dogbox.util.PreferenceUtil;

/**
 * author:tiwolf
 * create date:2023/10/30
 * Describe:
 */
public class WelComeActivity extends Activity {


    Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);

            switch (msg.what){
                case 1:{
                    // 进入主界面
                    Intent intent=new Intent(WelComeActivity.this,DogActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                    finish();
                    break;
                }
                case 2:{
                    //进入欠费界面

                    break;
                }

            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String language= PreferenceUtil.getString(PreferenceUtil.LANGUAGE, "zh");
        android.util.Log.e("TAG", "onCreate: 当前需要的语言是="+language );
        LanguageUtil.switchLanguage(WelComeActivity.this,language);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        View rootView= LayoutInflater.from(this).inflate(R.layout.activity_start,null);
        setContentView(rootView);

        Animation animation= AnimationUtils.loadAnimation(this,R.anim.start_alpha);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                Message msg=handler.obtainMessage();
                msg.what=1;
                handler.sendMessage(msg);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        rootView.startAnimation(animation);
    }
}
