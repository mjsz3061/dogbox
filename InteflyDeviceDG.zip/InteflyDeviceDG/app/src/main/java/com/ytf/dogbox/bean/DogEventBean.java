package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/11/25
 * Describe:
 */
public class DogEventBean {

    private String order;
    private String handThing;

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getHandThing() {
        return handThing;
    }

    public void setHandThing(String handThing) {
        this.handThing = handThing;
    }
}
