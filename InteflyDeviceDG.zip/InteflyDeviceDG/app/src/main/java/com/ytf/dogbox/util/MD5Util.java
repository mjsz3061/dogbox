package com.ytf.dogbox.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by Justin.t.wang on 2017-08-10.
 */
public class MD5Util {

    public static String md5(String content) throws MD5UtilException{
        StringBuffer sb = new StringBuffer();
        try{
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(content.getBytes("UTF-8"));
            byte[] tmpFolder = md5.digest();

            for (byte aTmpFolder : tmpFolder) {
                sb.append(Integer.toString((aTmpFolder & 0xff) + 0x100, 16).substring(1));
            }

            return sb.toString();
        }catch(NoSuchAlgorithmException ex){
            throw new MD5UtilException("无法生成指定内容的MD5签名", ex);
        }catch(UnsupportedEncodingException ex){
            throw new MD5UtilException("无法生成指定内容的MD5签名", ex);
        }
    }



    public static String getFileMd5(File file) {
        MessageDigest messageDigest;
        //MappedByteBuffer byteBuffer = null;
        FileInputStream fis = null;
        try {
            messageDigest = MessageDigest.getInstance("MD5");
            if (file == null) {
                return "";
            }
            if (!file.exists()) {
                return "";
            }
            int len = 0;
            fis = new FileInputStream(file);
            //普通流读取方式
            byte[] buffer = new byte[1024 * 1024 * 10];
            while ((len = fis.read(buffer)) > 0) {
                //该对象通过使用 update（）方法处理数据
                messageDigest.update(buffer, 0, len);
            }
            BigInteger bigInt = new BigInteger(1, messageDigest.digest());
            String md5 = bigInt.toString(16);
            while (md5.length() < 32) {
                md5 = "0" + md5;
            }
            return md5;
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                    fis = null;
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return "";
    }


    public static void main(String[] args) throws MD5UtilException{
        String str = "CN20191100003&20191231113015.mp4&mp4&2019123111301&11838930";
        String str2 = "CN20191100003&20191231113015.mp4&.mp4&2019123111301&11838930";
        String str3 = "CN20191100003&20191231113015.mp4&mp4&2019123111301&11838930";
        String md51 = MD5Util.md5(str);  // 0abea4f2d8d071c508db9d5e180359ef
        String md52 = MD5Util.md5(str2.toLowerCase()); // 1bb4a2c54e8d741e0855e9e2a2e22777
        String md53 = MD5Util.md5(str.toLowerCase());

        System.out.println(md51);
        System.out.println(md52);
        System.out.println(md53);
    }
}
