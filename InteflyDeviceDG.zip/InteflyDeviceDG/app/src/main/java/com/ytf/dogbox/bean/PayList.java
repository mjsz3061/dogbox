package com.ytf.dogbox.bean;

public class PayList {
    private String goodsName;
    private Long id;
    private Long num;
    private Double price;

    public String getGoodsName() { return goodsName; }
    public void setGoodsName(String value) { this.goodsName = value; }

    public Long getid() { return id; }
    public void setid(Long value) { this.id = value; }

    public Long getNum() { return num; }
    public void setNum(Long value) { this.num = value; }

    public Double getPrice() { return price; }
    public void setPrice(Double value) { this.price = value; }
}
