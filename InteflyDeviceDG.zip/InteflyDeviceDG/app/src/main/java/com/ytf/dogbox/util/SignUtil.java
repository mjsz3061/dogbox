package com.ytf.dogbox.util;


import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Copyright (c) Shenzhen Intefly Electronics Co.,Ltd.
 *
 * @author <a href="mailto:justin.t.wang@163.com">王耀军(justin.t.wang)</a>
 * @version 1.0
 * @createDate: 2020/5/16 15:14
 */
public class SignUtil {

    public static String sign(Object object, String primaryKey) throws Exception {

        String str = null;
        if(object instanceof Map){
            str = getSignString((Map)object, primaryKey);
        }else{
            List<String> fieldNames = getFiledName(object);
            Collections.sort(fieldNames);

            StringBuilder param = new StringBuilder();

            for(int i = 0 ; i < fieldNames.size() ; i ++){     //遍历所有属性
                String name = fieldNames.get(i);    //获取属性的名字
                Object value = getFieldValueByName(name, object);
                if(null != value && !"".equals(value.toString().trim())) {
                    param.append(name);
                    param.append(value);
                }
            }
            param.append(primaryKey);
            str = param.toString().toLowerCase();
        }
        return MD5Util.md5(str);
    }


    private static String getSignString(Map<String, Object> parameter, String primaryKey) throws Exception {

        List<String> keys = new ArrayList<>(parameter.keySet());
        Collections.sort(keys);

        StringBuilder param = new StringBuilder();

        for(String key : keys){     //遍历所有参数
            Object value = parameter.get(key);
            if(null != value && !"".equals(value.toString().trim())) {
                param.append(key);
                param.append(value);
            }
        }
        param.append(primaryKey);
        String str = param.toString().toLowerCase();
        return str;
    }

    /**
     * 获取属性名数组
     *
     */
    private static List<String> getFiledName(Object o){

        Class clazz = o.getClass();
        List<Field> fields = new ArrayList<>();
        while (clazz != null){
            fields.addAll(new ArrayList<>(Arrays.asList(clazz.getDeclaredFields())));
            clazz = clazz.getSuperclass();
        }
        List<String> fieldNames = new ArrayList<>();
        for(Field f : fields){
            fieldNames.add(f.getName());
        }
        return fieldNames;
    }

    /**
     * 根据属性名获取属性值
     * @param fieldName
     * @param o
     * @return
     */
    private static Object getFieldValueByName(String fieldName, Object o) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = o.getClass().getMethod(getter, new Class[] {});
            Object value = method.invoke(o, new Object[] {});
            return value;
        } catch (Exception e) {
            return null;
        }
    }

    public static void main(String[] args) throws Exception {
//        OpIO op = new OpIO();
//        op.setItemId(1L);
//        op.setOpType(2);
//
//        op.setUid(7L);
//        op.setPid(6L);
//        op.setOpValue("人民政府");
//        System.out.println(sign(op,"ota"));
//        // c4dcf233c70467f03917f710194391a7

        // 58d19cc1d6980f04befe8e030f1724f7

        Map<String, String> map = new HashMap<>();
        map.put("applicant","");
        map.put("applyPversion","1.0.0");
        map.put("identify","inteflyStreeLamp");
        map.put("pversion","1.0.1");
        map.put("queryTime","1590110250625");
        // 6c3f05a847ae3cc4a9ef2ceffed2a346
        // 6c3f05a847ae3cc4a9ef2ceffed2a346
        System.out.println(sign(map, "inteflyStreeLamp"));
    }
}
