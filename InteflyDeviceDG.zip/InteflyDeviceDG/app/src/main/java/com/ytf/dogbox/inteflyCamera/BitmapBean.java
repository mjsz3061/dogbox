package com.ytf.dogbox.inteflyCamera;

/**
 * author:tiwolf
 * create date:2022/7/4
 * Describe:
 */
public class BitmapBean {

    private byte[] bytes;
    private int height;
    private int width;


    public BitmapBean() {
    }

    public byte[] getBytes() {
        return bytes;
    }

    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }
}
