package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/12/18
 * Describe:
 */
public class DogHttpKeyBean {

    private String accessKey;
    private String accessTime;
    private String name;
    private String sn;

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getAccessTime() {
        return accessTime;
    }

    public void setAccessTime(String accessTime) {
        this.accessTime = accessTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }
}
