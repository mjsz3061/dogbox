package com.ytf.dogbox.dogHttp;

import static com.ytf.dogbox.util.UploadConfig.originName;

import com.ytf.dogbox.base.presenter.BasePresenter;
import com.ytf.dogbox.bean.AdvertBean;
import com.ytf.dogbox.bean.AlarmBean;
import com.ytf.dogbox.bean.CheckMsgBean;
import com.ytf.dogbox.bean.DogAlarmBean;
import com.ytf.dogbox.bean.DogExceBean;
import com.ytf.dogbox.bean.DogHttpKeyBean;
import com.ytf.dogbox.bean.DogSnBean;
import com.ytf.dogbox.bean.DogSyncConfigBean;
import com.ytf.dogbox.bean.DogTonkenBean;
import com.ytf.dogbox.bean.ErrorBean;
import com.ytf.dogbox.bean.HttpPayBean;
import com.ytf.dogbox.bean.KeyMsgBean;
import com.ytf.dogbox.bean.PayBean;
import com.ytf.dogbox.bean.QiniuMsgBean;
import com.ytf.dogbox.bean.RefundBean;
import com.ytf.dogbox.bean.RefundParamBean;
import com.ytf.dogbox.bean.UpLoadGetBean;
import com.ytf.dogbox.bean.UpLoadGetSubBean;
import com.ytf.dogbox.util.Log;
import com.ytf.dogbox.util.UploadConfig;

import java.util.List;
import java.util.Map;

import io.reactivex.functions.Consumer;

/**
 * author:tiwolf
 * create date:2023/10/31
 * Describe:
 */
public class DogPresenter extends BasePresenter<DogContract.View> implements DogContract.Presenter {

    DogContract.Model model;

    public DogPresenter(){
        model=new DogModel();
    }

    @Override
    public void getDogState() {

    }

    @Override
    public void getMerge(Map<String, String> map, String lastModifiedTime) {
        model.getMerge(map)
                .compose(RxScheduler.<UpLoadGetBean<UpLoadGetSubBean>>Flo_io_main())
                .as(mView.<UpLoadGetBean<UpLoadGetSubBean>>bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<UpLoadGetSubBean>>() {
                    @Override
                    public void accept(UpLoadGetBean<UpLoadGetSubBean> upLoadGetSubBeanUpLoadGetBean) throws Exception {
                        Log.e("TAG", "accept: 文件合并后返回的md5和文件名="+ map.get(UploadConfig.md5)+";"+originName);
                        mView.onSuccessMerge(upLoadGetSubBeanUpLoadGetBean,originName+","+map.get(UploadConfig.md5));
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mView.onErrorMerge(throwable,map.get(UploadConfig.md5));
                    }
                });
    }

    @Override
    public void getQiniuKey(Map<String, Object> map) {
        model.getQiniuKey(map)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.<QiniuMsgBean>bindAutoDispose())
                .subscribe(new Consumer<QiniuMsgBean>() {
                    @Override
                    public void accept(QiniuMsgBean keyMsgBean) throws Exception {
                        mView.onSuccessGetKey(keyMsgBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mView.onFailGetKey(throwable);
                    }
                });
    }

    @Override
    public void getQiniuDownloadUrl(Map<String, Object> map) {
        model.getQiniuDownloadUrl(map)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<KeyMsgBean>() {
                    @Override
                    public void accept(KeyMsgBean keyMsgBean) throws Exception {
                        Log.e("tiwolf", "accept: 下载="+keyMsgBean.toString() );
                        mView.onSuccessGetDownloadUrl(keyMsgBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mView.onFailGetDownloadUrl(throwable);
                    }
                });
    }

    /**
     *
     * @param map
     */
    @Override
    public void getUpdatePolice(Map<String, String> map) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.getUpdatePolice(map)
                .compose(RxScheduler.<KeyMsgBean>Flo_io_main())
                .as(mView.<KeyMsgBean>bindAutoDispose())
                .subscribe(new Consumer<KeyMsgBean>() {
                    @Override
                    public void accept(KeyMsgBean keyMsgBean) throws Exception {
                        Log.e("tiwolf", "accept:人脸识别获取成功 "+keyMsgBean.getData() );
                        mView.onSuccessPolice(keyMsgBean,map);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept:人脸识别获取失败 "+throwable.getMessage() );
                    }
                });
    }

    /**
     * 上传摄像头信息
     * @param map
     */
    @Override
    public void updateRecordMsg(Map<String, Object> map,String content,String md5) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.updateRecordMsg(map)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<KeyMsgBean>() {
                    @Override
                    public void accept(KeyMsgBean keyMsgBean) throws Exception {
                        mView.onSuccessUpdateMsg(keyMsgBean,content);
//                        mView.onFailUpdateMsg(new Throwable("专门搞出错"),content,md5);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 历史数据上传失败"+throwable.getMessage());
                        mView.onFailUpdateMsg(throwable,content,md5);
                    }
                });
    }

    @Override
    public void delRecordMsg(Map<String, Object> map,String content) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.delRecordMsg(map)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<KeyMsgBean>() {
                    @Override
                    public void accept(KeyMsgBean keyMsgBean) throws Exception {
                        mView.onSuccessDelMsg(keyMsgBean,content);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mView.onFailDelMsg(throwable,content);
                    }
                });
    }

    @Override
    public void upSendError(Map<String, String> map) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.upSendError(map)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<ErrorBean>>() {
                    @Override
                    public void accept(UpLoadGetBean<ErrorBean> keyMsgBean) throws Exception {
                        mView.upSendErrorSuccess(keyMsgBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mView.upSendErrorFail(throwable);
                    }
                });
    }

    @Override
    public void updateMsg(Map<String, Object> map) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.updateMsg(map)
                .compose(RxScheduler.<UpLoadGetBean<CheckMsgBean>>Flo_io_main())
                .as(mView.<UpLoadGetBean<CheckMsgBean>>bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<CheckMsgBean>>() {
                    @Override
                    public void accept(UpLoadGetBean<CheckMsgBean> checkMsgBeanUpdateMsgBean) throws Exception {
                        /**
                         * {"code":"0","data":{"pversion":"1.0.1","status":2,
                         * "releaseTime":1590481665000,"updateContent":"1.修改内容不清楚",
                         * "packageSize":695873522},"msg":null,"dataFlag":0}
                         */
                        Log.e("tiwolf", "accept:获取更新信息 "+checkMsgBeanUpdateMsgBean.getCode());
                        mView.onSuccessCheckKey(checkMsgBeanUpdateMsgBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 更新信息错误"+throwable.getMessage() );
                    }
                });
    }

    @Override
    public void getUpdateKey(Map<String, Object> map) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.getUpdateKey(map)
                .compose(RxScheduler.<KeyMsgBean>Flo_io_main())
                .as(mView.<KeyMsgBean>bindAutoDispose())
                .subscribe(new Consumer<KeyMsgBean>() {
                    @Override
                    public void accept(KeyMsgBean keyMsgBean) throws Exception {
                        Log.e("tiwolf", "accept: 获取秘钥"+keyMsgBean.getData() );
                        mView.onSuccessKey(keyMsgBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 秘钥信息错误"+throwable.getMessage() );
                    }
                });
    }

    @Override
    public void orderPay(HttpPayBean httpPayBean,String token) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.orderPay(httpPayBean,token)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<PayBean>>() {
                    @Override
                    public void accept(UpLoadGetBean<PayBean> payBeanUpLoadGetBean) throws Exception {
                        Log.e("tiwolf", "accept: 支付成功后的信息="+payBeanUpLoadGetBean.getData() );
                        mView.onSuccessPayUrl(payBeanUpLoadGetBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 支付返回失败" + throwable.getMessage());
                        mView.onFailPay(throwable);
                    }
                });
    }

    @Override
    public void refundPay(RefundParamBean refundParamBean,String token) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.refundPay(refundParamBean,token)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<RefundBean>>() {
                    @Override
                    public void accept(UpLoadGetBean<RefundBean> refundBeanUpLoadGetBean) throws Exception {
                        Log.e("tiwolf", "accept: 退款成功="+refundBeanUpLoadGetBean.getData() );
                        mView.onSuccessRefundPay(refundBeanUpLoadGetBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 退款失败=" + throwable.getMessage());
                        mView.onFailRefundPay(throwable);
                    }
                });
    }

    @Override
    public void upLoadDogException(DogExceBean dogExceBean,String token) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.upLoadDogException(dogExceBean,token)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<KeyMsgBean>() {
                    @Override
                    public void accept(KeyMsgBean keyMsgBean) throws Exception {
                        mView.onSuccessUploadDogException(keyMsgBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 上传异常失败=" + throwable.getMessage());
                        mView.onFailUploadDogException(throwable);
                    }
                });
    }

    @Override
    public void getHttpKey(DogHttpKeyBean dogHttpKeyBean) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.getHttpKey(dogHttpKeyBean)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<DogTonkenBean>>() {
                    @Override
                    public void accept(UpLoadGetBean<DogTonkenBean> dogTonkenBeanUpLoadGetBean) throws Exception {
                        Log.e("tiwolf", "accept: 成功获取狗的token" );
                        mView.onSuccessGetToken(dogTonkenBeanUpLoadGetBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 获取狗的token失败=" + throwable.getMessage());
                        mView.onFailGetToken(throwable);
                    }
                });
    }

    @Override
    public void upLoadAlarmWarning(DogAlarmBean dogAlarmBean, String token) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.upLoadAlarmWarning(dogAlarmBean,token)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<KeyMsgBean>() {
                    @Override
                    public void accept(KeyMsgBean keyMsgBean) throws Exception {
                        Log.e("TAG", "accept: 上传预警成功");
                        mView.onSuccessUploadDogAlarm(keyMsgBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 上传预警失败=" + throwable.getMessage());
                        mView.onFailUploadDogAlarm(throwable);
                    }
                });
    }

    @Override
    public void syncConfigData(DogSnBean dogSnBean,String token) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.syncConfigData(dogSnBean,token)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<DogSyncConfigBean>>() {
                    @Override
                    public void accept(UpLoadGetBean<DogSyncConfigBean> dogSyncConfigBeanUpLoadGetBean) throws Exception {
                        mView.onSuccessSyncConfigData(dogSyncConfigBeanUpLoadGetBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("tiwolf", "accept: 上传预警失败=" + throwable.getMessage());
                        mView.onFailSyncConfigData(throwable);
                    }
                });
    }

    @Override
    public void getDeviceDataAdvert(Map<String, String> map) {
        if (!isViewAttached()){
            mView.nonGetMessage("View 没有绑定");
            return;
        }

        model.getDeviceDataAdvert(map)
                .compose(RxScheduler.Flo_io_main())
                .as(mView.bindAutoDispose())
                .subscribe(new Consumer<UpLoadGetBean<AdvertBean<List<AlarmBean>>>>() {
                    @Override
                    public void accept(UpLoadGetBean<AdvertBean<List<AlarmBean>>> advertBeanUpLoadGetBean) throws Exception {
                        mView.onSuccessAdvert(advertBeanUpLoadGetBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mView.onFailAdvert(throwable);
                    }
                });
    }
}
