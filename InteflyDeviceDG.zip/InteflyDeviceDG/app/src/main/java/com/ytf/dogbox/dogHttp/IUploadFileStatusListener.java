package com.ytf.dogbox.dogHttp;


import com.ytf.dogbox.db.UploadItem;

/**
 * author:tiwolf
 * create date:2023/2/28
 * Describe:主要来用辨别上传文件时出现的各种状态，减少不断new导致的数据量巨大
 */
public interface IUploadFileStatusListener {

    void onUploadsPolieceSuccess(UploadItem uploadItem);//上传报警小文件成功，去上传记录

    void onUploadsRecordSuccess(UploadItem uploadItem);//上传录制小文件成功，去上传记录

    void onUploadPartSuccess(UploadItem uploadItem);//上传分片成功，去将所属的sn记录分片++，等上传分片数和sn分片总数相等的时候。即去合并操作

    void onUpLoadInterrupted(); //上传中断

    void onUploadError();   //上传出现其他问题

    void onFileError();     //上传文件出现问题
}
