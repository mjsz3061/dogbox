package com.ytf.dogbox.activity;

/**
 * author:tiwolf
 * create date:2022/10/28
 * Describe:
 */
public interface MqttReceiveRunnable extends Runnable {

    MqttReceiveRunnable receiveMqttMsg(String message);
}
