package com.ytf.dogbox.CountDownTime;

public interface OnCountDownListener {
    void getCountDownTime(int time);
    void timeOver();
}
