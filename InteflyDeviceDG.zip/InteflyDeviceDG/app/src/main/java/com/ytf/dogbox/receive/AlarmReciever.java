package com.ytf.dogbox.receive;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.ytf.dogbox.util.Log;



/**
 * Created by mc on 16-4-24.
 * 2022.11.16 
 */
public class AlarmReciever extends BroadcastReceiver{
    private String TAG="AlarmReciever";
    private Context mContext;
    PendingIntent pendingIntent;
    static IReceiver iReceiver1;

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG,"alarmReciever get");
        mContext=context;
        int id =intent.getIntExtra("_id",-1);
        boolean flag=intent.getBooleanExtra("flag",false);
        Log.i(TAG, "接收者闹钟onReceive: "+id );
        if(iReceiver1!=null){
            Log.e(TAG, "onReceive: 接收者广播" );
            iReceiver1.receiveAlarmMsg(""+id,flag);
        }

    }

    public interface IReceiver{
        void receiveAlarmMsg(String msg,boolean flag);
    }

    public static void setiReceiver(IReceiver iReceiver){
        iReceiver1=iReceiver;
    }
}

