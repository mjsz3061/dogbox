package com.ytf.dogbox.util;

import android.os.Environment;

public class TestConfig {

    public static String httpheader="http://";
    public static final String HOST="api.intefly.cn";

    public static final String MQTT_URL="http://api.intefly.cn"; //下载

    public static final String token="eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxIiwib2lkIjowLCJpc3MiOiJhZG1pbiIsImF1ZCI6IldBU0giLCJleHAiOjE3NjUzNTA5NDB9.qbAo0zu7z1cfzKKXxAhaxBevzbUVqzamU-xaIR7JekDHqojIcGsuh5tr1GxIw1gHFgKYC2kJdvc8rCJ2bg0iQw";
    public static final String RTMP_HEAR="rtmp://";
    public static final String RTMP_PARAMS=":1935/live/0";
    public static String MEDIASV="stream.intefly.cn";
    public  static final String rkUrl="rtsp://192.168.110.123:554/live/substream";


    //摄像头相关
    public static String usrname = "admin";
    public static String pwd = "YWRtaW4=";
    public static String ip = "192.168.110.123";
    public static int itfi = 2;


    public static String userName="admin";//用户名
    public static String password="uuB#tuJ^ib4p&S7Dh";//密码


    public  static final String uploadPart="/file/bigfile/upload";


    public static final String uploadFile="/file/common/upload";

    public static final String downloadFile="/file/common/download?md5=";

    public static final String downloadPackageFile="/ota/package/download";

    public static final String downloadFilePath= Environment.getExternalStorageDirectory()+"/solar/download/";

    //七牛云的key
    public static String accessKey = "i6qLj_FkBjb-43vEi_h9itaq74ue6nvbuuJNXaM2"; // 替换成自己 Qiniu 账号的 AccessKey.
    public static String secretKey = "fOzSxLGuneO-85v5bzEzAtfxsD7Hi-Ht1lDpqIaR"; // 替换成自己 Qiniu 账号的 SecretKey.

}
