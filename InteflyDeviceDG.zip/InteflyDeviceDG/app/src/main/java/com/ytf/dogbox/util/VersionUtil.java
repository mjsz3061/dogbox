package com.ytf.dogbox.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.util.ArrayMap;

import com.auth0.android.jwt.Claim;
import com.auth0.android.jwt.JWT;
import com.ytf.dogbox.activity.FlyUtil;
import com.ytf.dogbox.bean.CheckMsgBean;
import com.ytf.dogbox.bean.KeyMsgBean;
import com.ytf.dogbox.bean.UpLoadGetBean;
import com.ytf.dogbox.dogHttp.ThreadPoollExcutorUtil;

import net.lingala.zip4j.exception.ZipException;

import java.io.File;
import java.util.Map;



/**
 * author:tiwolf
 * create date:2022/4/20
 * Describe: App升级
 */
public class VersionUtil {

    private final static String TAG=VersionUtil.class.getSimpleName();
    private static String  appVersion = "";
    static String appVersionCode = "";

    private static String broadType="IND";


    /**
     * 主动开始进行app版本检查
     */
    public static Map<String, Object> startToCheck(Context context){
        PackageManager pm=context.getPackageManager();
//        File file1=FileSortUtil.createVersionFile();
//        Log.e(TAG, "startToCheck: "+file1.getAbsolutePath() );
        String versionName="non";
        String apiVersion="";
        try {
            PackageInfo pi=pm.getPackageInfo(context.getPackageName(),0);
            versionName=pi.versionName;
            apiVersion= FlyUtil.initInot(context).getApiVersion();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        if(!"non".equals(versionName) && apiVersion!=null && apiVersion.length()!=0){
            long currentTime=System.currentTimeMillis();
            Log.e(TAG, "onClick位数为: "+currentTime );

            Map<String,Object> verParams=new ArrayMap<>();
            verParams.put(UploadConfig.APPLICANT,FlyUtil.getSn(context));
            verParams.put(UploadConfig.APPLYPVERSION,versionName);
            verParams.put(UploadConfig.SYSTEMVERSION,apiVersion);
            verParams.put(UploadConfig.IDENTIFY,broadType);
            verParams.put(UploadConfig.QUERYTIME,currentTime);
            try {
                verParams.put(UploadConfig.SIGN, SignUtil.sign(verParams,broadType));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return verParams;

//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    mPresenter.updateMsg(verParams);
//                }
//            });

        }
        return null;

    }

    /**
     * 主动开始进行固件版本检查
     */
    public static Map<String, Object> startToCheck(Context context,String model){
        String apiVersion="";
        try {
            apiVersion= FlyUtil.initInot(context).getSystemVersion();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(apiVersion!=null && apiVersion.length()!=0){
            long currentTime=System.currentTimeMillis();
            Log.e(TAG, "onClick位数为: 固件版本查询"+currentTime );

            Map<String,Object> verParams=new ArrayMap<>();
            verParams.put(UploadConfig.APPLICANT,FlyUtil.getSn(context));
            verParams.put(UploadConfig.APPLYPVERSION,apiVersion);
            verParams.put(UploadConfig.IDENTIFY,model);
            verParams.put(UploadConfig.QUERYTIME,currentTime);
            try {
                verParams.put(UploadConfig.SIGN, SignUtil.sign(verParams,model));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return verParams;
        }
        return null;

    }


    /**
     * 这个是知道版本号之后直接升级指定app版本号的
     *
     * @param version
     * @param context
     * @return
     */
    public static  Map<String, Object> startToUpdate(String version, Context context){


        appVersionCode=version.replace(".","");
        Log.e(TAG, "升级 onSuccessCheckKey: "+appVersionCode );
        PackageManager pm=context.getPackageManager();
        String versionName="non";
        try {
            PackageInfo pi=pm.getPackageInfo(context.getPackageName(),0);
            versionName=pi.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        Log.e(TAG, "startToUpdate: "+versionName +":升级的版本为："+version);
        if(!"non".equals(versionName)) {
            Log.e(TAG, "得到想要升级的版本: " + version);
            //下一步
            Map<String, Object> verParams = new ArrayMap<>();
            long currentTime = System.currentTimeMillis();
            verParams.put(UploadConfig.APPLICANT, FlyUtil.getSn(context));
            verParams.put(UploadConfig.APPLYPVERSION, versionName);
            verParams.put(UploadConfig.IDENTIFY, broadType);
            verParams.put(UploadConfig.PVERSION, version);
            verParams.put(UploadConfig.QUERYTIME, currentTime);
            String inw01 = null;
            try {
                inw01 = SignUtil.sign(verParams, broadType);

                verParams.put(UploadConfig.SIGN, inw01);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return verParams;

//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    mPresenter.getUpdateKey(verParams);
//                }
//            });

        }else {
            Log.e(TAG, "onSuccessCheckKey: 版本升级异常" );
        }
        return null;
    }

    /**
     * 这个是知道版本号之后直接升级指定固件版本号的
     */
    /**
     *
     * @param version  欲升级版本号
     * @param context 上下文
     * @param model 升级的型号
     * @return
     */
    public static  Map<String, Object> startToUpdate(String version, Context context,String model){


        appVersionCode=version.replace(".","");
        Log.e(TAG, "升级固件 onSuccessCheckKey: "+appVersionCode );
        PackageManager pm=context.getPackageManager();
        String versionName="non";
        versionName= FlyUtil.initInot(context).getSystemVersion();

        Log.e(TAG, "startToUpdate: "+versionName +":固件升级的版本为："+version);
        if(!"non".equals(versionName)) {
            Log.e(TAG, "得到想要升级的固件版本: " + version);
            //下一步
            Map<String, Object> verParams = new ArrayMap<>();
            long currentTime = System.currentTimeMillis();
            verParams.put(UploadConfig.APPLICANT, FlyUtil.getSn(context));
            verParams.put(UploadConfig.APPLYPVERSION, versionName);
            verParams.put(UploadConfig.IDENTIFY, model);
            verParams.put(UploadConfig.PVERSION, version);
            verParams.put(UploadConfig.QUERYTIME, currentTime);
            String inw01 = null;
            try {
                inw01 = SignUtil.sign(verParams, model);

                verParams.put(UploadConfig.SIGN, inw01);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return verParams;


        }else {
            Log.e(TAG, "onSuccessCheckKey: 固件版本升级异常" );
        }
        return null;
    }

    /**
     *   将相关文件进行解压
     * @param sdPath  存储路径
     * @param subFile   存储文件夹文件夹
     * @param name  存储名称
     */
    public static void startDepressZip(Context context,String sdPath,String subFile,String name){
        File file1=null;
        //检查下载的包，看是否符合
        if ("intefly_Board".equals(name)){
            file1= FileSortUtil.createBoardVersionFile(sdPath);
        }else{
            file1= FileSortUtil.createVersionFile(sdPath);
        }

        File file2=new File(subFile);

        File file=new File(file2,name+appVersionCode+".zip");
        if (file2.getParentFile().exists()){
            if (!file2.isFile() && !file2.exists()){
                file2.mkdirs();
            }

        }
        try {
            boolean pressFlag=false;
            pressFlag = ZipUtil.deCompress(file, file2.getAbsolutePath(), decrypt);
            if (pressFlag){
                //解压完，开始升级
                if ("intefly_Board".equals(name)){
                    //进行固件升级
                    Log.e(TAG, "固件升级 startDepressZip: "+file1.getAbsolutePath());
                    FlyUtil.initInot(context).updateSystem(file1.getAbsolutePath());

                }else{
                    Log.e(TAG, "app升级 startDepressZip: "+file1.getAbsolutePath());
                    InstallClient client=new InstallClient(file1.getAbsolutePath(),file1.length());
                    client.installSlient();
                }


            }else {
                //解压出错
                Log.e(TAG, "升级 startDepressZip: 解压出错" );

            }
        } catch (ZipException e) {
            e.printStackTrace();
        }

    }


    static String pversionStr;
//    static String subStr;
    static String identifyStr;
    static String sizeStr;
//    static String applyPversionStr;
//    static String modelStr;
//    static String locationStr;
    static String pwdStr;
//    static String expStr;
    static String md5Str;
    static String decrypt;
    private static void jWTParse(String data){
        if (data.length()==0)return;
        JWT jwt1 = new JWT(data);
        Map<String, Claim> map=jwt1.getClaims();
        Map<String, String> header = jwt1.getHeader();
        Claim pversion = map.get("pversion");
        pversionStr = pversion.asString();
        Claim sub = map.get("sub");
        String subStr = sub.asString();
        Claim identify = map.get("identify");
        identifyStr = identify.asString();
        Claim size = map.get("size");
        sizeStr = size.asString();
        Claim applyPversion = map.get("applyPversion");
        String applyPversionStr = applyPversion.asString();
        Claim model = map.get("model");
        String modelStr = model.asString();
        Claim location = map.get("location");
        String locationStr = location.asString();
        Claim pwd = map.get("pwd");
        pwdStr = pwd.asString();
        Claim exp=map.get("exp");
        String expStr = exp.asString();
        Claim md5 = map.get("md5");
        md5Str = md5.asString();

//        Log.e("tiwolf解析", "JWTParse pversion: "+pversionStr );
//        Log.e("tiwolf解析", "JWTParse sub: "+subStr );
//        Log.e("tiwolf解析", "JWTParse identify: "+identifyStr );
//        Log.e("tiwolf解析", "JWTParse applyPversion: "+applyPversionStr );
//        Log.e("tiwolf解析", "JWTParse model: "+modelStr );
//        Log.e("tiwolf解析", "JWTParse location: "+locationStr );
//        Log.e("tiwolf解析", "JWTParse pwd: "+pwdStr );
//        Log.e("tiwolf解析", "JWTParse exp: "+expStr );
//        Log.e("tiwolf解析", "JWTParse md5: "+md5Str );
//        Log.e("tiwolf解析", "JWTParse size: "+sizeStr );
    }

    /**
     * app下载完成后的动作
     * @param sdPath 存储路径
     * @param pversion 将版本号置null
     * @param context
     */
    public static void startToUpdateVersion(String sdPath,String pversion,Context context){
        String key = PreferenceUtil.getString(PreferenceUtil.KEY, "tiwolf");
        if (!"tiwolf".equals(key)) {
            jWTParse(key);
            if ("IND".equals(identifyStr)){
                //说明是app升级，否则是固件升级
                File file1 = new File(Environment.getExternalStorageDirectory() + "/version/intefly_ai" + appVersionCode + ".zip");

                String fileMd5 = MD5Util.getFileMd5(file1).toUpperCase();
//                    File file = FileSortUtil.createVersionFile();
//                    String fileMd5 = MD5Util.getFileMd5(file).toUpperCase();
                Log.e(TAG, "startToUpdateVersion: App md5为="+md5Str+";文件md5="+fileMd5 );
                if (md5Str.equals(fileMd5)) {
                    //如果md5都一样，说明已经下载完,解压
                    Log.e(TAG, "downloadSuccess: 已经下载完");
                    pversion = null;
                    PreferenceUtil.commitString(PreferenceUtil.UPVERSION, "-1");
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            startDepressZip(context,sdPath,FileSortUtil.appVer,"intefly_ai");
                        }
                    }).start();

                } else {
                    PreferenceUtil.commitInt(PreferenceUtil.LENGTH, 0);
                    if (pversion != null) {
                        startToUpdate(pversion,context);
                    }

                }

            }

        } else {
            Log.e(TAG, "downloadSuccess: 程序出错");
        }

    }

    /**
     * 固件版本下载完成后的动作
     * @param sdPath 存储路径
     * @param pversion 将版本号置null
     * @param context
     */
    public static void startToUpdateVersion(String sdPath,String pversion,Context context,String model){
        String key = PreferenceUtil.getString(PreferenceUtil.BOARDKEY, "tiwolf");
        if (!"tiwolf".equals(key)) {
            jWTParse(key);
            File file1= new File(Environment.getExternalStorageDirectory() + "/boardVersion/intefly_Board" + appVersionCode + ".zip");

            Log.e(TAG, "startToUpdateVersion: 固件file1="+file1.getAbsolutePath() );
            String fileMd5 = MD5Util.getFileMd5(file1).toUpperCase();
//                    File file = FileSortUtil.createVersionFile();
//                    String fileMd5 = MD5Util.getFileMd5(file).toUpperCase();
            Log.e(TAG, "startToUpdateVersion: 固件md5为="+md5Str+";文件md5="+fileMd5 );
            if (md5Str.equals(fileMd5)) {
                //如果md5都一样，说明已经下载完,解压
                Log.e(TAG, "downloadSuccess: 固件已经下载完");
                pversion = null;
                PreferenceUtil.commitString(PreferenceUtil.BOARDVERSION, "-1");
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        startDepressZip(context,sdPath,FileSortUtil.boardVer,"intefly_Board");
                    }
                }).start();

            } else {
                PreferenceUtil.commitInt(PreferenceUtil.BOARDLENGTH, 0);
                if (pversion != null) {
                    startToUpdate(pversion,context,model);
                }

            }
        } else {
            Log.e(TAG, "downloadSuccess: 固件程序出错");
        }

    }

    /**
     * 从服务器获取到新的版本号 之后所做的动作
     * @param msg  从服务器返回的信息
     * @param pversion 上一次的版本
     * @param context 上下文
     */
    public static Map<String, Object> afterSuccessGetVersionInfo(UpLoadGetBean<CheckMsgBean> msg, String pversion, Context context){
        if (msg.getData() == null) {
            Log.e(TAG, "onSuccessCheck: 当前版本为最新版本，不需要做升级");
//                if (sdPath==null || sdPath.length()==0){
//                    FileSortUtil.delSubFile(FileSortUtil.appVer);
//                }else {
//                    FileSortUtil.delSubFile(sdPath+"/version");
//                }
            FileSortUtil.delSubFile(FileSortUtil.appVer);


        } else {
            if (pversion != null && (!pversion.equals(msg.getData().getPversion()))) {
                PreferenceUtil.commitInt(PreferenceUtil.LENGTH, 0);
            }
            pversion = msg.getData().getPversion();
            PreferenceUtil.commitString(PreferenceUtil.UPVERSION, pversion);

            appVersionCode = pversion.replace(".", "");
            Log.e(TAG, "升级 onSuccessCheckKey: " + appVersionCode);
            PackageManager pm = context.getPackageManager();
            String versionName = "non";
            try {
                PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
                versionName = pi.versionName;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

            if (!"non".equals(versionName)) {
                Log.e(TAG, "得到想要升级的版本: " + pversion);
                //下一步
                Map<String, Object> verParams = new ArrayMap<>();
                long currentTime = System.currentTimeMillis();
                verParams.put(UploadConfig.APPLICANT, FlyUtil.getSn(context));
                verParams.put(UploadConfig.APPLYPVERSION, versionName);
                verParams.put(UploadConfig.IDENTIFY, broadType);
                verParams.put(UploadConfig.PVERSION, pversion);
                verParams.put(UploadConfig.QUERYTIME, currentTime);
                String inw01 = null;
                try {
                    inw01 = SignUtil.sign(verParams, broadType);

                    verParams.put(UploadConfig.SIGN, inw01);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return verParams;
//                mPresenter.getUpdateKey(verParams);
            } else {
                Log.e(TAG, "onSuccessCheckKey: 版本升级异常");
            }
        }
        return null;
    }

    /**
     *  从服务器获取到新的固件版本号，然后进行升级
     * @param msg  从服务器返回的信息
     * @param pversion 上一次的版本
     * @param context 上下文
     */
    public static Map<String, Object> afterSuccessGetVersionInfo(UpLoadGetBean<CheckMsgBean> msg, String pversion, Context context,String model){
        if (msg.getData() == null) {
            Log.e(TAG, "onSuccessCheck: 当前版本为最新版本，不需要做升级");
//                if (sdPath==null || sdPath.length()==0){
//                    FileSortUtil.delSubFile(FileSortUtil.appVer);
//                }else {
//                    FileSortUtil.delSubFile(sdPath+"/version");
//                }
            FileSortUtil.delSubFile(FileSortUtil.boardVer);


        } else {
            if (pversion != null && (!pversion.equals(msg.getData().getPversion()))) {
                PreferenceUtil.commitInt(PreferenceUtil.BOARDLENGTH, 0);
            }
            pversion = msg.getData().getPversion();
            PreferenceUtil.commitString(PreferenceUtil.BOARDVERSION, pversion);

            appVersionCode = pversion.replace(".", "");
            Log.e(TAG, "升级 固件onSuccessCheckKey: " + appVersionCode);
            PackageManager pm = context.getPackageManager();
            String versionName = "non";

            versionName= FlyUtil.initInot(context).getSystemVersion();


            if (!"non".equals(versionName)) {
                Log.e(TAG, "固件得到想要升级的版本: " + pversion);
                //下一步
                Map<String, Object> verParams = new ArrayMap<>();
                long currentTime = System.currentTimeMillis();
                verParams.put(UploadConfig.APPLICANT, FlyUtil.getSn(context));
                verParams.put(UploadConfig.APPLYPVERSION, versionName);
                verParams.put(UploadConfig.IDENTIFY, model);
                verParams.put(UploadConfig.PVERSION, pversion);
                verParams.put(UploadConfig.QUERYTIME, currentTime);
                String inw01 = null;
                try {
                    inw01 = SignUtil.sign(verParams, model);

                    verParams.put(UploadConfig.SIGN, inw01);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return verParams;
//                mPresenter.getUpdateKey(verParams);
            } else {
                Log.e(TAG, "onSuccessCheckKey: 固件版本升级异常");
            }
        }
        return null;
    }


    /**
     *  取到下载key之后就准备去下载文件，在这里分辨
     * @param msg 获取key返回
     * @param pversion 版本
     * @param sdPath 版本路径
     * @param threadPoollExcutorUtil 线程
     */
    public static synchronized void doAfterGetKey(Context context, KeyMsgBean msg, String pversion, String sdPath, ThreadPoollExcutorUtil threadPoollExcutorUtil){
        String key = msg.getData();

        try {
            jWTParse(key);

            if ("IND".equals(identifyStr)){
                PreferenceUtil.commitString(PreferenceUtil.KEY, key);
                decrypt = DesUtil.decrypt(pwdStr);
                File file1 = new File(Environment.getExternalStorageDirectory() + "/version/intefly_ai" + appVersionCode + ".zip");

//                if (sdPath==null || sdPath.length()==0){
//                    file1=new File(Environment.getExternalStorageDirectory()+"/version/intefly_ai"+appVersionCode+".zip");
//                }else {
//                    file1=new File(sdPath+"/version/intefly_ai"+appVersionCode+".zip");
//                }
                String fileMd5 = MD5Util.getFileMd5(file1).toUpperCase();
                if (md5Str.equals(fileMd5)) {
                    //如果md5都一样，说明已经下载完,解压
                    Log.e(TAG, "升级 downloadSuccess: 已经下载完，准备解压" + decrypt);
                    pversion = null;
                    PreferenceUtil.commitString(PreferenceUtil.UPVERSION, "-1");
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //开始解压
                            startDepressZip(context,sdPath,FileSortUtil.appVer,"intefly_ai");
                        }
                    }).start();


                } else {
                    //如果没有，则继续去下载
                    //准备去下载
                    if (key != null) {
                        int anInt = PreferenceUtil.getInt(PreferenceUtil.LENGTH, 0);
                        Log.e(TAG, "升级 onClick: 当前的字节为" + anInt);
                        if (anInt == 0 || anInt == 100) {
                            //在这里将文件夹里面的文件全部删掉
                            FileSortUtil.delSubFile(FileSortUtil.appVer);
//                            if (sdPath==null || sdPath.length()==0){
//                                FileSortUtil.delSubFile(FileSortUtil.appVer);
//                            }else {
//                                FileSortUtil.delSubFile(sdPath+"/version");
//                            }


                            if (threadPoollExcutorUtil != null && sizeStr != null) {
                                Log.e(TAG, "onSuccessKey: 当前需要下载的总字节为="+sizeStr );
                                threadPoollExcutorUtil.downLoadPackageFile(file1, key, 0, sizeStr);
                            }
                        } else {
                            if (file1.exists()) {
                                if (threadPoollExcutorUtil != null && sizeStr != null) {
                                    threadPoollExcutorUtil.downLoadPackageFile(file1, key, anInt, sizeStr);
                                }
                            } else {
                                FileSortUtil.delSubFile(FileSortUtil.appVer);
//                                if (sdPath==null || sdPath.length()==0){
//                                    FileSortUtil.delSubFile(FileSortUtil.appVer);
//                                }else {
//                                    FileSortUtil.delSubFile(sdPath+"/version");
//                                }

                                if (threadPoollExcutorUtil != null && sizeStr != null) {
                                    threadPoollExcutorUtil.downLoadPackageFile(file1, key, 0, sizeStr);
                                }
                            }

                        }
                    }
                }
            }else{
                PreferenceUtil.commitString(PreferenceUtil.BOARDKEY, key);
                decrypt = DesUtil.decrypt(pwdStr);
                File file1 = new File(Environment.getExternalStorageDirectory() + "/boardVersion/intefly_Board" + appVersionCode + ".zip");

//                if (sdPath==null || sdPath.length()==0){
//                    file1=new File(Environment.getExternalStorageDirectory()+"/version/intefly_ai"+appVersionCode+".zip");
//                }else {
//                    file1=new File(sdPath+"/version/intefly_ai"+appVersionCode+".zip");
//                }
                Log.e(TAG, "doAfterGetKey:固件md5= "+file1.getAbsolutePath()+";文件md5="+md5Str );
                String fileMd5 = MD5Util.getFileMd5(file1).toUpperCase();
                if (md5Str.equals(fileMd5)) {
                    //如果md5都一样，说明已经下载完,解压
                    Log.e(TAG, "升级 downloadSuccess: 已经下载完，准备解压" + decrypt);
                    pversion = null;
                    PreferenceUtil.commitString(PreferenceUtil.BOARDVERSION, "-1");
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //开始解压
                            startDepressZip(context,sdPath,FileSortUtil.boardVer,"intefly_Board");
                        }
                    }).start();


                } else {
                    //如果没有，则继续去下载
                    //准备去下载
                    if (key != null) {
                        int anInt = PreferenceUtil.getInt(PreferenceUtil.BOARDLENGTH, 0);
                        Log.e(TAG, "升级 onClick: 当前的字节为" + anInt);
                        if (anInt == 0 || anInt == 100) {
                            //在这里将文件夹里面的文件全部删掉
                            FileSortUtil.delSubFile(FileSortUtil.boardVer);
//                            if (sdPath==null || sdPath.length()==0){
//                                FileSortUtil.delSubFile(FileSortUtil.appVer);
//                            }else {
//                                FileSortUtil.delSubFile(sdPath+"/version");
//                            }


                            if (threadPoollExcutorUtil != null && sizeStr != null) {
                                Log.e(TAG, "onSuccessKey: 当前需要下载的总字节为="+sizeStr );
                                threadPoollExcutorUtil.downLoadBoardPackageFile(file1, key, 0, sizeStr);
                            }
                        } else {
                            if (file1.exists()) {
                                if (threadPoollExcutorUtil != null && sizeStr != null) {
                                    threadPoollExcutorUtil.downLoadBoardPackageFile(file1, key, anInt, sizeStr);
                                }
                            } else {
                                FileSortUtil.delSubFile(FileSortUtil.appVer);
//                                if (sdPath==null || sdPath.length()==0){
//                                    FileSortUtil.delSubFile(FileSortUtil.appVer);
//                                }else {
//                                    FileSortUtil.delSubFile(sdPath+"/version");
//                                }

                                if (threadPoollExcutorUtil != null && sizeStr!= null) {
                                    threadPoollExcutorUtil.downLoadBoardPackageFile(file1, key, 0, sizeStr);
                                }
                            }

                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            PreferenceUtil.commitBoolean(PreferenceUtil.PACKAGEFLAG, false);
        }
    }

}
