package com.ytf.dogbox.dogHttp;

import com.ytf.dogbox.base.view.BaseView;
import com.ytf.dogbox.bean.AdvertBean;
import com.ytf.dogbox.bean.AlarmBean;
import com.ytf.dogbox.bean.CheckMsgBean;
import com.ytf.dogbox.bean.DogAlarmBean;
import com.ytf.dogbox.bean.DogExceBean;
import com.ytf.dogbox.bean.DogHttpKeyBean;
import com.ytf.dogbox.bean.DogSnBean;
import com.ytf.dogbox.bean.DogSyncConfigBean;
import com.ytf.dogbox.bean.DogTonkenBean;
import com.ytf.dogbox.bean.ErrorBean;
import com.ytf.dogbox.bean.HttpPayBean;
import com.ytf.dogbox.bean.KeyMsgBean;
import com.ytf.dogbox.bean.PayBean;
import com.ytf.dogbox.bean.QiniuMsgBean;
import com.ytf.dogbox.bean.RefundBean;
import com.ytf.dogbox.bean.RefundParamBean;
import com.ytf.dogbox.bean.UpLoadGetBean;
import com.ytf.dogbox.bean.UpLoadGetSubBean;

import java.util.List;
import java.util.Map;

import io.reactivex.Flowable;
import retrofit2.http.Body;

/**
 * author:tiwolf
 * create date:2023/11/1
 * Describe:用来管理dog相关的数据
 */
public interface DogContract {

    interface Model{
        Flowable<KeyMsgBean> getDogState();
        Flowable<UpLoadGetBean<UpLoadGetSubBean>> getMerge(Map<String, String> map);
        Flowable<QiniuMsgBean> getQiniuKey(Map<String, Object> map);

        Flowable<KeyMsgBean> getQiniuDownloadUrl(Map<String,Object> map);
        Flowable<KeyMsgBean> getUpdatePolice(Map<String,String> map);
        Flowable<KeyMsgBean> updateRecordMsg(Map<String,Object> map);

        Flowable<KeyMsgBean> delRecordMsg(Map<String, Object> map);
        Flowable<UpLoadGetBean<ErrorBean>> upSendError(Map<String,String> map);
        Flowable<UpLoadGetBean<CheckMsgBean>> updateMsg(Map<String, Object> map);

        Flowable<UpLoadGetBean<DogTonkenBean>> getHttpKey(DogHttpKeyBean dogHttpKeyBean);
        Flowable<KeyMsgBean> getUpdateKey(Map<String, Object> map);
        Flowable<UpLoadGetBean<PayBean>> orderPay(HttpPayBean httpPayBean,String token);
        Flowable<UpLoadGetBean<RefundBean>> refundPay(RefundParamBean refundParamBean,String token);
        Flowable<KeyMsgBean> upLoadDogException(DogExceBean dogExceBean,String token);
        Flowable<KeyMsgBean> upLoadAlarmWarning(DogAlarmBean dogAlarmBean,String token);
        Flowable<UpLoadGetBean<DogSyncConfigBean>> syncConfigData(DogSnBean dogSnBean,String token);
        Flowable<UpLoadGetBean<AdvertBean<List<AlarmBean>>>> getDeviceDataAdvert(Map<String,String> map); //同步广告
    }

    interface View extends BaseView{

        void onSuccessDogState();

        void onFailDogState();

        void onSuccessMerge(UpLoadGetBean<UpLoadGetSubBean> msg,String lastModifiedTime);

        void onErrorMerge(Throwable throwable,String md5);

        void nonGetMessage(String error);

        void onSuccessGetKey(QiniuMsgBean msg);

        void onFailGetKey(Throwable throwable);

        void onSuccessGetDownloadUrl(KeyMsgBean msg);

        void onFailGetDownloadUrl(Throwable throwable);

        void onSuccessPolice(KeyMsgBean msg,Map<String,String> police);
        void onSuccessUpdateMsg(KeyMsgBean msg,String content);

        void onFailUpdateMsg(Throwable throwable,String content,String md5);

        void onSuccessDelMsg(KeyMsgBean msg,String content);

        void onFailDelMsg(Throwable throwable,String content);
        void upSendErrorSuccess(UpLoadGetBean<ErrorBean> keyMsgBean);

        void upSendErrorFail(Throwable throwable);

        void onSuccessCheckKey(UpLoadGetBean<CheckMsgBean> msg);

        void onSuccessKey(KeyMsgBean msg);

        void onSuccessPayUrl(UpLoadGetBean<PayBean> payMsg);

        void onFailPay(Throwable throwable);
        void onSuccessRefundPay(UpLoadGetBean<RefundBean> refundBean);
        void onFailRefundPay(Throwable throwable);
        void onSuccessUploadDogException(KeyMsgBean keyMsgBean);
        void onFailUploadDogException(Throwable throwable);
        void onSuccessGetToken(UpLoadGetBean<DogTonkenBean> dogTonkenBeanUpLoadGetBean);
        void onFailGetToken(Throwable throwable);
        void onSuccessUploadDogAlarm(KeyMsgBean keyMsgBean);
        void onFailUploadDogAlarm(Throwable throwable);
        void onSuccessSyncConfigData(UpLoadGetBean<DogSyncConfigBean> dogSyncConfigBeanUpLoadGetBean);
        void onFailSyncConfigData(Throwable throwable);
        void onSuccessAdvert(UpLoadGetBean<AdvertBean<List<AlarmBean>>> map);
        void onFailAdvert(Throwable throwable);
    }

    interface  Presenter{
        void getDogState();
        void getMerge(Map<String, String> map,String lastModifiedTime);
        void getQiniuKey(Map<String, Object> map);
        void getQiniuDownloadUrl(Map<String, Object> map);
        void getUpdatePolice(Map<String,String> map);
        void updateRecordMsg(Map<String,Object> map,String content,String md5);
        void delRecordMsg(Map<String, Object> map,String content);
        void upSendError(Map<String,String> map);
        void updateMsg(Map<String, Object> map);
        void getUpdateKey(Map<String, Object> map);
        void orderPay(HttpPayBean httpPayBean,String token);
        void refundPay(RefundParamBean refundParamBean,String token);
        void upLoadDogException(DogExceBean dogExceBean,String token);
        void getHttpKey(DogHttpKeyBean dogHttpKeyBean);
        void upLoadAlarmWarning(DogAlarmBean dogAlarmBean,String token);
        void syncConfigData(DogSnBean dogSnBean,String token);
        void getDeviceDataAdvert(Map<String,String> map);
    }
}
