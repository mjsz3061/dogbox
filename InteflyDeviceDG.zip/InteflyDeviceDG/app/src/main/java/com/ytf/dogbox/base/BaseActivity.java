package com.ytf.dogbox.base;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;



public abstract class BaseActivity extends Activity implements IBase {
    protected Activity activity;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this;
        if (getLayout()!=0){
            setContentView(getLayout());
        }

        initView(savedInstanceState);
        initData();
        setListener();
    }

    @Override
    public void initData() {

    }

    @Override
    public void setListener() {

    }

}
