package com.ytf.dogbox.activity;

import android.os.Process;

import com.ytf.dogbox.util.Log;

//实现UncaughtExceptionHandler接口
public class CrashHandler implements Thread.UncaughtExceptionHandler {
    
    private static CrashHandler mAppCrashHandler;
    //系统默认的处理器
    private Thread.UncaughtExceptionHandler mDefaultHandler;
 
    private CrashHandler(){}
 
    public void initCrashHandler() {
        // 获取系统默认的UncaughtException处理器
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        //设置系统
        Thread.setDefaultUncaughtExceptionHandler(this);
    }
 
    public static CrashHandler getInstance() {
        if (mAppCrashHandler == null) {
            mAppCrashHandler = new CrashHandler();
        }
        return mAppCrashHandler;
    }
 
    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        // 回调函数，处理异常
        // 在这里将崩溃日志读取出来，然后保存到SD卡，或者直接上传到日志服务器
        // 注意 保存或者上传到日志服务器需要将系统版本，手机唯一标识等系统信息和崩溃信息一同上传，方便分析crash问题
        // 如果用户没有处理则让系统默认的异常处理器来处理
        Log.e("tiwolf", "uncaughtException: 收集到app遭遇到未知错误，清除缓存，异常线程="+thread.getName()+";异常线程id="+thread.getId()+";异常信息："+ex.getLocalizedMessage() );
        Process.killProcess(Process.myPid());
        System.exit(0);
    }
}