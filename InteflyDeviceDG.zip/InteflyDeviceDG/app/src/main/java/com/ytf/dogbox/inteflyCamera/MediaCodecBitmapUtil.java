package com.ytf.dogbox.inteflyCamera;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.os.Build;
import android.view.SurfaceHolder;

import androidx.annotation.RequiresApi;

import com.ytf.dogbox.util.Log;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ConcurrentLinkedDeque;


/**
 * Created by ZhangHao on 2016/8/5.
 * 用于硬件解码(MediaCodec)H264的工具类
 */
@TargetApi(Build.VERSION_CODES.LOLLIPOP)
@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
public class MediaCodecBitmapUtil {

    //解码后显示的surface及其宽高
    private SurfaceHolder holder;
    private int width, height;
    //解码器
    private MediaCodec mCodec;
    private boolean isFirst = true;
    // 需要解码的类型
    private final static String MIME_TYPE = "video/avc"; // H.264 Advanced Video
    private final static int TIME_INTERNAL = 5;

    /**
     * 初始化解码器
     *
     * @param holder 用于显示视频的surface
     * @param width  surface宽
     * @param height surface高
     */
    public MediaCodecBitmapUtil(SurfaceHolder holder, int width, int height) {
//        logger.d("MediaCodecUtil() called with: " + "holder = [" + holder + "], " +
//                "width = [" + width + "], height = [" + height + "]");
        this.holder = holder;
        this.width = width;
        this.height = height;
//        doPicWork();
//        doPicWork1();
    }

    public MediaCodecBitmapUtil(SurfaceHolder holder) {
        this(holder, 640, 480);
    }

    public void startCodec() {
        if (isFirst) {
            //第一次打开则初始化解码器
            initDecoder();
        }
    }

    public void setCodecSize(int width,int height){
        if (this.width!=width){
            this.width=width;
            this.height=height;
            Log.i("tiwolf", "setCodecSize: 摄像头设置了宽和高="+width+";"+height );
            stopDecoder();
            initDecoder();
        }

    }


    private void initDecoder() {
        try {
            //根据需要解码的类型创建解码器
            mCodec = MediaCodec.createDecoderByType(MIME_TYPE);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //初始化MediaFormat
        MediaFormat mediaFormat = MediaFormat.createVideoFormat(MIME_TYPE,
                width, height);
        mediaFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar);
        //配置MediaFormat以及需要显示的surface
        mCodec.configure(mediaFormat, null, null, 0);
        //开始解码
        mCodec.start();
        isFirst = false;
    }

    //先将这个解码器释放
    public void stopDecoder(){
        if (mCodec!=null){
            mCodec.flush();
            mCodec.stop();
            mCodec.release();
            mCodec=null;
        }
    }

    int mCount = 0;


    boolean isOnlyOneFramedecodec=true;  //确保每次进去解码成图片的帧是唯一的
    public boolean onFrame(byte[] buf, int offset, int length) {
//        Log.i("tiwolf", "onFrame: 开始解码" );
        long delong= System.currentTimeMillis();
        if (mCodec==null)return false;
        //-1表示一直等待；0表示不等待；其他大于0的参数表示等待毫秒数
        int inputBufferIndex = mCodec.dequeueInputBuffer(-1);
        if (inputBufferIndex >= 0) {
//            ByteBuffer inputBuffer = inputBuffers[inputBufferIndex];
            ByteBuffer inputBuffer = mCodec.getInputBuffer(inputBufferIndex);
            //清空buffer
            inputBuffer.clear();
            //put需要解码的数据
            inputBuffer.put(buf, offset, length);
            //解码
            mCodec.queueInputBuffer(inputBufferIndex, offset, length, mCount*TIME_INTERNAL, 0);
            mCount++;

        } else {
            return false;
        }
//        Log.i("tiwolf", "onFrame: 开始解码，添加byteBuffer进去"+(System.currentTimeMillis()-delong));
        // 获取输出buffer index
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        int outputBufferIndex = mCodec.dequeueOutputBuffer(bufferInfo, 0);
        //循环解码，直到数据全部解码完成
        while (outputBufferIndex >= 0) {
            //logger.d("outputBufferIndex = " + outputBufferIndex);
            //true : 将解码的数据显示到surface上
            ByteBuffer outputBuffer = mCodec.getOutputBuffer(outputBufferIndex);
//            Log.i("tiwolf", "onFrame bitmap: 使用surfaceview后数据"+outputBuffer);
//            Log.i("tiwolf", "onFrame bitmap: 可以获取到帧数据11111" );
            if (outputBuffer!=null){
//                Log.i("tiwolf", "开始解码 onFrame bitmap: 可以获取到帧数据22222" );
                long start= System.currentTimeMillis();
//                ByteBuffer nv21Buffer = outputBuffer.duplicate();
//                Log.i("tiwolf", "onFrame bitmap: 复制内存需要时间"+(System.currentTimeMillis()-start) );
                setOutByte(outputBuffer,bufferInfo);

            }
            mCodec.releaseOutputBuffer(outputBufferIndex, false);
            outputBufferIndex = mCodec.dequeueOutputBuffer(bufferInfo, 0);
//            Log.i("tiwolf", "onFrame bitmap: 可以获取到帧数据33333" );
            Log.i("TAG", "onFrame: 对帧数据进行解码00++++++");
        }
//        Log.i("tiwolf", "onFrame:开始解码 解码一帧所需时间"+(System.currentTimeMillis()-delong) );
        if (outputBufferIndex < 0) {
            //logger.e("outputBufferIndex = " + outputBufferIndex);
//            Log.i("tiwolf", "onFrame: 超时问题"+outputBufferIndex );
        }

//        System.gc();
        return true;
    }

    long dolongTime=0;
    int num=2;
    byte[] mConfigByte;
    int size=0;
    byte[] outData=null;
    byte[] nv21Data=null;
    boolean isCodeFlag=true;
    private synchronized void setOutByte(ByteBuffer outputBufffer,  MediaCodec.BufferInfo bufferInfo){
//        Log.i("tiwolf", "Background 解码==setOutByte: size="+size+";buffersize="+bufferInfo.size+";outData="+outData );
        if (isCodeFlag || bufferInfo.size!=size || outData==null || nv21Data==null){
//            Log.i("tiwolf", "Background 解码==setOutByte: 00000" );
            isCodeFlag=false;
            size=bufferInfo.size;
            outData = new byte[bufferInfo.size];    //todo 2021.9.7大问题（严重）--只有size不一样的时候才会new新的，以确保这个不会消耗大量内存
            nv21Data = new byte[bufferInfo.size];
        }

        outputBufffer.get(outData);
        if (outData.length>0){
            if (bufferInfo.flags == 2) {
                mConfigByte = new byte[bufferInfo.size];
                mConfigByte = outData;
            } else if (bufferInfo.flags == 1) {
                byte[] keyframe = new byte[bufferInfo.size + mConfigByte.length];
                System.arraycopy(mConfigByte, 0, keyframe, 0, mConfigByte.length);
                System.arraycopy(outData, 0, keyframe, mConfigByte.length, outData.length);
                iByteArray.setByteArray(keyframe,width,height);
            } else {

                long start= System.currentTimeMillis();
//                Log.i("tiwolf", "setOutByte: 图片解压得到的内容长度为---"+nv21Data.length );

                NV12ToNV21(outData,nv21Data,width,height);
                iByteArray.setByteArray(nv21Data,width,height);
                outputBufffer.clear();

            }
        }

    }

//    private static int length=0;
//    static byte[] nv21=null;
    //TODO 这个会导致很多的gc回收,但是它本身处理不需要多少时间 主要是产生大量的byte[]数组
    private static byte[] NV12ToNV21(byte[] data,int width,int height){

//        if (length==0 || length==data.length){
//            nv21=new byte[data.length];
//            length=data.length;
//        }
        byte[] nv21=new byte[data.length];
        int framesize=width*height;
        int i=0,j=0;
        System.arraycopy(data,0,nv21,0,framesize);
        for ( i = 0; i < framesize; i++) {
            nv21[i]=data[i];
        }
        for (j = 0; j < framesize/2; j+=2) {
            nv21[framesize+j-1]=data[j+framesize];
        }
        for (j = 0; j < framesize/2; j+=2) {
            nv21[framesize+j]=data[j+framesize-1];
        }
        return nv21;
    }

    private static byte[] NV12ToNV21(byte[] data,byte[] nv21,int width,int height){

//        byte[] nv21=new byte[data.length];
        int framesize=width*height;
//        System.arraycopy(data,0,nv21,0,framesize);
//        for ( i = 0; i < framesize; i++) {
//            nv21[i]=data[i];
//        }
        System.arraycopy(data,0,nv21,0,framesize);
        for (int i = 0; i < framesize/4; i++) {
            nv21[framesize + i*2 ] = data[framesize + i*2 +1];
            nv21[framesize + i*2 + 1] = data[framesize + i*2];
        }
        return nv21;
    }



    public static byte[] NV12ToYuv420P(byte[] nv12,int width,int height) {

        byte[] yuv420p=new byte[nv12.length];
        int ySize = width * height;

        int i, j;

//y
        for (i =0; i < ySize; i++) {
            yuv420p[i] = nv12[i];
        }

//u
        i =0;
        for (j =0; j < ySize /2; j +=2) {
            yuv420p[ySize + i] = nv12[ySize + j];
            i++;
        }

//v
        i =0;
        for (j =1; j < ySize /2; j+=2) {
            yuv420p[ySize *5 /4 + i] = nv12[ySize + j];
            i++;
        }

        return yuv420p;
    }

    public  byte[] NV12ToYuv420P(byte[] nv12,byte[] yuv420p,int width,int height) {

//        byte[] yuv420p=new byte[nv12.length];
        int ySize = width * height;

        int i, j;

//y
//        for (i =0; i < ySize; i++) {
//            yuv420p[i] = nv12[i];
//        }

//u
        i =0;
        for (j =0; j < ySize /2; j +=2) {
            yuv420p[ySize + i] = nv12[ySize + j];
            yuv420p[ySize *5 /4 + i] = nv12[ySize + j+1];
            i++;
        }

//v
//        i =0;
//        for (j =1; j < ySize /2; j+=2) {
//
//            i++;
//        }

        return yuv420p;
    }


    /**
    *停止解码，释放解码器
    */
    public void stopCodec() {

        try {
            mCodec.flush();
            mCodec.stop();
            mCodec.release();
            mCodec = null;
            isFirst = true;
        } catch (Exception e) {
            e.printStackTrace();
            mCodec = null;
        }

        outData=null;
        nv21Data=null;

        cacheLinkedDeque.clear();

        if (picWorker != null) {
            picWorker.interrupt();
            try {
                picWorker.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
                picWorker.interrupt();
            }
            picWorker = null;
        }
    }

    IByteArray iByteArray;
    public interface IByteArray{
        void setByteArray(byte[] flag, int width, int height);
        void setyuvArray(byte[] yuv, int width, int height);
    }
    public void setiByteArray(IByteArray iByteArray){
        this.iByteArray=iByteArray;
    }


    private Thread picWorker;
    private final Object writeLock = new Object();
    private ConcurrentLinkedDeque<BytePicMsg> cacheLinkedDeque=new ConcurrentLinkedDeque<>();

    //这个处理nv21人脸识别
    public void doPicWork(){

        picWorker=new Thread(new Runnable() {
            @Override
            public void run() {
                long dolongTime=0;      //当上一帧图片处理时间太长的时候，直接跳过下一帧 隔帧处理
                while (!Thread.interrupted()) {
                    while (!cacheLinkedDeque.isEmpty()) {
//                        Log.i(TAG, "run: 将nv12处理成nv21" );
                        long start= System.currentTimeMillis();
                        BytePicMsg source=cacheLinkedDeque.poll();
                        if (source.origin.length>0){
                            NV12ToNV21(source.origin,source.output,width,height);
                            if ((System.currentTimeMillis()-start)>10 || dolongTime>50){
//                                Log.i("tiwolf", "run: 上一次人脸识别大于50毫秒,或者nv12转换nv21大于10毫秒，不处理这一帧" );

                            }else {
//                                Log.i("tiwolf", "run: 上一次人脸识别大于50毫秒，不处理这一帧" );
                                iByteArray.setByteArray(source.output,width,height);
                            }

//                            Log.i("tiwolf", "setOutByte: 上一次转换成nv21人脸识别之后所需时间"+(System.currentTimeMillis()-start) );
                            dolongTime= System.currentTimeMillis()-start;

                        }

                    }
                    // Waiting for next frame
                    synchronized (writeLock) {
                        try {
                            // isEmpty() may take some time, so we set timeout to detect next frame
                            writeLock.wait(500);
                        } catch (InterruptedException ie) {
                            picWorker.interrupt();
                        }
                    }
                }
            }
        });
        picWorker.start();
    }

    private Thread picWorker1;
    private final Object writeLock1 = new Object();
    private ConcurrentLinkedDeque<BytePicMsg> cacheLinkedDeque1=new ConcurrentLinkedDeque<>();

    public void doPicWork1(){
//        Log.i("tiwolf", "doPicWork: 启动nv21数据处理" );
        picWorker1=new Thread(new Runnable() {
            @Override
            public void run() {

                while (!Thread.interrupted()) {
                    while (!cacheLinkedDeque1.isEmpty()) {
//                        Log.i(TAG, "run: 将nv12处理成nv21" );
                        long start= System.currentTimeMillis();
                        BytePicMsg source=cacheLinkedDeque1.poll();
                        if (source.origin.length>0){
                            NV12ToYuv420P(source.origin,source.output,width,height);
                            iByteArray.setyuvArray(source.output,height,width);
                        }
//                        Log.i("tiwolf", "setOutByte: 转换成yuv420所需时间"+(System.currentTimeMillis()-start) );

                    }
                    // Waiting for next frame
                    synchronized (writeLock1) {
                        try {
                            // isEmpty() may take some time, so we set timeout to detect next frame
                            writeLock1.wait(500);
                        } catch (InterruptedException ie) {
                            picWorker1.interrupt();
                        }
                    }
                }
            }
        });
        picWorker1.start();
    }


    class BytePicMsg{
        byte[] origin;
        byte[] output;
        public BytePicMsg(byte[] origin,byte[] output){
            this.origin=origin;
            this.output=output;
        }

    }
}
