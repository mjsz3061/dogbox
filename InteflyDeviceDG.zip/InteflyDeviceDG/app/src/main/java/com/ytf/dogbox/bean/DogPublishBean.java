package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/12/7
 * Describe:
 */
public class DogPublishBean {

    private String upTime; //上传时间
    private String sn;      //sn
    private String netType; //网络类型
    private String netst;   //网络强度
    private String appVersion;//APP版本
    private String inotVersion; //硬件版本
    private String boardModel;//主板类型
    private String lng;//纬度
    private String lat;//经度
    private String volume;//当前音量
    private String storage;//存储大小
    private String tfStatus;//TF卡状态
    private String ip;//设备IP
    private String timeZone;//时区
    private String inLight;//内照明
    private String outLight;//外照明
    private String shower;//沐浴露量
    private String conditioner;//护毛素量
    private String disinfectant;//消毒液量
    private String doorStatus;//开关门状态
    private String temp;//水温
    private String roomTemp;//室温
    private String eleLevel;//电量
    private String voltage;//电压
    private String eleCurrent;//电流
    private String freq;//频率
    private int washState;//洗狗机是否处于洗狗中
    private int remainTime;//还剩多少分钟洗完狗

    public String getUpTime() {
        return upTime;
    }

    public void setUpTime(String upTime) {
        this.upTime = upTime;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getNetType() {
        return netType;
    }

    public void setNetType(String netType) {
        this.netType = netType;
    }

    public String getNetst() {
        return netst;
    }

    public void setNetst(String netst) {
        this.netst = netst;
    }

    public String getInotVersion() {
        return inotVersion;
    }

    public void setInotVersion(String inotVersion) {
        this.inotVersion = inotVersion;
    }

    public String getBoardModel() {
        return boardModel;
    }

    public void setBoardModel(String boardModel) {
        this.boardModel = boardModel;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getTfStatus() {
        return tfStatus;
    }

    public void setTfStatus(String tfStatus) {
        this.tfStatus = tfStatus;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public String getInLight() {
        return inLight;
    }

    public void setInLight(String inLight) {
        this.inLight = inLight;
    }

    public String getOutLight() {
        return outLight;
    }

    public void setOutLight(String outLight) {
        this.outLight = outLight;
    }

    public String getShower() {
        return shower;
    }

    public void setShower(String shower) {
        this.shower = shower;
    }

    public String getConditioner() {
        return conditioner;
    }

    public void setConditioner(String conditioner) {
        this.conditioner = conditioner;
    }

    public String getDisinfectant() {
        return disinfectant;
    }

    public void setDisinfectant(String disinfectant) {
        this.disinfectant = disinfectant;
    }

    public String getDoorStatus() {
        return doorStatus;
    }

    public void setDoorStatus(String doorStatus) {
        this.doorStatus = doorStatus;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getRoomTemp() {
        return roomTemp;
    }

    public void setRoomTemp(String roomTemp) {
        this.roomTemp = roomTemp;
    }

    public String getEleLevel() {
        return eleLevel;
    }

    public void setEleLevel(String eleLevel) {
        this.eleLevel = eleLevel;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public String getEleCurrent() {
        return eleCurrent;
    }

    public void setEleCurrent(String eleCurrent) {
        this.eleCurrent = eleCurrent;
    }

    public String getFreq() {
        return freq;
    }

    public void setFreq(String freq) {
        this.freq = freq;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }


    public int getWashState() {
        return washState;
    }

    public void setWashState(int washState) {
        this.washState = washState;
    }

    public int getRemainTime() {
        return remainTime;
    }

    public void setRemainTime(int remainTime) {
        this.remainTime = remainTime;
    }
}
