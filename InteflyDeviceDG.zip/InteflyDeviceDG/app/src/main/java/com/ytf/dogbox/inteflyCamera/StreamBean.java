package com.ytf.dogbox.inteflyCamera;

/**
 * author:tiwolf
 * create date:2022/7/11
 * Describe:
 */
public class StreamBean {

    private int isItfRtmpInitFlag;
    private long ts;
    private int len;
    private byte[] data;

    public int getIsItfRtmpInitFlag() {
        return isItfRtmpInitFlag;
    }

    public void setIsItfRtmpInitFlag(int isItfRtmpInitFlag) {
        this.isItfRtmpInitFlag = isItfRtmpInitFlag;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
