package com.ytf.dogbox.boxState;

import android.content.Context;

import com.ytf.dogbox.activity.SocketService;
import com.ytf.dogbox.serialport.SerialHelper;
import com.ytf.dogbox.util.IEEE754;
import com.ytf.dogbox.util.Log;


/**
 * author:tiwolf
 * create date:2023/2/3
 * Describe:电表数据解析改造
 */
public class AmmeterData extends SerialBaseData{

    /**==电表数据获取===**/
    //这个是获取电表电压指令 01 04 00 00 00 02 71 CB
    //这个是获取电表电流指令 01 04 00 08 00 02 F0 09
    //这个是获取电表电量指令 01 04 01 00 00 02 70 37
    //这个是获取电表频率    01 04 00 36 00 02 91 C5
    //这个是清除电表电量的指令 05 AA 01 DE A1

    private String TAG=AmmeterData.class.getSimpleName();
    public static final String mevol="050400000002704F";//meter voltage电表电压
    public static final String mecur="050400080002F18D";//meter current电表电流
    public static final String mecha="05040100000271B3";//meter charge电表电量
    public static final String mefre="0504003600029041";//meter frequency电表频率

    public AmmeterData(){}


    @Override
    public void sendOrderToDevice(SerialHelper serialControl, String order) {

    }

    @Override
    public Object receiveDataFromDevice(Context context, String result) {
        return null;
    }

    /**
     * 解析电表数据返回所得
     * @return
     */
    public String getMeterContent(String str,int eleType){
        if (eleType==1){        //电压
            float vNum= IEEE754.hexStr2FloatIeee(str.substring(6,14));
            Log.i("TAG", "DispRecData: 电表得到的电压="+vNum );
            return (""+vNum);
        }else if (eleType==2){  //电流
            float aNum=IEEE754.hexStr2FloatIeee(str.substring(6,14));
            Log.i(TAG, "DispRecData: 电表得到的电流="+aNum );
            return (""+aNum);
        }else if(eleType==3){   //电量
            float eNum=IEEE754.hexStr2FloatIeee(str.substring(6,14));
            Log.i(TAG, "DispRecData: 电表得到的电量="+eNum );
            return (""+eNum);
        }else if (eleType==4){  //频率
            float pNum=IEEE754.hexStr2FloatIeee(str.substring(6,14));
            Log.i(TAG, "DispRecData: 电表得到的频率="+pNum );
            return (""+pNum);
        }
        return null;
    }

}
