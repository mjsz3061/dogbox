package com.ytf.dogbox.util;

/**
 * @author tiwolf_li
 * @Date on 2020/8/3
 * @Description
 */
public class Log {

    public static boolean isShow=true;

    public static void e(String TAG,String msg){
        if (isShow){
            android.util.Log.e(TAG, msg);
        }
    }

    public static void d(String TAG,String msg){
        if (isShow){
            android.util.Log.d(TAG, msg);
        }
    }

    public static void i(String TAG,String msg){
        if (isShow){
            android.util.Log.i(TAG, msg);
        }
    }

    public static void v(String TAG,String msg){
        if (isShow){
            android.util.Log.v(TAG, msg);
        }
    }

    public static void w(String TAG,String msg){
        if (isShow){
            android.util.Log.w(TAG, msg);
        }
    }
}
