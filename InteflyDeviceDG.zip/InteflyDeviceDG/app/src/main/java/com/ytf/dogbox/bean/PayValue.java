package com.ytf.dogbox.bean;

public class PayValue {
    private String bodyFeature;
    private String hairFeature;
    private PayList[] list;
    private String tickFeature;
    private String washFeature;
    private String washType;
    private String sn;
    private String temp;

    public String getBodyFeature() { return bodyFeature; }
    public void setBodyFeature(String value) { this.bodyFeature = value; }

    public String getHairFeature() { return hairFeature; }
    public void setHairFeature(String value) { this.hairFeature = value; }

    public PayList[] getList() { return list; }
    public void setList(PayList[] value) { this.list = value; }

    public String getTickFeature() { return tickFeature; }
    public void setTickFeature(String value) { this.tickFeature = value; }

    public String getWashFeature() { return washFeature; }
    public void setWashFeature(String value) { this.washFeature = value; }

    public String getWashType() { return washType; }
    public void setWashType(String value) { this.washType = value; }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }
}