package com.ytf.dogbox.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * @author tiwolf_li
 * @Date on 2020/1/3
 * @Description 版本6：添加公益任务表
 *              版本7：添加上传失败收集表
 *              版本8：广告列表添加时段总时间，来作为同步广告的时间依据
 *              版本10：添加电量存储表格  2022.01.10
 */
public class SqliteHelper extends SQLiteOpenHelper {

    public SqliteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
//        Log.e("tiwolf", "onCreate: 数据库创建" );
        StringBuffer vStringBuffer=new StringBuffer();

        //新建上传表头  文件名（用来管理文件的上传，上传大小，上传）
        vStringBuffer.append("Create table upload_file(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("chunkIndex int,");        // 这个在分片后的文件记录里面代表了分片排序，在源文件记录里面代表了已经上传的数量
        vStringBuffer.append("chunkNumber int,");       //这个是分片总数
        vStringBuffer.append("chunkSize varchar(20),"); //分片大小
        vStringBuffer.append("ext varchar(20),");
        vStringBuffer.append("filePath varchar(50),");  //文件途径
        vStringBuffer.append("lastModifiedTime varchar(50),");//文件建成时间
        vStringBuffer.append("md5 varchar(50),");  //md5
        vStringBuffer.append("originName varchar(50),");
        vStringBuffer.append("size varchar(20),");  //文件总大小
        vStringBuffer.append("upstate int)");       //文件上传状态 , 0表示未上传，1表示已上传，2表示正在上传 100表示当前文件已经拆分，还未上传完

        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);

        //新建下载表明细
        vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table download_file(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("downloadMd5 varchar(50),");       //下载所需md5
        vStringBuffer.append("downloadLength varchar(20),");    //已下载的文件长度
        vStringBuffer.append("downloadTotal varchar(20),");     //文件总长度
        vStringBuffer.append("downloadFlag int,");              //是否已经下载
        vStringBuffer.append("playType int,");                  //文件类型
//        vStringBuffer.append("alarmId int,");                 //闹钟的id
        vStringBuffer.append("downloadId int,");                //下载的id
        vStringBuffer.append("downloadName varchar(50),");      //文件名字
        vStringBuffer.append("downloadExt varchar(10))");       //后缀名
        sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);

        //新建播放表明细
        vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table play_list(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("downloadMd5 varchar(50),");       //下载所需md5
        vStringBuffer.append("playExt varchar(10),");           //播放后缀名
        vStringBuffer.append("playName varchar(50),");          //播放名字
        vStringBuffer.append("content varchar(200),");           //文字内容
        vStringBuffer.append("playType int,");                  //文件类型
        vStringBuffer.append("downloadTotal varchar(20),");     //文件总长度
        vStringBuffer.append("downloadId int,");                //下载的id
        vStringBuffer.append("playTime int,");                  //播放时间长度
        vStringBuffer.append("alarmId int,");                   //闹钟的id
        vStringBuffer.append("alarm1 int,");                    //闹钟直接操作
        vStringBuffer.append("alarm2 int,");                    //闹钟直接操作2
        vStringBuffer.append("startTime varchar(10),");         //闹钟开启时间
        vStringBuffer.append("endTime varchar(10),");           //闹钟结束时间
        vStringBuffer.append("avTime varchar(20),");            //当前时间段广告的总时间
        vStringBuffer.append("mediaName varchar(50),");            //广告名称
        vStringBuffer.append("volumn int,");
        vStringBuffer.append("playIndex int)");                 //播放的排序

        sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);


        addUpdateRecord(sqLiteDatabase);
        addLiveTab(sqLiteDatabase);
        addScreenTab(sqLiteDatabase);
        addLedScreenLight(sqLiteDatabase);
        addPicTab(sqLiteDatabase);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        Log.e("tiwolf", "onUpgrade: 数据库升级了，旧版本是"+oldVersion+"；新版本是"+newVersion );

        addWorkTime(sqLiteDatabase);
        addSameTime(sqLiteDatabase);
    }

    private void addSameTime(SQLiteDatabase sqLiteDatabase){
        //添加普通广告 真正的文件名称
        String cmd="ALTER TABLE play_list ADD mediaName varchar(50);";
        sqLiteDatabase.execSQL(cmd);
    }


    /**
     * 这个表主要是sdcard上传记录失败的时候，作为缓存。待有网络或者是重启的时候再重新上传
     * @param sqLiteDatabase
     */
    private void addUpdateRecord(SQLiteDatabase sqLiteDatabase){
        StringBuffer vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table if not exists update_record(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("rccontent varchar(200),");             //记录内容
        vStringBuffer.append("updateType int,");                     //内容的类型，例如1表示（目前还没用到），2表示向服务器告知本地已经删除mp4记录，8表示通知服务器增加普通录制记录，9表示通知服务器增加报警记录
        vStringBuffer.append("updateFlag int,");                     //待用
        vStringBuffer.append("updateMsg varchar(50),");              //待用
        vStringBuffer.append("updateMg varchar(20),");               //待用
        vStringBuffer.append("dotime varchar(20))");                //时间戳
        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);
    }

    /**
     * 这个表主要是一个直播列表
     * @param sqLiteDatabase
     */
    private void addLiveTab(SQLiteDatabase sqLiteDatabase){
        StringBuffer vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table if not exists live_tab(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("liveContent varchar(400),");              //直播url
        vStringBuffer.append("alarmId int,");                           //闹钟id
        vStringBuffer.append("volume int,");                            //音量大小
        vStringBuffer.append("startTime varchar(30),");                 //开始时间段
        vStringBuffer.append("endTime varchar(30),");                   //结束时间段
        vStringBuffer.append("startDay varchar(30),");                  //开始日期
        vStringBuffer.append("endDay varchar(30),");                    //结束日期
        vStringBuffer.append("flag int,");                              //是否可用
        vStringBuffer.append("alarm1 int,");                            //闹钟直接操作
        vStringBuffer.append("alarm2 int,");                            //闹钟直接操作2
        vStringBuffer.append("item1 varchar(30),");                     //备用1
        vStringBuffer.append("item2 varchar(30),");                     //备用2
        vStringBuffer.append("item3 int,");                             //备用3
        vStringBuffer.append("item4 int,");                             //备用4
        vStringBuffer.append("dotime varchar(20))");                    //下发时间戳
        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);
    }

    /**
     * 这个表主要是用来存储电量值 存储每天的电表数据，一个小时左右存储一次数据吧,然后每天的数据进行更新。最后每天保存一条数据
     * @param sqLiteDatabase
     */
    private void addAmmeterTab(SQLiteDatabase sqLiteDatabase){
        StringBuffer vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table if not exists ammeter_tab(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("electricity varchar(30),");               //总电量
        vStringBuffer.append("voltage varchar(30),");                   //电压
        vStringBuffer.append("current varchar(30),");                   //电流
        vStringBuffer.append("fre varchar(30),");                       //频率
        vStringBuffer.append("update varchar(30),");                    //更新时间（读取时间）
        vStringBuffer.append("item1 varchar(30),");                     //备用1
        vStringBuffer.append("item2 varchar(30),");                     //备用2
        vStringBuffer.append("item3 varchar(30),");                     //备用3
        vStringBuffer.append("item4 varchar(30),");                     //备用4
        vStringBuffer.append("item5 varchar(30),");                     //备用5
        vStringBuffer.append("item6 varchar(30)");                      //备用6
        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);
    }

    /**
     * 多时段开息屏时间
     * @param sqLiteDatabase
     */
    private void addScreenTab(SQLiteDatabase sqLiteDatabase){
        StringBuffer vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table if not exists screen_tab(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("timedo varchar(30),");                    //开屏 息屏的时间
//        vStringBuffer.append("end varchar(30),");                     //结束息屏
        vStringBuffer.append("timeInt int,");                          //开屏，息屏换算成的值，用来比较大小
//        vStringBuffer.append("endInt int,");                            //结束息屏换数字
        vStringBuffer.append("switchflag int,");                        //开屏，息屏的辨别  0为息屏，1为开屏
        vStringBuffer.append("item1 varchar(30),");                     //备用1
        vStringBuffer.append("item2 varchar(30),");                     //备用1
        vStringBuffer.append("item3 varchar(30),");                     //备用1
        vStringBuffer.append("item4 varchar(30),");                     //备用1
        vStringBuffer.append("item5 int,");                             //备用5
        vStringBuffer.append("item6 int)");                              //备用6
        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);
    }

    private void addLedScreenLight(SQLiteDatabase sqLiteDatabase){
        StringBuffer vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table if not exists ledscreen_tab(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("timedo varchar(30),");                    //屏幕亮度切换的时间
        vStringBuffer.append("timeInt int,");                          //屏幕亮度换算成的值，用来比较大小
        vStringBuffer.append("screenlight int,");                          //屏幕亮度值
        vStringBuffer.append("item1 varchar(30),");                     //备用1
        vStringBuffer.append("item2 varchar(30),");                     //备用1
        vStringBuffer.append("item3 varchar(30),");                     //备用1
        vStringBuffer.append("item4 varchar(30),");                     //备用1
        vStringBuffer.append("item5 int,");                             //备用5
        vStringBuffer.append("item6 int)");                              //备用6
        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);
    }


    /**
     * 添加图片记录表格
     * @param sqLiteDatabase
     */
    private void addPicTab(SQLiteDatabase sqLiteDatabase){
        StringBuffer vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table if not exists picrecord_tab(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("filename varchar(30),");                    //文件名称 20230531091641.jpg
        vStringBuffer.append("ext varchar(10),");                       //文件的拓展名
        vStringBuffer.append("name varchar(30) unique,");               //文件名 约束唯一标识数据表中的每条记录 避免出现两条一样的数据
        vStringBuffer.append("filePath varchar(150),");                 //文件路径  后面取出来之后如果没有，需要将相关记录清除
        vStringBuffer.append("item3 varchar(30),");                     //备用1
        vStringBuffer.append("item4 varchar(30),");                     //备用2
        vStringBuffer.append("item5 int,");                             //备用3
        vStringBuffer.append("item6 int,");                              //备用4
        vStringBuffer.append("date timestamp not null default (datetime('now','localtime')))");//添加日期 其中date是日期
        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);
    }

    /**
     * 添加设备工作的时间段  输入日期先判断当前是否已经设置时间段，如果有则拿出时间段进行定时。如果没有再输入星期几去判断当前是否已经设置时间段，如果有则拿出对应的时间段进行定时。没有则在星期几表头这输入“100”去获取时间段，这个为平常的时间段
     * @param sqLiteDatabase  主要是数据库保存问题如何解决
     */
    private void addWorkTime(SQLiteDatabase sqLiteDatabase){
        StringBuffer vStringBuffer=new StringBuffer();
        vStringBuffer.append("Create table if not exists dogboxwork_tab(");
        vStringBuffer.append("AutoID integer primary key autoincrement,");
        vStringBuffer.append("date varchar(20),");                      //日期
        vStringBuffer.append("week varchar(50) unique,");               //星期几
        vStringBuffer.append("time varchar(10),");                      //时间
        vStringBuffer.append("timeInt int,");                           //时间大小，用来对比
        vStringBuffer.append("flag varchar(5),");                       //开始，结束标志
        vStringBuffer.append("item1 varchar(30),");                     //备用1
        vStringBuffer.append("item2 int,");                             //备用2
        vStringBuffer.append("item3 int)");                             //备用3
        String sSQL=vStringBuffer.toString();
        sqLiteDatabase.execSQL(sSQL);
    }
}
