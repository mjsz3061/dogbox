package com.ytf.dogbox.util;

/**
 * @author tiwolf_li
 * @Date on 2020/6/24
 * @Description
 */
public class UploadConfig {

    public static String chunkSize="chunkSize";
    public static String index="index";
    public static String md5="md5";
    public static String owner="owner";
    public static String endUser="endUser";
    public static String experies="experies";
    public static String chunkIndex="chunkIndex";
    public static String chunkNumber="chunkNumber";
    public static String ext="ext";
    public static String file="file";
    public static String lastModifiedTime="lastModifiedTime";
    public static String originName="originName";
    public static String filePath="filePath";
    public static String size="size";
    public static String devicelig="DEVICELIG";
    public static String upstate="upstate";
    public static String fileName="filename";
    public static String name="name";

    public static String APPLICANT="applicant";
    public static String APPLYPVERSION="applyPversion";
    public static String SYSTEMVERSION="relyPversion";
    public static String IDENTIFY="identify";
    public static String QUERYTIME="queryTime";
    public static String SIGN="sign";

    public static String PVERSION="pversion";
    public static String PRIFILE="priFile";//是否是私有

    public static String ATTACH="attach";//是否以文件形式保存
    public static String EXPERIES="experies";//过期时间

    public static String UPDATETIME="time";
    public static String sn="sn";
    public static String type="type";
}
