package com.ytf.dogbox.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;

import java.util.List;

/**
 * author:tiwolf
 * create date:2021/12/13
 * Describe:
 */
public class WifiUtil {

    static int NO_PASS=0;
    static int WPA_PSK=1;
    static int WPA2_PSK=2;
    private static WifiManager mWifiManager;

    public static WifiManager initWifiManager(Context mContext){
        if (mWifiManager==null){
            mWifiManager=(WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
        }
        return mWifiManager;
    }

    public static boolean connectwifi(WifiManager mWifiManager, String mSSID, String mPasswd, int Type) {

        try {
            Log.e("tiwolf", "connectwifi: 账号="+mSSID+";密码="+mPasswd+";类型="+Type);
            //WifiAdmin wa = new WifiAdmin(mContext);
            //wa.addNetwork(wa.CreateWifiInfo(mSSID, mPasswd, Type));
//            WifiManager mWifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
            WifiConfiguration config = new WifiConfiguration();
            config.allowedAuthAlgorithms.clear();
            config.allowedGroupCiphers.clear();
            config.allowedKeyManagement.clear();
            config.allowedPairwiseCiphers.clear();
            config.allowedProtocols.clear();
            config.SSID = "\"" + mSSID + "\"";

            WifiConfiguration tempConfig = IsExsits(mSSID,mWifiManager);
            if (tempConfig != null) {
                mWifiManager.removeNetwork(tempConfig.networkId);
            }

            switch (Type) {
                case 0: {
                    //WifiSecurityType.WIFICIPHER_NOPASS
                    config.wepKeys[0] = "";
                    config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
                    config.wepTxKeyIndex = 0;
                    Log.e("tiwolf", "connectwifi: 连接WiFi,没密码");
                    break;
                }
                case 1:  {
                    //WifiSecurityType.WIFICIPHER_WPA
//                    config.hiddenSSID = true;
                    config.wepKeys[0] = "\"" + mPasswd + "\"";
                    config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.SHARED);
                    config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
                    config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
                    config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
                    config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
                    config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
                    config.wepTxKeyIndex = 0;
                    Log.e("tiwolf", "connectwifi: 连接WiFi,wpa");
                    break;
                }
                case 2:  {
                    //WifiSecurityType.WIFICIPHER_WPA2
                    config.preSharedKey = "\"" + mPasswd + "\"";
//                    config.hiddenSSID = true;
                    config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
                    config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
                    config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
                    config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
                    //config.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
                    config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
                    config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
                    config.status = WifiConfiguration.Status.ENABLED;
                    Log.e("tiwolf", "connectwifi: 连接WiFi,wpa2_psk");
                    break;
                }
                default:{
                    Log.e("tiwolf", "connectwifi: 连接WiFi,啥都没连上");
                    break;
                }

            }
            int wcgID = mWifiManager.addNetwork(config);
            boolean b = mWifiManager.enableNetwork(wcgID, true);

            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            Log.e("tiwolf", "connectwifi: 连接WiFi错误="+ex.getLocalizedMessage() );
        }
        return false;
    }

    //查看以前是否也配置过这个网络
    private static WifiConfiguration IsExsits(String SSID, WifiManager mWifiManager) {
        @SuppressLint("MissingPermission") List<WifiConfiguration> existingConfigs = mWifiManager.getConfiguredNetworks();
        if (existingConfigs==null)return null;
        Log.e("tiwolf", "IsExsits: wifi是否存在。。。" );
        for (WifiConfiguration existingConfig : existingConfigs) {
            if (existingConfig.SSID.equals("\""+SSID+"\"")){
                return existingConfig;
            }
        }
        return null;
    }

    /**
     * 打开WiFi
     * @param mWifiManager
     * @return
     */
    public synchronized static boolean openwifi(WifiManager mWifiManager) {
        try {
            Log.e("tiwolf", "openwifi: wifiap 当前状态="+mWifiManager.getWifiState() );
            if (mWifiManager.getWifiState()!=WifiManager.WIFI_STATE_ENABLED){
                mWifiManager.setWifiEnabled(true);
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    /**
     * 关闭WiFi
     * @param mWifiManager
     * @return
     */
    public synchronized static boolean closewifi(WifiManager mWifiManager) {

        try {
            Log.e("tiwolf", "closewifi: wifi 当前状态="+mWifiManager.getWifiState() );
            if (mWifiManager.getWifiState()!=WifiManager.WIFI_STATE_DISABLED){
                mWifiManager.setWifiEnabled(false);
                return true;
            }
//            if (mWifiManager.isWifiEnabled()) {
//
//            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

}
