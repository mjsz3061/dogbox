package com.ytf.dogbox.dogHttp;

import static java.lang.Thread.currentThread;

import com.ytf.dogbox.bean.DownloadItem;
import com.ytf.dogbox.db.SqliteManager;
import com.ytf.dogbox.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CountDownLatch;



/**
 * @author tiwolf_li
 * @Date on 2020/6/23
 * @Description  Get方法  主要用来将文件上传到我司的服务器里面
 */
public class QiNiuDownLoadFile implements Runnable {

    public String TAG="tiwolf";

    private OnThreadResultListener listener;//任务线程回调接口
    private DownloadItem downloadItem;
    SqliteManager sqliteManager;
    File file;
    String fileUrl=null;

    CountDownLatch downLatch;

    public static boolean forceFlag=false;


    int mFinished=0;

    private boolean stopFlag=false;
    public void setStop(boolean flag){
        this.stopFlag=flag;
    }

    public QiNiuDownLoadFile(String url, File file, SqliteManager sqliteManager, CountDownLatch downLatch, DownloadItem downloadItem, OnThreadResultListener listener){
        this.fileUrl=url;
        this.downloadItem=downloadItem;
        this.listener=listener;
        this.downLatch=downLatch;
        this.sqliteManager=sqliteManager;
        this.file=file;
    }


    /**
     * 下载标志：1，表示文件未下载（当前未在下载）；2，表示已经下载完成；3，表示文件正在下载（避免多次下载）
     */
    @Override
    public void run() {
        Log.e(TAG, "run66666: "+currentThread().getName() );
//        String urlStr= TestConfig.downloadFile+downloadItem.getDownloadMd5();
        String startLength=downloadItem.getDownloadLength();
        sqliteManager.updateDownloadFlag(3,downloadItem.getDownloadMd5());

        Log.e("startplay", "更新了下载标志；"+downloadItem.getDownloadMd5()+"开始下载文件,进度为："+startLength);
        //这里直接进行数据更新。更新下载进度
        RandomAccessFile raf=null;
        HttpURLConnection con=null;
        InputStream is=null;
        try {
//            Log.e(TAG, "download:4未下载的文件下载开始 "+startLength );
            URL url=new URL(fileUrl);
            con= (HttpURLConnection) url.openConnection();
            con.setReadTimeout(50000);
            con.setConnectTimeout(50000);
            con.setRequestProperty("Accept-Language","zh-CN,zh;q=0.9");
            con.setRequestMethod("POST");
            con.setRequestProperty("RANGE","bytes="+startLength+"-");
//            con.setRequestProperty("connection", "Keep-Alive");
//            con.setRequestProperty("Content-Type","application/json");
            //设置下载位置
            int start=Integer.valueOf(downloadItem.getDownloadLength());
            mFinished=start;
//            con.setRequestProperty("Range", "bytes=" + start + "-" + downloadItem.getDownloadEnd());
            //设置一个文件写入位置
            raf=new RandomAccessFile(file,"rwd");
            //设置文件写入位置
            raf.seek(start);

//            Log.e(TAG, "run: 开始下载文件,当前进度为："+mFinished);
//            Log.e(TAG, downloadItem.getDownloadMd5()+"得到的返回值为"+con.getResponseCode() );

            Log.e(TAG, "run: 七牛云下载="+con.getResponseCode() );
            //开始下载
            if (con.getResponseCode()==HttpURLConnection.HTTP_OK  || con.getResponseCode()==HttpURLConnection.HTTP_PARTIAL){
                //读取数据
                is=con.getInputStream();
                byte[] buffer=new byte[1024*4];
                int len=-1;
                while ((len=is.read(buffer))>0){
                    //写入文件
                    raf.write(buffer,0,len);
                    start+=len;
                    mFinished=start;
                    if (stopFlag){
                        Log.e(TAG, "run: 如果遇到设备格式化，或者其他需要强制退出写入文件情况使用");
                        break;
                    }
//                    Log.e(TAG, downloadItem.getDownloadMd5()+"下载文件进度为+mFinish："+mFinished);
                }

                Log.e(TAG, downloadItem.getDownloadMd5()+"文件已七牛云下载完："+mFinished);
                if (!forceFlag){
                    //正常情况下
                    listener.onDownloadFinish();
                    sqliteManager.updateDownloadLength(""+start,2,downloadItem.getDownloadMd5());
                }else {
                    //如果出现强制停止下载的情况下，则记录一下当前下载的进度
                    listener.downloadFailed();
                    sqliteManager.updateDownloadLength(""+mFinished,1,downloadItem.getDownloadMd5());
                }


            }else {
                //说明数据出错，则应该变回未下载
                sqliteManager.updateDownloadFlag(1,downloadItem.getDownloadMd5());
            }

        } catch (IOException e){
            //如果出现IO error；那么既有可能是tf卡无法写进去
            e.printStackTrace();
            Log.e(TAG, "run: 文件七牛云下载出现io异常"+e.getLocalizedMessage() );
            if("timeout".equals(e.getLocalizedMessage())){
                listener.downloadError(2);
            }else{
                listener.downloadError(1);
            }
            sqliteManager.updateDownloadLength(""+mFinished,1,downloadItem.getDownloadMd5());
        }catch (Exception e) {
            e.printStackTrace();
//            listener.onDownloadInterrupted();
            Log.e(TAG, downloadItem.getDownloadMd5()+"文件七牛云下载异常，mFinish："+mFinished);
            listener.downloadFailed();
            sqliteManager.updateDownloadLength(""+mFinished,1,downloadItem.getDownloadMd5());
        }finally {
//            Log.e(TAG, "已经全部结束："+mFinished);
            try {

                if (raf!=null){
                    raf.close();
                }
                if (is!=null){
                    is.close();
                }
                if (con!=null){
                    con.disconnect();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        downLatch.countDown();
    }
}
