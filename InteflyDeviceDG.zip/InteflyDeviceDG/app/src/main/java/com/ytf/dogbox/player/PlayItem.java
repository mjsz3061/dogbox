package com.ytf.dogbox.player;

public class PlayItem {

    private int downloadId;      //下载的所需id
    private String downloadMd5;     //下载所需md5
    private String playName;        //名称
    private String downloadTotal;   //下载文件总长度
    private int playType;           //文件类型
    private String playExt;         //后缀名
    private int playTime;           //播放长度
    private int alarmId;            //闹钟的id
    private int playIndex;          //播放的顺序
    private int alarm1;             //闹钟操作1
    private int alarm2;             //闹钟操作2
    private String content;         //播放内容
    private String startTime;       //开始的时间
    private String endTime;         //结束的时间
    private int volumn;             //音量值大小
    private String avTime;          //获取时间段播放一次广告的时间
    private String mediaName;       //真正的文件名




    public int getDownloadId() {
        return downloadId;
    }

    public void setDownloadId(int downloadId) {
        this.downloadId = downloadId;
    }

    public String getDownloadMd5() {
        return downloadMd5;
    }

    public void setDownloadMd5(String downloadMd5) {
        this.downloadMd5 = downloadMd5;
    }

    public String getPlayName() {
        return playName;
    }

    public void setPlayName(String playName) {
        this.playName = playName;
    }

    public String getDownloadTotal() {
        return downloadTotal;
    }

    public void setDownloadTotal(String downloadTotal) {
        this.downloadTotal = downloadTotal;
    }

    public int getPlayType() {
        return playType;
    }

    public void setPlayType(int playType) {
        this.playType = playType;
    }

    public String getPlayExt() {
        return playExt;
    }

    public void setPlayExt(String playExt) {
        this.playExt = playExt;
    }

    public int getPlayTime() {
        return playTime;
    }

    public void setPlayTime(int playTime) {
        this.playTime = playTime;
    }

    public int getAlarmId() {
        return alarmId;
    }

    public void setAlarmId(int alarmId) {
        this.alarmId = alarmId;
    }

    public int getPlayIndex() {
        return playIndex;
    }

    public void setPlayIndex(int playIndex) {
        this.playIndex = playIndex;
    }

    public int getAlarm1() {
        return alarm1;
    }

    public void setAlarm1(int alarm1) {
        this.alarm1 = alarm1;
    }

    public int getAlarm2() {
        return alarm2;
    }

    public void setAlarm2(int alarm2) {
        this.alarm2 = alarm2;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public int getVolumn() {
        return volumn;
    }

    public void setVolumn(int volumn) {
        this.volumn = volumn;
    }

    public String getAvTime() {
        return avTime;
    }

    public void setAvTime(String avTime) {
        this.avTime = avTime;
    }

    public String getMediaName() {
        return mediaName;
    }

    public void setMediaName(String mediaName) {
        this.mediaName = mediaName;
    }
}
