package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2022/1/14
 * Describe:  广告列表
 */
public class LiveObjBean<T> {

    private String currentTime;
    private T configMains;


    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public T getConfigMains() {
        return configMains;
    }

    public void setConfigMains(T configMains) {
        this.configMains = configMains;
    }
}
