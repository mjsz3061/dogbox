package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/12/18
 * Describe:
 */
public class DogTonkenBean {

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
