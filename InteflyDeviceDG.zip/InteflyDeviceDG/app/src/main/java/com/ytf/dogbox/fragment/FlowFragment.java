package com.ytf.dogbox.fragment;

import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ytf.dogbox.R;



public class FlowFragment extends Fragment {

    //是否可见
    //是否初始化完成
    public boolean isInit = false;
    //全局的view
    private View view;

    RelativeLayout flowLL1,flowLL2,flowLL3,flowLL4,flowLL5,flowLL6;
    ImageView flowLeftIv1,flowLeftIv2,flowLeftIv3;
    ImageView flowRightIv1,flowRightIv2,flowRightIv3;

    TextView numLeftTv1,numLeftTv2,numLeftTv3;
    TextView numRightTv1,numRightTv2,numRightTv3;

    TextView textLeftTv1,textLeftTv2,textLeftTv3;
    TextView textRightTv1,textRightTv2,textRightTv3;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       //1.创建View视图
        if (view==null){
            view = inflater.inflate(R.layout.fragment_dog_flow,container,false);

            isInit=true;
            setParam();
        }

        //2.返回view视图
        return  view ;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e("TAG", "onResume: Fragment1-显示数据" );
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e("TAG", "onDestroyView: Fragment1-停止显示" );
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("TAG", "onDestroy: Fragment1-销毁控件" );
    }

    //处理逻辑和网络请求等
    private void setParam() {
        if (isInit && flowLeftIv1==null) {
            flowLL1=view.findViewById(R.id.dog_flow_left_one_rl);
            flowLL2=view.findViewById(R.id.dog_flow_right_one_rl);
            flowLL3=view.findViewById(R.id.dog_flow_left_two_rl);
            flowLL4=view.findViewById(R.id.dog_flow_right_two_rl);
            flowLL5=view.findViewById(R.id.dog_flow_left_three_rl);
            flowLL6=view.findViewById(R.id.dog_flow_right_three_rl);

            flowLeftIv1=view.findViewById(R.id.flow_left_1_iv);
            flowLeftIv2=view.findViewById(R.id.flow_left_2_iv);
            flowLeftIv3=view.findViewById(R.id.flow_left_3_iv);
            flowRightIv1=view.findViewById(R.id.flow_right_1_iv);
            flowRightIv2=view.findViewById(R.id.flow_right_2_iv);
            flowRightIv3=view.findViewById(R.id.flow_right_3_iv);

            numLeftTv1=view.findViewById(R.id.flow_left_1_tv1);
            numLeftTv2=view.findViewById(R.id.flow_left_2_tv1);
            numLeftTv3=view.findViewById(R.id.flow_left_3_tv1);
            numRightTv1=view.findViewById(R.id.flow_right_1_tv1);
            numRightTv2=view.findViewById(R.id.flow_right_2_tv1);
            numRightTv3=view.findViewById(R.id.flow_right_3_tv1);

            textLeftTv1=view.findViewById(R.id.flow_left_1_tv2);
            textLeftTv2=view.findViewById(R.id.flow_left_2_tv2);
            textLeftTv3=view.findViewById(R.id.flow_left_3_tv2);
            textRightTv1=view.findViewById(R.id.flow_right_1_tv2);
            textRightTv2=view.findViewById(R.id.flow_right_2_tv2);
            textRightTv3=view.findViewById(R.id.flow_right_3_tv2);
            Log.e("tiwolf", "onCreateView: Fragment1-创建ui" );
        }
    }

    public void setFlowShow(int stage){
        Log.e("TAG", "handleMessage: 进入设置流程值0000000="+stage );
        if (flowRightIv1==null){
            Log.e("TAG", "handleMessage: 进入设置流程值1111" );
            return;
        }
        if (stage==3){
            flowLeftIv1.setEnabled(true);
            flowLeftIv2.setEnabled(false);
            flowLeftIv3.setEnabled(false);
            flowRightIv1.setEnabled(false);
            flowRightIv2.setEnabled(false);
            flowRightIv3.setEnabled(false);

            numLeftTv1.setEnabled(true);
            numLeftTv2.setEnabled(false);
            numLeftTv3.setEnabled(false);
            numRightTv1.setEnabled(false);
            numRightTv2.setEnabled(false);
            numRightTv3.setEnabled(false);

            textLeftTv1.setEnabled(true);
            textLeftTv2.setEnabled(false);
            textLeftTv3.setEnabled(false);
            textRightTv1.setEnabled(false);
            textRightTv2.setEnabled(false);
            textRightTv3.setEnabled(false);
            startFlick(flowLL1);
        }else if (stage==5){
            stopFlick(flowLL2);
            flowLeftIv1.setEnabled(false);
            flowLeftIv2.setEnabled(true);
            flowLeftIv3.setEnabled(false);
            flowRightIv1.setEnabled(false);
            flowRightIv2.setEnabled(false);
            flowRightIv3.setEnabled(false);

            numLeftTv1.setEnabled(false);
            numLeftTv2.setEnabled(true);
            numLeftTv3.setEnabled(false);
            numRightTv1.setEnabled(false);
            numRightTv2.setEnabled(false);
            numRightTv3.setEnabled(false);

            textLeftTv1.setEnabled(false);
            textLeftTv2.setEnabled(true);
            textLeftTv3.setEnabled(false);
            textRightTv1.setEnabled(false);
            textRightTv2.setEnabled(false);
            textRightTv3.setEnabled(false);
            startFlick(flowLL3);
        }else if (stage==7){
            stopFlick(flowLL4);
            flowLeftIv1.setEnabled(false);
            flowLeftIv2.setEnabled(false);
            flowLeftIv3.setEnabled(true);
            flowRightIv1.setEnabled(false);
            flowRightIv2.setEnabled(false);
            flowRightIv3.setEnabled(false);

            numLeftTv1.setEnabled(false);
            numLeftTv2.setEnabled(false);
            numLeftTv3.setEnabled(true);
            numRightTv1.setEnabled(false);
            numRightTv2.setEnabled(false);
            numRightTv3.setEnabled(false);

            textLeftTv1.setEnabled(false);
            textLeftTv2.setEnabled(false);
            textLeftTv3.setEnabled(true);
            textRightTv1.setEnabled(false);
            textRightTv2.setEnabled(false);
            textRightTv3.setEnabled(false);
            startFlick(flowLL5);
        }else if (stage==4){
            stopFlick(flowLL1);
            flowLeftIv1.setEnabled(false);
            flowLeftIv2.setEnabled(false);
            flowLeftIv3.setEnabled(false);
            flowRightIv1.setEnabled(true);
            flowRightIv2.setEnabled(false);
            flowRightIv3.setEnabled(false);

            numLeftTv1.setEnabled(false);
            numLeftTv2.setEnabled(false);
            numLeftTv3.setEnabled(false);
            numRightTv1.setEnabled(true);
            numRightTv2.setEnabled(false);
            numRightTv3.setEnabled(false);

            textLeftTv1.setEnabled(false);
            textLeftTv2.setEnabled(false);
            textLeftTv3.setEnabled(false);
            textRightTv1.setEnabled(true);
            textRightTv2.setEnabled(false);
            textRightTv3.setEnabled(false);
            startFlick(flowLL2);
        }else if (stage==6){
            stopFlick(flowLL3);
            flowLeftIv1.setEnabled(false);
            flowLeftIv2.setEnabled(false);
            flowLeftIv3.setEnabled(false);
            flowRightIv1.setEnabled(false);
            flowRightIv2.setEnabled(true);
            flowRightIv3.setEnabled(false);

            numLeftTv1.setEnabled(false);
            numLeftTv2.setEnabled(false);
            numLeftTv3.setEnabled(false);
            numRightTv1.setEnabled(false);
            numRightTv2.setEnabled(true);
            numRightTv3.setEnabled(false);

            textLeftTv1.setEnabled(false);
            textLeftTv2.setEnabled(false);
            textLeftTv3.setEnabled(false);
            textRightTv1.setEnabled(false);
            textRightTv2.setEnabled(true);
            textRightTv3.setEnabled(false);
            startFlick(flowLL4);
        }else if (stage==8){
            stopFlick(flowLL5);
            flowLeftIv1.setEnabled(false);
            flowLeftIv2.setEnabled(false);
            flowLeftIv3.setEnabled(false);
            flowRightIv1.setEnabled(false);
            flowRightIv2.setEnabled(false);
            flowRightIv3.setEnabled(true);

            numLeftTv1.setEnabled(false);
            numLeftTv2.setEnabled(false);
            numLeftTv3.setEnabled(false);
            numRightTv1.setEnabled(false);
            numRightTv2.setEnabled(false);
            numRightTv3.setEnabled(true);

            textLeftTv1.setEnabled(false);
            textLeftTv2.setEnabled(false);
            textLeftTv3.setEnabled(false);
            textRightTv1.setEnabled(false);
            textRightTv2.setEnabled(false);
            textRightTv3.setEnabled(true);
            startFlick(flowLL6);
        }

    }

    public void clearFlick(int num){
        if (num==3){
            stopFlick(flowLL1);
        }else if (num==4){
            stopFlick(flowLL2);
        } else if (num==5) {
            stopFlick(flowLL3);
        } else if (num==6) {
            stopFlick(flowLL4);
        } else if (num==7) {
            stopFlick(flowLL5);
        } else if (num==8) {
            stopFlick(flowLL6);
        }
    }

    /**
     * 开启View闪烁效果
     *
     * */
    private void startFlick( View view ){
        if( null == view ){
            return;
        }
        Animation alphaAnimation = new AlphaAnimation( 1, 0.7f );
        alphaAnimation.setDuration( 600 );
        alphaAnimation.setInterpolator( new LinearInterpolator( ) );
        alphaAnimation.setRepeatCount( Animation.INFINITE );
        alphaAnimation.setRepeatMode( Animation.REVERSE );
        view.startAnimation( alphaAnimation );
    }

    /**
     * 取消View闪烁效果
     *
     * */
    private void stopFlick( View view ){
        if( null == view ){
            return;
        }
        view.clearAnimation( );
    }



}
