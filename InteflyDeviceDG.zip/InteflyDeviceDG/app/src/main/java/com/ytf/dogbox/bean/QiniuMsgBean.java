package com.ytf.dogbox.bean;

/**
 * @author tiwolf_li
 * @Date on 2020/6/23
 * @Description
 */
public class QiniuMsgBean {
    private String code;
    private QiniuBean data;
    private String dataFlag;
    private String msg;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public QiniuBean getData() {
        return data;
    }

    public void setData(QiniuBean data) {
        this.data = data;
    }

    public String getDataFlag() {
        return dataFlag;
    }

    public void setDataFlag(String dataFlag) {
        this.dataFlag = dataFlag;
    }

}
