package com.ytf.dogbox.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ytf.dogbox.db.SqliteManager;
import com.ytf.dogbox.listener.ICameraListener;



/**
 * @author tiwolf_li
 * @Date on 2021/8/17
 * @Description  摄像头的父控件
 */
public abstract class CameraFragment extends Fragment {

    //直接从activity获取语言，屏幕

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public abstract void startRecordMp4();

    public abstract void setDrawHelper();

    public abstract void setNetworkFlag(boolean isOnNetWork);

    public abstract void setFaceDistinguish(String mode);

    public abstract void setFragmentParams(SqliteManager sqliteManager);

    public abstract void stopRtmpPublisher(String url);

    public abstract void setPolicePictureFlag(boolean policePictureFlag,boolean isPeopleDo);

    public abstract void createQiniuRoom();

    public abstract void stopRtmpStream();

    public abstract void destroyCamera();

    public abstract int rebootCamera(int code,String user,String passwd,String ip);

    public abstract void endRecord();

    public abstract int startQiPlayBack(String path,String url);

    public abstract int isEnd(int handle);

    public abstract int stopPlayBack(String path,int handle);

    public abstract void restartAudio();

    public abstract void stopRecord();

    public abstract void startRtmpPublisher(boolean stopRtmpFlag);

    public abstract void startRtmpPublisher(boolean stopRtmpFlag,String url);

    public abstract void stopRtmpPublish();

    public abstract void setCameraListener(ICameraListener listener);

    //这个用于我司的摄像头
    public abstract void setCameraOperation(String order,int itfi,String usrname,String pwd,String ip);

    //这个用于海康摄像头
    public abstract void setCameraOperation(String order);

    //2022.5.10 当前适用于我司摄像头
    public abstract void setCameraMode(int mode);

    //2022.5.31 当前使用我司摄像头  手动聚焦
    public abstract int prePoint(int code,String user,String passwd,String ip);

    //2022.6.13 当前适用我司摄像头 设置第三码流参数
    public abstract int setThirdStreamParam(int code,String user,String passwd,String ip);

    //2022.6.13 当前适用我司摄像头 获取第三码流参数
    public abstract int getThirdStreamParam(int code,String user,String passwd,String ip);

}
