package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2022/2/22
 * Describe:
 */
public class ScreenAlarmBean {

    private String timeStr;
    private int timeInt;
    private int switchFlag;
    private boolean istomorrowflag;


    public String getTimeStr() {
        return timeStr;
    }

    public void setTimeStr(String timeStr) {
        this.timeStr = timeStr;
    }

    public int getTimeInt() {
        return timeInt;
    }

    public void setTimeInt(int timeInt) {
        this.timeInt = timeInt;
    }

    public int getSwitchFlag() {
        return switchFlag;
    }

    public void setSwitchFlag(int switchFlag) {
        this.switchFlag = switchFlag;
    }

    public boolean isIstomorrowflag() {
        return istomorrowflag;
    }

    public void setIstomorrowflag(boolean istomorrowflag) {
        this.istomorrowflag = istomorrowflag;
    }
}
