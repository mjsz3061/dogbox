package com.ytf.dogbox.util;

/**
 * author:tiwolf
 * create date:2023/11/2
 * Describe:  洗澡过程
 */
public class BathProgressUtil {

    //洗狗流程
    public static void bathDog(){



    }

}
