package com.ytf.dogbox.base;


import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;

import com.uber.autodispose.AutoDispose;
import com.uber.autodispose.AutoDisposeConverter;
import com.uber.autodispose.android.lifecycle.AndroidLifecycleScopeProvider;
import com.ytf.dogbox.base.presenter.BasePresenter;
import com.ytf.dogbox.base.view.BaseView;
import com.ytf.dogbox.util.Log;


public abstract class BaseOneActivity<T extends BasePresenter> extends AppCompatActivity implements BaseView {
    protected AppCompatActivity activity;

    protected T mPresenter;

    private boolean isDo=true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        //TODO 使用程序的严格模式来尽快找出泄漏的内存问题
//        if(BuildConfig.DEBUG){
//            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
//                    .detectLeakedSqlLiteObjects()
//                    .detectLeakedClosableObjects()
//                    .penaltyLog()
//                    .penaltyDeath()
//                    .build()
//            );
//        }
        super.onCreate(savedInstanceState);
//        if (!this.isTaskRoot() && getIntent() != null) {
//            String action = getIntent().getAction();
//            if (getIntent().hasCategory(Intent.CATEGORY_LAUNCHER) && Intent.ACTION_MAIN.equals(action)) {
//                finish();
//                return;
//            }
//        } else {
////            setContentView(R.layout.activity_welcome);
////            goMainActivity();
//
//        }
        long start=System.currentTimeMillis();
        getWindow().setBackgroundDrawable(null);
        if (isDo){
            isDo=false;
            activity = this;
            setContentView(getLayout());
            Log.e("tiwolf", "onCreate: 1111初始化所需时间="+(System.currentTimeMillis()-start) );
            initView(savedInstanceState);
            Log.e("tiwolf", "onCreate: 22222初始化所需时间="+(System.currentTimeMillis()-start) );
            initData();
            Log.e("tiwolf", "onCreate: 33333初始化所需时间="+(System.currentTimeMillis()-start) );
            setListener();
            Log.e("tiwolf", "onCreate: 进入4444初始化所需时间="+(System.currentTimeMillis()-start) );

        }

    }

    //TODO 解决VideoView内存泄漏问题
    @Override
    protected void attachBaseContext(Context newBase)
    {
        super.attachBaseContext(new ContextWrapper(newBase)
        {
            @Override
            public Object getSystemService(String name)
            {
                if (Context.AUDIO_SERVICE.equals(name))
                    return getApplicationContext().getSystemService(name);

                return super.getSystemService(name);
            }
        });
    }


    @Override
    public void initData() {

    }

    @Override
    public void setListener() {

    }


    @Override
    protected void onDestroy() {
        if (mPresenter!=null){
            mPresenter.detachView();
        }
        super.onDestroy();
    }

    /**
     * 绑定生命周期 防止MVP内存泄漏
     *
     * @param <T>
     * @return
     */
    @Override
    public <T> AutoDisposeConverter<T> bindAutoDispose() {
        return AutoDispose.autoDisposable(AndroidLifecycleScopeProvider
                .from(this, Lifecycle.Event.ON_DESTROY));
    }
}
