package com.ytf.dogbox.fragment;

import android.graphics.Outline;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ytf.dogbox.R;
import com.ytf.dogbox.view.LedFirewormsView;


public class MusicFragment extends Fragment {

    //是否可见
    private boolean isVisibleToUser;
    //是否初始化完成
    public boolean isInit = false;
    //全局的view
    private View view;


    private LedFirewormsView ledFirewormsView;

//    private ImageView gifIv;

    private String screen="00";

    /*
     * 当前页面可见时和不可见的方法
     * */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        this.isVisibleToUser = isVisibleToUser;
        setParam();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //1.创建View视图
        Log.e("TAG", "MusicFragment: 初始化--音乐控件布局"+view );
        if (view==null){
            view=inflater.inflate(R.layout.fragment_ol_music,container,false);
            isInit=true;
            setParam();
        }
        return  view;
    }

    @Override
    public void onResume() {
        super.onResume();

        Log.e("TAG", "onResume: MusicFragment-显示数据" );
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.e("TAG", "onResume: MusicFragment-控件可见的时候" );

    }

    @Override
    public void onStop() {
        super.onStop();
        Log.e("TAG", "MusicFragment: 控件停止的时候" );
        stopFly();
    }

    public void setFly(){
        if (ledFirewormsView!=null){
            Log.e("TAG", "onDestroyView: MusicFragment-开始雪花飞" );
            ledFirewormsView.startFly();
        }
//        Glide.with(context)
//                .asGif()
//                .load(R.mipmap.meihua)
//                .into(gifIv);
    }

    public void stopFly(){
        if (ledFirewormsView!=null){
            Log.e("TAG", "onDestroyView: MusicFragment-停止雪花飞" );
            ledFirewormsView.cancelValueAnim();
        }
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e("TAG", "onDestroyView: MusicFragment-停止显示" );
    }

    @Override
    public void onDestroy() {
        if (ledFirewormsView!=null){
            Log.e("TAG", "onDestroy: MusicFragment-销毁控件" );
            ledFirewormsView.cancelValueAnim();
        }
        super.onDestroy();

    }

    //处理逻辑和网络请求等
    private void setParam() {
        if (isInit && isVisibleToUser && ledFirewormsView==null) {
            ledFirewormsView=view.findViewById(R.id.firewormsView);
//            gifIv=view.findViewById(R.id.gifimage);
            Log.e("tiwolf", "onCreateView: MusicFragment-创建ui" );
            setSurfaceviewCorner(20);
        }
    }
    /**
     * 设置Surfaceviewl圆角
     */
    private void setSurfaceviewCorner(final float radius) {
        ledFirewormsView.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                Rect rect = new Rect();
                view.getGlobalVisibleRect(rect);
                int leftMargin = 0;
                int topMargin = 0;
                Rect selfRect = new Rect(leftMargin, topMargin, rect.right - rect.left - leftMargin, rect.bottom - rect.top - topMargin);
                outline.setRoundRect(selfRect, radius);
            }
        });
        ledFirewormsView.setClipToOutline(true);
    }
}