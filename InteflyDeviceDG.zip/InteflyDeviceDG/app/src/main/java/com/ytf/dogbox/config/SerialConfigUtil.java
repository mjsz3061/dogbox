package com.ytf.dogbox.config;

/**
 * author:tiwolf
 * create date:2023/11/24
 * Describe: 2024.2.27 添加了新的一些洗狗机协议
 */
public class SerialConfigUtil {

    //获取洗狗机状态指令
    public static final String CONFIGDOGBOXSTATUS="010300000006C5C8";
    //这个是新协议下的洗狗机指令值
    public static final String CONFIGDOGBOXSTATUS2="0103000000158405";
    //洗狗机开门
    public static final String CONFIGDOGBOXOPENDOOR="0106000100A119B2";//stage==1 开门
    public static final String CONFIGDOGBOXOPENDOOR1="0106000100A259B3";//stage==9 开门
    public static final String CONFIGDOGBOXOPENDOOR2="0106000100AA5875";//异常 开门
    //洗狗机关门
    public static final String CONFIGDOGBOXCLOSEDOOR="0106000100B1187E";//stage==1 关门
    public static final String CONFIGDOGBOXCLOSEDOOR1="0106000100B2587F";//stage==9 关门
    public static final String CONFIGDOGBOXCLOSEDOOR2="0106000100BB9879";//异常 关门
    //洗狗机开水阀
    public static final String CONFIGDOGBOXWATEROPEN="0106000200AAA875";
    //洗狗机关水阀
    public static final String CONFIGDOGBOXWATERCLOSE="0106000200BB6879";
    //水箱加热开
    public static final String CONFIGDOGBOXWATERHEATINGOPEN="0106000300AAF9B5";
    //水箱加热关
    public static final String CONFIGDOGBOXWATERHEATINGCLOSE="0106000300BB39B9";
    //高压水泵阀门开
    public static final String CONFIGDOGBOXWATERPUMPOPEN="0106000800AA8877";
    //高压水泵阀门关
    public static final String CONFIGDOGBOXWATERPUMPCLOSE="0106000800BB487B";
    //沐浴露阀门开
    public static final String CONFIGDOGBOXWASHOPEN="0106000400AA4874";
    //沐浴露阀门关
    public static final String CONFIGDOGBOXWASHCLOSE="0106000400BB8878";
    //浓缩液泵阀门开
    public static final String CONFIGDOGBOXCONCENTRATEDOPEN="0106000700AAB874";
    //浓缩液泵阀门关
    public static final String CONFIGDOGBOXCONCENTRATEDCLOSE="0106000700BB7878";
    //护毛素泵阀门开
    public static final String CONFIGDOGBOXCONDITIONEROPEN="0106000500AA19B4";
    //护毛素泵阀门关
    public static final String CONFIGDOGBOXCONDITIONERCLOSE="0106000500BBD9B8";
    //风机加热条开
    public static final String CONFIGDOGBOXHEATINGOPEN="0106000A00AA29B7";
    //风机加热条关
    public static final String CONFIGDOGBOXHEATINGCLOSE="0106000A00BBE9BB";
    //风机加热条开
    public static final String CONFIGDOGBOXHEATINGOPEN2="0106002A00AA287D";
    //风机加热条关
    public static final String CONFIGDOGBOXHEATINGCLOSE2="0106002A00BBE871";
    //风机加热条开
    public static final String CONFIGDOGBOXHEATINGOPEN3="0106003A00AA29B8";
    //风机加热条关
    public static final String CONFIGDOGBOXHEATINGCLOSE3="0106003A00BBE9B4";
    //吹风机开
    public static final String CONFIGDOGBOXHAIRDRYEROPEN="0106000900AAD9B7";
    //吹风机关
    public static final String CONFIGDOGBOXHAIRDRYERCLOSE="0106000900BB19BB";
    //吹风机2开
    public static final String CONFIGDOGBOXHAIRDRYEROPEN2="0106002900AAD87D";
    //吹风机2关
    public static final String CONFIGDOGBOXHAIRDRYERCLOSE2="0106002900BB1871";
    //吹风机2开
    public static final String CONFIGDOGBOXHAIRDRYEROPEN3="0106003900AAD9B8";
    //吹风机2关
    public static final String CONFIGDOGBOXHAIRDRYERCLOSE3="0106003900BB19B4";
    //消毒液开
    public static final String CONFIGDOGBOXDISINFECTANTOPEN="0106000600AAE9B4";
    //消毒液关
    public static final String CONFIGDOGBOXDISINFECTANTCLOSE="0106000600BB29B8";
    //内照明开
    public static final String CONFIGDOGBOXLIGHTOPEN="0106000C00AAC9B6";
    //内照明关
    public static final String CONFIGDOGBOXLIGHTCLOSE="0106000C00BB09BA";
    //紫外线 开
    public String CONFIGDOGBOXOUTLIGHTOPEN="0106000B00AA7877";
    //紫外线 关
    public String CONFIGDOGBOXOUTLIGHTCLOSE="0106000B00BBB87B";
    //换气风机开
    public static final String SendHex25="0106000D00AA9876";
    //换气风机关
    public static final String SendHex26="0106000D00BB587A";
}
