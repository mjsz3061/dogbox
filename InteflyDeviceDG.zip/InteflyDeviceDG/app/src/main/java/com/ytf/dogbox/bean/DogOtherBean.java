package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/12/14
 * Describe:
 */
public class DogOtherBean {


    private String adminPhone;
    private int id;
    private double lowTemp;
    private double stopHighTemp;
    private double downTemp;
    private double upTemp;

    public String getAdminPhone() {
        return adminPhone;
    }

    public void setAdminPhone(String adminPhone) {
        this.adminPhone = adminPhone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getLowTemp() {
        return lowTemp;
    }

    public void setLowTemp(double lowTemp) {
        this.lowTemp = lowTemp;
    }

    public double getStopHighTemp() {
        return stopHighTemp;
    }

    public void setStopHighTemp(double stopHighTemp) {
        this.stopHighTemp = stopHighTemp;
    }

    public double getDownTemp() {
        return downTemp;
    }

    public void setDownTemp(double downTemp) {
        this.downTemp = downTemp;
    }

    public double getUpTemp() {
        return upTemp;
    }

    public void setUpTemp(double upTemp) {
        this.upTemp = upTemp;
    }
}
