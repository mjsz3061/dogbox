package com.ytf.dogbox.activity;

import android.app.intefly.InteflySmartApi;
import android.app.intefly.rk3568;
import android.content.Context;
import android.util.Log;

/**
 * author:tiwolf
 * create date:2022/3/25
 * Describe:
 *
 */
public class FlyUtil {

    public static String bigBoard3568="PCB-A21061-00";//大板子
    public static String smallBoard3568="PCB-3568-220520-00";//小板子

    static InteflySmartApi api;
    static String mechineModel;

    public static InteflySmartApi initInot(Context context){
        if (api==null){
           api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        return api;
    }

    public static String getSn(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
       return api.getSerialno();
    }

    public static void lanSoftAp(Context context,int type){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        Log.e("TAG", "LanSoftAp: 开启软路由=="+type );
        api.softap(type);
    }

    /**
     * 获取设备型号，来判断当前使用的硬件接口
     * @param context
     * @return
     */
    public static String getMeChineModel(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        mechineModel=api.getHardwareVersion();
        return api.getHardwareVersion();
    }

    /**
     * 获取api版本
     * @param context
     * @return
     */
    public static String getApiVersion(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        return api.getApiVersion();
    }

    /**
     * 重启设备
     * @param context
     */
    public static void rebootMechine(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("reboot");
    }

    /**
     * 打开屏幕
     * @param context
     */
    public static void openScreen(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.setGpioState(rk3568.RK30_PIN0_PC3,1);//打开主屏屏供电
        api.setGpioState(rk3568.RK30_PIN0_PC2,1);//打开副屏屏供电
        api.setGpioState(rk3568.RK30_PIN3_PA4,1);//打开主屏屏背光
        api.setGpioState(rk3568.RK30_PIN3_PA3,1);//打开副屏屏背光
    }

    public static double getOutTemp(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        return api.getAmbientTemp();
    }

    //关闭屏幕
    public static void closeScreen(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }

        api.setGpioState(rk3568.RK30_PIN3_PA4,0);//关闭主屏屏背光
        api.setGpioState(rk3568.RK30_PIN3_PA3,0);//关闭副屏屏背光
        api.setGpioState(rk3568.RK30_PIN0_PC3,0);//关闭主屏屏供电
        api.setGpioState(rk3568.RK30_PIN0_PC2,0);//关闭副屏屏供电
    }



    //打开4G开关
    public static void open4G(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("svc data enable");       //打开数据网络
    }

    //关闭4G开关
    public static void close4G(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("svc data disable");      //关闭数据网络
    }

    //打开eth1开关
    public static void openEth1(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("ifconfig eth1 up");  //打开eth1
    }

    //关闭eth1开关
    public static void closeEth1(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("ifconfig eth1 down");    //关闭eth1
    }

    //打开wifi开关
    public static void openWifi(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("svc wifi enable");   //打开WiFi
    }

    //关闭wifi开关
    public static void closeWifi(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("svc wifi disable");  //关闭Wifi
    }

//    //设备格式化
//    public static void format(Context context,String path){
//        if (api==null){
//            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
//        }
//        api.getStoragePath(path);
//    }

    public static String serverAddress(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        return api.getServerAddress();
    }



    //同步数据到存储
    public static void syncData(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.execSuCmd("sync");   //执行同步指令
    }

    //打开硬件声音 ，对应硬件GPIO3_C5
    public static void openHareVoice(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.setGpioState(rk3568.RK30_PIN3_PC5,1);
    }

    //关闭硬件声音，对应硬件GPIO3_C5
    public static void closeHareVoice(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        api.setGpioState(rk3568.RK30_PIN3_PC5,0);
    }

    public static float getInvirTemp(Context context){
        if (api==null){
            api= (InteflySmartApi) context.getSystemService("inteflysmartapi");
        }
        if(api.getApiVersion().compareTo("3.0.5")>0){
            return api.getAmbientTemp();
        }else{
            return 0;
        }
    }
}
