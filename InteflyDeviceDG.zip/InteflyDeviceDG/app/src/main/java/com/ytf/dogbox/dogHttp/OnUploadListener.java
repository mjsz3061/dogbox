package com.ytf.dogbox.dogHttp;


import com.ytf.dogbox.db.UploadItem;

/**
 * @author tiwolf_li
 * @Date on 2020/6/24
 * @Description
 */
public interface OnUploadListener {

    void onThreadProgressChange(int position, int persent);

    void onThreadFinish(String filePath);

    void onThreadInterrupted(int persent);

    void onAllSuccess(boolean isSingleFile,String md5);

    void onAllFailed();

    void onDownloadFail();

    void onDownloadSuccess();

    void onDownloadTreadSuccess();

    void onDownloadPackageSuccess();

    void onDownloadPackageFail();

    void onDownloadError(int errorCode);

    void onBoardProgressChange(int persent);//固件下载成功

    void onBoardDownloadSuccess();//固件下载成功

    void onBoardDownloadFail(); //固件下载失败

    void onUploadsPolieceSuccess(UploadItem uploadItem);//上传报警小文件成功，去上传记录

    void onUploadsRecordSuccess(UploadItem uploadItem);//上传录制小文件成功，去上传记录

    void onUploadPartSuccess(UploadItem uploadItem);//上传分片成功，去将所属的sn记录分片++，等上传分片数和sn分片总数相等的时候。即去合并操作

    void onUpLoadInterrupted(); //上传中断

    void onUploadError();   //上传出现其他问题

    void onFileError();     //上传文件出现问题
}


