package com.ytf.dogbox.util;

/**
 * author:tiwolf
 * create date:2022/2/11
 * Describe:
 */
public class ActivityConfig {

    public static final String sclive="sclive";//从服务器同步直播广告数据
    public static final String advert="advert";//从服务器接收普通广告数据
    public static final String coadvert="coadvert";//从服务器接收公益广告数据
    public static final String syncadvert="syncadvert";//从服务器同步普通广告数据
    public static final String synccoadvert="synccoadvert";//从服务器同步公益广告数据
    public static final String syncbroadcast="syncbroadcast";//从服务器同步广播数据
    public static final String closevolume="closevolume";//关闭普通音量，打开恒定音量
    public static final String openvolume="openvolume";//关闭恒定音量，打开普通音量
    public static final String inform="inform";//整点播报的数据
    public static final String ap="ap";//ap热点的数据
    public static final String wifi="wifi";//wifi的数据

    public static final String notification="notification";//预警开关

    public static final String syncaddata="syncaddata";//同步广告内容
    public static final String dm="dm";//布局变化
    public static final String extinguish="extinguish";//多时段息屏
    public static final String extinguishclear="extinguishclear";//清除息屏的列表
    public static final String po="po";//报警灯常亮
    public static final String spray="spray";//喷淋
    public static final String sprayclear="sprayclear";//清除喷淋列表
    public static final String lightspray="lightspray";
    public static final String screenLuminance="screenLuminance";//屏幕亮度列表
    public static final String rebootmechine="rebootMechine";//重启设备
    public static final String rebootFlag="rebootFlag";//是否每天进行重启设备

    public static final String bi="bi";//广播
    public static final String we="we";//天气
    public static final String we1="we1";//天气
    public static final String nt="nt";//指定版本
    public static final String upapk="upapk";//手动进行升级
    public static final String ledVir="ledVir";//仰邦屏幕添加内容
    public static final String ledcls="ledcls";//仰邦屏幕清除内容
    public static final String led="led";
    public static final String rest="rest";
    public static final String mute="mute";//静默时间


    public static final String content="content";//显示内容
    public static final String st="st";//决定底部内容显示
    public static final String map="map";//决定地图部分显示
    public static final String language="language";//决定了语言的设置
    public static final String advertdownload="advertdownload";//获取文件下载信息
    public static final String wifiswitch="wifiswitch";//wifi开关
    public static final String changeadvolumn="changeadvolumn";//更改广告音量
    public static final String vmd="vmd";//移动数据侦测
    public static final String wk="wk";//催款状态
    public static final String speaker="speaker";//语音提示
    public static final String ba="ba";//音量设置，更新音量
    public static final String ao="ao";//警报打开
    public static final String anc="anc";//警报关闭
    public static final String ccn="ccn";//更改摄像头名称
    public static final String cop="cop";//摄像头操作方向
    public static final String apiorder="apiorder";//api的直接指令
    public static final String debug="debug";//debug开关
    public static final String cameraMode="cameraMode";//摄像头模式
    public static final String focusAutoCorrect="FocusAutoCorrect";
    public static final String thirdStream="thirdStream";//第三码流参数

    public static final String htemwarn="htemwarn"; //高温提醒
    public static final String ltemwarn="ltemwarn"; //低温提醒
    public static final String wswarn="wswarn"; //风速提醒

    public static final String orbitautoon="OrbitAutoOn";//自动巡航打开
    public static final String orbitautooff="OrbitAutoOff";//自动巡航关闭

    public static final String chpic="chpic";//选择图片上传
    public static final String partcode="partcode";//功能码
    public static final String cr="cr";//开流
    public static final String ct="ct";//关流
    public static final String PAYSUCCESS="paySuccess";//支付成功后的订单
    public static final String SHOWBACK="showBack";//显示返回来的订单

    //洗狗机
    public static final String DOGBOXCONFIG="dogBoxConfig";//洗狗机价格配置
    public static final String DOGBOXFLOWCONFIG="dogboxFlowConfig";//洗狗机流程时间配置
    public static final String DOGBOXOTHERCONFIG="dogboxOtherConfig";//洗狗机其他配置
    public static final String DOGBOXSTATEINFOFLAG="dogboxStateInfoFlag";//洗狗机状态说明
    public static final String DOGCANCELPOP="dogCancelPop";//取消可能存在的弹窗
    public static final String DOGBOXWORKTIME="dogboxWorkTime";//洗狗机工作时间
}
