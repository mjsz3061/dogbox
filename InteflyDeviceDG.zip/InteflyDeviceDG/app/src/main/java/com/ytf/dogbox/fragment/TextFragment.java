package com.ytf.dogbox.fragment;
 
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ytf.dogbox.R;



public class TextFragment extends Fragment {

    //是否可见
    private boolean isVisibleToUser;
    //是否初始化完成
    public boolean isInit = false;
    //全局的view
    private View view;



    /*
     * 当前页面可见时和不可见的方法
     * */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        this.isVisibleToUser = isVisibleToUser;
        setParam();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //1.创建View视图
        if (view==null){
            view = inflater.inflate(R.layout.fragment_text,container,false);

            isInit=true;
            setParam();
        }
        return  view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e("TAG", "onResume: Fragment4-显示数据" );
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e("TAG", "onDestroyView: Fragment4-停止显示" );
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("TAG", "onDestroy: Fragment4-销毁控件" );
    }


    //处理逻辑和网络请求等
    private void setParam() {
        if (isInit && isVisibleToUser) {

            Log.e("tiwolf", "onCreateView: Fragment4-创建ui" );
        }
    }
}