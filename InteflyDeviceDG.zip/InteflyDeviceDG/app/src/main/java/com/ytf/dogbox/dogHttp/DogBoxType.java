package com.ytf.dogbox.dogHttp;

/**
 * author:tiwolf
 * create date:2023/11/2
 * Describe: DRY为烘干功能，BATH为洗澡功能+烘干，BADR为洗澡+烘干+烘干
 */
public enum DogBoxType {

    DRY,BATH,BADR;
}
