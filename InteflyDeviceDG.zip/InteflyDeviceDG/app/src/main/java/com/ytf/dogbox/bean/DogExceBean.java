package com.ytf.dogbox.bean;

/**
 * author:tiwolf
 * create date:2023/11/28
 * Describe:
 */
public class DogExceBean {

    private String exceName;
    private String exceType;
    private String remark;
    private String sn;
    private String upTime;

    public String getExceName() {
        return exceName;
    }

    public void setExceName(String exceName) {
        this.exceName = exceName;
    }

    public String getExceType() {
        return exceType;
    }

    public void setExceType(String exceType) {
        this.exceType = exceType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getUpTime() {
        return upTime;
    }

    public void setUpTime(String upTime) {
        this.upTime = upTime;
    }
}
