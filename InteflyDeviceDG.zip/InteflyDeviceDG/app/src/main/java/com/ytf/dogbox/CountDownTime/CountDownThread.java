package com.ytf.dogbox.CountDownTime;

import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;

public class CountDownThread extends CountDownTimer {

    private final static String TAG=CountDownThread.class.getSimpleName();


    private OnCountDownListener listener;

    Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:{
                    listener.getCountDownTime(msg.arg1);
                    break;
                }
                case 2:{
                    listener.timeOver();
                    break;
                }
            }
        }
    };


    public CountDownThread(long millisInFuture,long countDownInterval){
        super(millisInFuture,countDownInterval);
    }

    public void setOnCountDownTimeListener(OnCountDownListener listener){
        this.listener=listener;
    }

    @Override
    public void onTick(long millisUntilFinished) {
        Message msg = new Message();
        msg.what = 1;
        msg.arg1 = (int)millisUntilFinished/1000;
        mHandler.sendMessage(msg);
    }


    @Override
    public void onFinish() {
        Message msg = new Message();
        msg.what = 2;
        mHandler.sendMessage(msg);
    }
}
