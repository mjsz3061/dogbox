package com.ytf.dogbox.bean;

public class DownloadItem {

    private int downloadFlag;      //下载状态
    private String downloadLength;     //下载进度，断点续传的时候用到
    private String downloadTotal;      //文件总长度
    private int downloadId;      //下载的所需id
    private String downloadMd5;     //下载所需md5
    private String downloadName;    //名称
    private String downloadExt;     //后缀名
    private int playType;    //下载的类型


    public String getDownloadLength() {
        return downloadLength;
    }

    public void setDownloadLength(String downloadLength) {
        this.downloadLength = downloadLength;
    }

    public int getDownloadId() {
        return downloadId;
    }

    public void setDownloadId(int downloadId) {
        this.downloadId = downloadId;
    }

    public String getDownloadMd5() {
        return downloadMd5;
    }

    public void setDownloadMd5(String downloadMd5) {
        this.downloadMd5 = downloadMd5;
    }

    public String getDownloadName() {
        return downloadName;
    }

    public void setDownloadName(String downloadName) {
        this.downloadName = downloadName;
    }

    public int getDownloadFlag() {
        return downloadFlag;
    }

    public void setDownloadFlag(int downloadFlag) {
        this.downloadFlag = downloadFlag;
    }

    public String getDownloadTotal() {
        return downloadTotal;
    }

    public void setDownloadTotal(String downloadTotal) {
        this.downloadTotal = downloadTotal;
    }

    public String getDownloadExt() {
        return downloadExt;
    }

    public void setDownloadExt(String downloadExt) {
        this.downloadExt = downloadExt;
    }

    public int getPlayType() {
        return playType;
    }

    public void setPlayType(int playType) {
        this.playType = playType;
    }

}
