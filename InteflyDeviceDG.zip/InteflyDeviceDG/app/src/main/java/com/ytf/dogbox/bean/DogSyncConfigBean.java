package com.ytf.dogbox.bean;

import java.util.List;

/**
 * author:tiwolf
 * create date:2024/1/17
 * Describe:
 */
public class DogSyncConfigBean {


    private FlowBean washStepConfig;
    List<DogPriceBean> washTypeConfig;
    private DogOtherBean attributeConfig;
    private long updateTime;

    public FlowBean getWashStepConfig() {
        return washStepConfig;
    }

    public void setWashStepConfig(FlowBean washStepConfig) {
        this.washStepConfig = washStepConfig;
    }

    public List<DogPriceBean> getWashTypeConfig() {
        return washTypeConfig;
    }

    public void setWashTypeConfig(List<DogPriceBean> washTypeConfig) {
        this.washTypeConfig = washTypeConfig;
    }

    public DogOtherBean getAttributeConfig() {
        return attributeConfig;
    }

    public void setAttributeConfig(DogOtherBean attributeConfig) {
        this.attributeConfig = attributeConfig;
    }


    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }
}
