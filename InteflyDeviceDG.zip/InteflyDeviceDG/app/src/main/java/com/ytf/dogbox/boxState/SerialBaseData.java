package com.ytf.dogbox.boxState;

import android.content.Context;

import com.ytf.dogbox.activity.SocketService;
import com.ytf.dogbox.serialport.SerialHelper;


/**
 * author:tiwolf
 * create date:2023/2/3
 * Describe:串口的一个基础类，主要用来分辨各类下发串口数据的类型
 */
public abstract class SerialBaseData<T> {

    /**
     * 向下发送数据
     * @param serialControl
     * @param order
     */
    public abstract void sendOrderToDevice(SerialHelper serialControl, String order);

    /**
     * 用来解析设备的数据，然后使用监听将其返回
     * @param result
     * @return
     */
    public abstract T  receiveDataFromDevice(Context context, String result);

}
