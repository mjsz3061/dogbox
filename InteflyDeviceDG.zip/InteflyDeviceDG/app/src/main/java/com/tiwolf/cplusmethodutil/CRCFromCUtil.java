package com.tiwolf.cplusmethodutil;

/**
 * author:tiwolf
 * create date:2023/12/14
 * Describe:
 */
public class CRCFromCUtil {

    static {
        System.loadLibrary("cplusmethodutil");
    }

    public static native String getCRCResult(byte[] input,int length);

    public static native short getCRCData(byte[] input,int length);
}
